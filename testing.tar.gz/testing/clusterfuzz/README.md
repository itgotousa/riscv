Useful scripts for writting ClusterFuzz fuzzers.

https://www.chromium.org/Home/chromium-security/bugs/developing-fuzzers-for-clusterfuzz
