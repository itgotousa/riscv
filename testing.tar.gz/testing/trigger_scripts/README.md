# Swarming trigger scripts

This directory contains Swarming trigger scripts, which are trampoline
scripts that provide finer-grained control of how tests are sharded
and distributed on the Swarming fleet.

Trigger scripts are documented here:

https://cs.chromium.org/search/?q=file:swarming/api.py+%22*+trigger_script:%22&type=cs
