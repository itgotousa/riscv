#if 0


// Copyright 2014 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "mojo/core/configuration.h"

namespace mojo {
namespace core {
namespace internal {

Configuration g_configuration;

}  // namespace internal
}  // namespace core
}  // namespace mojo



#endif
