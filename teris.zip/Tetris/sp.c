#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*------------------------- SWF Tag types------------------------*/
#define ST_END                  0
#define ST_SHOWFRAME            1
#define ST_DEFINESHAPE          2
#define ST_FREECHARACTER        3
#define ST_PLACEOBJECT          4
#define ST_REMOVEOBJECT         5
#define ST_DEFINEBITS           6
#define ST_DEFINEBITSJPEG       6
#define ST_DEFINEBUTTON         7
#define ST_JPEGTABLES           8
#define ST_SETBACKGROUNDCOLOR   9
#define ST_DEFINEFONT           10
#define ST_DEFINETEXT           11
#define ST_DOACTION             12
#define ST_DEFINEFONTINFO       13
#define ST_DEFINESOUND          14 /* Event sound tags. */
#define ST_STARTSOUND           15
#define ST_DEFINEBUTTONSOUND    17
#define ST_SOUNDSTREAMHEAD      18
#define ST_SOUNDSTREAMBLOCK     19
#define ST_DEFINEBITSLOSSLESS   20 /* A bitmap using lossless zlib compression. */
#define ST_DEFINEBITSJPEG2      21 /* A bitmap using an internal JPEG compression table. */
#define ST_DEFINESHAPE2         22
#define ST_DEFINEBUTTONCXFORM   23
#define ST_PROTECT              24 /* This file should not be importable for editing. */
#define ST_PLACEOBJECT2         26 /* The new style place w/ alpha color transform and name. */
#define ST_REMOVEOBJECT2        28 /* A more compact remove object that omits the character tag (just depth). */
#define ST_FREEALL              31 /* ? */
#define ST_DEFINESHAPE3         32 /* A shape V3 includes alpha values. */
#define ST_DEFINETEXT2          33 /* A text V2 includes alpha values. */
#define ST_DEFINEBUTTON2        34 /* A button V2 includes color transform, alpha and multiple actions */
#define ST_DEFINEBITSJPEG3      35 /* A JPEG bitmap with alpha info. */
#define ST_DEFINEBITSLOSSLESS2  36 /* A lossless bitmap with alpha info. */
#define ST_DEFINEEDITTEXT       37
#define ST_DEFINEMOVIE          38
#define ST_DEFINESPRITE         39 /* Define a sequence of tags that describe the behavior of a sprite. */
#define ST_NAMECHARACTER        40 /* Name a character definition, character id and a string, (used for buttons, bitmaps, sprites and sounds). */
#define ST_SERIALNUMBER         41
#define ST_GENERATORTEXT        42 /* contains an id */
#define ST_FRAMELABEL           43 /* A string label for the current frame. */
#define ST_SOUNDSTREAMHEAD2     45 /* For lossless streaming sound, should not have needed this... */
#define ST_DEFINEMORPHSHAPE     46 /* A morph shape definition */
#define ST_DEFINEFONT2          48
#define ST_TEMPLATECOMMAND      49
#define ST_GENERATOR3           51
#define ST_EXTERNALFONT         52
#define ST_EXPORTASSETS			56
#define ST_IMPORTASSETS			57
#define ST_ENABLEDEBUGGER		58
#define ST_DOINITACTION         59
#define ST_DEFINEVIDEOSTREAM    60
#define ST_VIDEOFRAME           61
#define ST_DEFINEFONTINFO2		62
#define ST_MX4					63 /*(?) */
#define ST_ENABLEDEBUGGER2      64 /* version 8 */
#define ST_SCRIPTLIMITS			65 /* version 7- u16 maxrecursedepth, u16 scripttimeoutseconds */
#define ST_SETTABINDEX			66 /* version 7- u16 depth(!), u16 tab order value */
#define ST_FILEATTRIBUTES		69 /* version 8 (required)- */
#define ST_PLACEOBJECT3			70 /* version 8 */
#define ST_IMPORTASSETS2		71 /* version 8 */
#define ST_RAWABC               72 /* version 9, used by flex */
#define ST_DEFINEFONTALIGNZONES 73 /* version 8 */
#define ST_CSMTEXTSETTINGS		74 /* version 8 */
#define ST_DEFINEFONT3			75 /* version 8 */
#define ST_SYMBOLCLASS			76 /* version 9 */
#define ST_METADATA				77 /* version 8 */
#define ST_DEFINESCALINGGRID    78 /* version 8 */
#define ST_DOABC				82 /* version 9 */
#define ST_DEFINESHAPE4			83 /* version 8 */
#define ST_DEFINEMORPHSHAPE2    84 /* version 8 */
#define ST_SCENEDESCRIPTION		86 /* version 9 */
#define ST_DEFINEBINARY			87 /* version 9 */
#define ST_DEFINEFONTNAME		88 /* version 9 */

#define ST_CAMTASIA           	700 /* to identify generator software */
/* custom tags- only valid for swftools */
#define ST_REFLEX             	777 /* to identify generator software */
#define ST_GLYPHNAMES          	778

typedef unsigned char uint8_t;
typedef signed char int8_t;
typedef unsigned short uint16_t;
typedef signed short int16_t;
typedef unsigned int uint32_t;
typedef signed int int32_t;

#ifdef _MSC_VER
typedef unsigned __int64 uint64_t;
typedef signed __int64 int64_t;
#else
typedef unsigned long long uint64_t;
typedef long long int64_t;
#endif

uint8_t   sign0800[9] = {0x78, 0x00, 0x07, 0xd0, 0x00, 0x00, 0x17, 0x70, 0x00};
uint8_t   sign1024[9] = {0x80, 0x00, 0x02, 0x80, 0x00, 0x00, 0x01, 0xE0, 0x00};
/*
 * 1000.0000-0000.0000-0000.0010-1000.0000-0000.0000-0000.0000-0000.0001-1110.0000-0000.0000
 * NBits = 10000 = 16
 * Xmin = 000-0000.0000-0000.0 = 0
 * XMax = 010-1000.0000-0000.0 = 0101.0000.0000.0000 = 0x5000 / 20  
 * Ymin = 000-0000.0000-0000.0 = 0
 * Ymax = 001-1110.0000-0000.0 = 0011.1100.0000.0000 = 0x3C00 / 20
 */
uint16_t  g_tag[1024]; /* global variables : tag table */
const char*  tagName[1024];

static void init_tag()
{
	int i;
	
	for(i = 0; i < 1024; i++) g_tag[i] = 0;
	g_tag[ST_END]                 = 1;
	g_tag[ST_SHOWFRAME]           = 1;
	g_tag[ST_SOUNDSTREAMBLOCK]    = 1;
	g_tag[ST_DOACTION]            = 1;
	g_tag[ST_PLACEOBJECT2]        = 1;
	g_tag[ST_DEFINESHAPE3]        = 1;
	g_tag[ST_DEFINEBITSLOSSLESS2] = 1;
	g_tag[ST_FRAMELABEL]          = 1;
	g_tag[ST_SOUNDSTREAMHEAD2]    = 1;
	g_tag[ST_CAMTASIA]            = 1;
	g_tag[ST_FILEATTRIBUTES]      = 1;
	g_tag[ST_METADATA]            = 1;
	g_tag[ST_REMOVEOBJECT2]       = 1;

	for(i = 0; i < 1024; i++) tagName[i] = NULL;
	tagName[ST_END]                 = "ST_END";
	tagName[ST_SHOWFRAME]           = "ST_SHOWFRAME";
	tagName[ST_SOUNDSTREAMBLOCK]    = "ST_SOUNDSTREAMBLOCK";
	tagName[ST_DOACTION]            = "ST_DOACTION";
	tagName[ST_PLACEOBJECT2]        = "ST_PLACEOBJECT2";
	tagName[ST_DEFINESHAPE3]        = "ST_DEFINESHAPE3";
	tagName[ST_DEFINEBITSLOSSLESS2] = "ST_DEFINEBITSLOSSLESS2";
	tagName[ST_FRAMELABEL]          = "ST_FRAMELABEL";
	tagName[ST_SOUNDSTREAMHEAD2]    = "ST_SOUNDSTREAMHEAD2";
	tagName[ST_CAMTASIA]            = "ST_CAMTASIA";
	tagName[ST_FILEATTRIBUTES]      = "ST_FILEATTRIBUTES";
	tagName[ST_METADATA]            = "ST_METADATA";
	tagName[ST_REMOVEOBJECT2]       = "ST_REMOVEOBJECT2";
}

int main(int argc, char* argv[])
{
uint32_t  size, len, tagIdx;
int       ret;
FILE     *fi;
uint8_t* inbuf = NULL;
uint8_t  *p;
uint32_t *psize;
uint16_t  tagCL, tagid, framecount;
uint32_t  taglen, bmplen, skip, counter;

    if(argc < 2) {
        printf("SWF parser usage: %s swf_file\n", argv[0]);
		return 0;
    }
    
    init_tag();
    
    fi = fopen(argv[1], "rb");
    if(NULL == fi) {
		printf("cannot open swf file [%s]!\n", argv[1]);
        return 0;
    }
    
    fseek(fi, 0L, SEEK_END);
    size = ftell(fi);
    printf("fie size is %d bytes!\n", size);
    
    fseek(fi, 0L, SEEK_SET);
    
    inbuf = (uint8_t*)malloc(size);
    if(NULL == inbuf) {
        printf("Cannot allocate %d bytes memory!\n", size);
        return 0;
    }
   
    ret = fread(inbuf, size, 1, fi);   
	if(1 != ret) {
        printf("Cannot read %d bytes from SWF file!\n", size);
        goto _exit_app;
    }
    fclose(fi);
    
    p = inbuf; 
    if(p[0] != 'F' || p[1] != 'W' || p[2] != 'S' || p[3] != 0x08) {
        printf("Signature is wrong!\n");
        goto _exit_app;
    }
    printf("SWF header is good!\n");
    
    psize = (uint32_t *)(p+4);
    printf("SWF file size is: %d - %d bytes\n", size, *psize);
    
    if(0 == memcmp(p+8, sign0800, 9)) {
        printf("it is 800 X 600 size\n");
    } else if(0 == memcmp(p+8, sign1024, 9)) { 
        printf("it is 1024 X 768 size\n");
    } else {
        printf("demision is not standard size\n");
    }
    
    if(p[17]) { printf(" frame count is wrong! p[17]=%d\n", p[17]); }
    
    printf("frame rate is %d/seconds\n", p[18]);
    framecount = (uint16_t)*(p+20); 
    framecount <<= 8;
    framecount += (uint16_t)*(p+19); 
    printf("frame count is %d\n", framecount);
    framecount = *((uint16_t*)(p+19));
    printf("frame count is %d\n", framecount);
    if(framecount > 16000) {  /* swf is 16000 frames or less */
        printf("Frame Count[%d] is wrong!\n", framecount);
        goto _exit_app;
    }
    
    p = inbuf + 21;  /* p --> the first tag */
    tagIdx = 0;
	uint16_t charId;
	uint32_t TAGLEN;
    do {
		charId = 0;
        tagCL = *((uint16_t *)p); /* get the TagCodeAndLength 2 bytes */
        taglen = tagCL & 0x3F; TAGLEN = taglen;
        tagid  = (tagCL >> 6) & 0x03FF; /* 11 1111,1111*/
        if(0 == g_tag[tagid]) { /* we are sure that the camtasia video only use 13 tags */
            printf("------------------------------------ Invalid tag: %d\n", tagid);
        }
        else g_tag[tagid]++; /* we count how many times each tag in the swf file here */
		
		if(0x3F == taglen) TAGLEN = *((uint32_t*)(p+2));
        
        if(ST_DEFINEBITSLOSSLESS2 == tagid) {
			charId = *((uint16_t *)(p+6));
#if 0            
            if(0x3F == taglen) bmplen = *((uint32_t*)(p+2)); /* get the next 4 bytes */
            uint16_t characterid, w, h;
            uint8_t bmpformat;
            characterid = *((uint16_t *)(p+6));
            bmpformat = *(p+8);
            w = *((uint16_t *)(p+9)); h = *((uint16_t *)(p+11));
            printf("[%d]-ST_DEFINEBITSLOSSLESS2: taglen=%d, characterid=%d, bmpformat=%d, w=%d, h=%d\n",
            tagIdx, bmplen, characterid, bmpformat, w, h);
#endif             
        }


        if(ST_SOUNDSTREAMHEAD2 == tagid) {
#if 0            
            uint8_t b;
            printf("[%d]-ST_SOUNDSTREAMHEAD2: tagid=%d, taglen=%d\n", tagIdx, tagid, taglen);
            /* printf("%2X-%2X-%2X-%2X\n", p[2],p[3],p[4],p[5]); */
            b = (p[2] & 0xF0) >> 4;
            printf("-- Reserved=%d\n", b);
            b = (p[2] & 0x0C) >> 2;
            printf("-- PlaybackSoundRate=%d\n", b);
            b = (p[2] & 0x02) >> 1;
            printf("-- PlaybackSoundSize=%d\n", b);
            b = (p[2] & 0x01);
            printf("-- PlaybackSoundType=%d\n", b);
            b = (p[3] & 0xF0) >> 4;
            printf("-- StreamSoundCompression=%d\n", b);
            b = (p[3] & 0x0C) >> 2;
            printf("-- StreamSoundRate=%d\n", b);
            b = (p[3] & 0x02) >> 1;
            printf("-- StreamSoundSize=%d\n", b);
            b = (p[3] & 0x01);
            printf("-- StreamSoundType=%d\n", b);
            /*
            [9]-ST_SOUNDSTREAMHEAD2: tagid=45, taglen=6
            F-2F-7C- B 
            0000.1111-0010.1111-0111.1100-0000.1011
            */
#endif            
        }

        if(ST_SHOWFRAME == tagid) {
            /* printf("[%d]-ST_SHOWFRAME: tagid=%d, taglen=%d\n", tagIdx, tagid, taglen); */
        }
        
        if(ST_PLACEOBJECT2 == tagid) {
#if 0            
            uint8_t b;
            uint8_t PlaceFlagHasClipActions = 0;
            uint8_t PlaceFlagHasClipDepth = 0;
            uint8_t PlaceFlagHasName = 0;
            uint8_t PlaceFlagHasRatio = 0;
            uint8_t PlaceFlagHasColorTransform = 0;
            uint8_t PlaceFlagHasMatrix = 0;
            uint8_t PlaceFlagHasCharacter = 0;
            uint8_t PlaceFlagMove = 0;
            uint16_t Depth, CharacterId;
            b = p[2];
            PlaceFlagHasClipActions = (0 != (b & 0x80));
            PlaceFlagHasClipDepth = (0 != (b & 0x40));
            PlaceFlagHasName = (0 != (b & 0x20));
            PlaceFlagHasRatio = (0 != (b & 0x10));
            PlaceFlagHasColorTransform = (0 != (b & 0x08));
            PlaceFlagHasMatrix = (0 != (b & 0x04));
            PlaceFlagHasCharacter = (0 != (b & 0x01));
            PlaceFlagMove = (0 != (b & 0x01));
            Depth = *((uint16_t *)(p+3));
            printf("[%d]-ST_PLACEOBJECT2: Depth=%d PlaceFlagHasCharacter=%d PlaceFlagHasMatrix = %d\n"
                    ,tagIdx
                    ,Depth
                    ,PlaceFlagHasCharacter
                    ,PlaceFlagHasMatrix);
#endif                     
			charId = *((uint16_t *)(p+2+3));	
			printf("ST_PLACEOBJECT2X[%d][%d](%d) ==> ", charId, taglen, TAGLEN);
			for(uint32_t i=0; i<TAGLEN; i++)
				printf("%02X:", *(p+2+i));
			printf("\n");
        }
        
        if(ST_DEFINESHAPE3 == tagid) {
#if 1
			charId = *((uint16_t *)(p+2));	
			printf("ST_DEFINESHAPE3 =============[%d][%d](%d)\n", charId, taglen, TAGLEN);
			for(uint32_t i=0; i<TAGLEN; i++)
				printf("%02X:", *(p+2+i));
			printf("\n");
#endif 
        }
        
        if(ST_SOUNDSTREAMBLOCK == tagid) {
        }
        
        if(ST_SOUNDSTREAMBLOCK == tagid) {
        }
        
        if(ST_SOUNDSTREAMBLOCK == tagid) {
        }
        
        if(ST_SOUNDSTREAMBLOCK == tagid) {
        }
        
        if(ST_PLACEOBJECT2 == tagid) {
			
        }
        
		printf("[%d:%d] --[%s][%d]\n", tagIdx, charId, tagName[tagid], TAGLEN);

        if(0x3F == taglen) 	{ /* it is a long tag */
            taglen = *((uint32_t*)(p+2)); /* get the next 4 bytes */
            /* now put the tagid in the lower byte, and length in the upper byte !!! */
            tagCL = tagid | 0xFC00;
            skip = 4 + taglen;
        } else {
            tagCL = tagid | (taglen << 10); /* xxxxxx,00 | tagid */
            skip = taglen;
        }
        p += (skip + 2); /* go to the next tag */
        tagIdx++;
    } while (ST_END != tagid);
    
    if(framecount != g_tag[ST_SHOWFRAME]-1) { /* check the frame count is ok?*/
        printf("The frame count is error![%d] - [%d]\n", framecount, g_tag[ST_SHOWFRAME] - 1);
    }
    
	printf("===== parser successfuly! ======\n");

	printf("g_tag[ST_END] = %d\n", g_tag[ST_END]-1);
	printf("g_tag[ST_SHOWFRAME] = %d\n", g_tag[ST_SHOWFRAME]-1);
	printf("g_tag[ST_SOUNDSTREAMBLOCK] = %d\n", g_tag[ST_SOUNDSTREAMBLOCK]-1);
	printf("g_tag[ST_PLACEOBJECT2] = %d\n", g_tag[ST_PLACEOBJECT2]-1);
	printf("g_tag[ST_DEFINESHAPE3] = %d\n", g_tag[ST_DEFINESHAPE3]-1);
	printf("g_tag[ST_DEFINEBITSLOSSLESS2] = %d\n", g_tag[ST_DEFINEBITSLOSSLESS2]-1);
	printf("g_tag[ST_SOUNDSTREAMHEAD2] = %d\n", g_tag[ST_SOUNDSTREAMHEAD2]-1);
	printf("g_tag[ST_REMOVEOBJECT2] = %d\n", g_tag[ST_REMOVEOBJECT2]-1);
	printf("--------------------------------------------\n");
	printf("g_tag[ST_DOACTION] = %d\n", g_tag[ST_DOACTION]-1);
	printf("g_tag[ST_FRAMELABEL] = %d\n", g_tag[ST_FRAMELABEL]-1);
	printf("g_tag[ST_CAMTASIA] = %d\n", g_tag[ST_CAMTASIA]-1);
	printf("g_tag[ST_FILEATTRIBUTES] = %d\n", g_tag[ST_FILEATTRIBUTES]-1);
	printf("g_tag[ST_METADATA] = %d\n", g_tag[ST_METADATA]-1);
    
_exit_app:
	if(NULL != inbuf) free(inbuf);
    return 0;
}

