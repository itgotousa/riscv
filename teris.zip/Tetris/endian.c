#include <stdio.h>

int endian = 1;

int main(int argc, const char* argv[])
{
	if(1 == *(char*)&endian)
	{ 
		printf("Your system is little endian\n");
	}
	else 
	{
		 printf("Your system is big endian\n");
	}

	return 0;
}
