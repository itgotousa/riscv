#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

/*------------------------- SWF Tag types------------------------*/
#define ST_END                  0
#define ST_SHOWFRAME            1
#define ST_DEFINESHAPE          2
#define ST_FREECHARACTER        3
#define ST_PLACEOBJECT          4
#define ST_REMOVEOBJECT         5
#define ST_DEFINEBITS           6
#define ST_DEFINEBITSJPEG       6
#define ST_DEFINEBUTTON         7
#define ST_JPEGTABLES           8
#define ST_SETBACKGROUNDCOLOR   9
#define ST_DEFINEFONT           10
#define ST_DEFINETEXT           11
#define ST_DOACTION             12
#define ST_DEFINEFONTINFO       13
#define ST_DEFINESOUND          14 /* Event sound tags. */
#define ST_STARTSOUND           15
#define ST_DEFINEBUTTONSOUND    17
#define ST_SOUNDSTREAMHEAD      18
#define ST_SOUNDSTREAMBLOCK     19
#define ST_DEFINEBITSLOSSLESS   20 /* A bitmap using lossless zlib compression. */
#define ST_DEFINEBITSJPEG2      21 /* A bitmap using an internal JPEG compression table. */
#define ST_DEFINESHAPE2         22
#define ST_DEFINEBUTTONCXFORM   23
#define ST_PROTECT              24 /* This file should not be importable for editing. */
#define ST_PLACEOBJECT2         26 /* The new style place w/ alpha color transform and name. */
#define ST_REMOVEOBJECT2        28 /* A more compact remove object that omits the character tag (just depth). */
#define ST_FREEALL              31 /* ? */
#define ST_DEFINESHAPE3         32 /* A shape V3 includes alpha values. */
#define ST_DEFINETEXT2          33 /* A text V2 includes alpha values. */
#define ST_DEFINEBUTTON2        34 /* A button V2 includes color transform, alpha and multiple actions */
#define ST_DEFINEBITSJPEG3      35 /* A JPEG bitmap with alpha info. */
#define ST_DEFINEBITSLOSSLESS2  36 /* A lossless bitmap with alpha info. */
#define ST_DEFINEEDITTEXT       37
#define ST_DEFINEMOVIE          38
#define ST_DEFINESPRITE         39 /* Define a sequence of tags that describe the behavior of a sprite. */
#define ST_NAMECHARACTER        40 /* Name a character definition, character id and a string, (used for buttons, bitmaps, sprites and sounds). */
#define ST_SERIALNUMBER         41
#define ST_GENERATORTEXT        42 /* contains an id */
#define ST_FRAMELABEL           43 /* A string label for the current frame. */
#define ST_SOUNDSTREAMHEAD2     45 /* For lossless streaming sound, should not have needed this... */
#define ST_DEFINEMORPHSHAPE     46 /* A morph shape definition */
#define ST_DEFINEFONT2          48
#define ST_TEMPLATECOMMAND      49
#define ST_GENERATOR3           51
#define ST_EXTERNALFONT         52
#define ST_EXPORTASSETS			56
#define ST_IMPORTASSETS			57
#define ST_ENABLEDEBUGGER		58
#define ST_DOINITACTION         59
#define ST_DEFINEVIDEOSTREAM    60
#define ST_VIDEOFRAME           61
#define ST_DEFINEFONTINFO2		62
#define ST_MX4					63 /*(?) */
#define ST_ENABLEDEBUGGER2      64 /* version 8 */
#define ST_SCRIPTLIMITS			65 /* version 7- u16 maxrecursedepth, u16 scripttimeoutseconds */
#define ST_SETTABINDEX			66 /* version 7- u16 depth(!), u16 tab order value */
#define ST_FILEATTRIBUTES		69 /* version 8 (required)- */
#define ST_PLACEOBJECT3			70 /* version 8 */
#define ST_IMPORTASSETS2		71 /* version 8 */
#define ST_RAWABC               72 /* version 9, used by flex */
#define ST_DEFINEFONTALIGNZONES 73 /* version 8 */
#define ST_CSMTEXTSETTINGS		74 /* version 8 */
#define ST_DEFINEFONT3			75 /* version 8 */
#define ST_SYMBOLCLASS			76 /* version 9 */
#define ST_METADATA				77 /* version 8 */
#define ST_DEFINESCALINGGRID    78 /* version 8 */
#define ST_DOABC				82 /* version 9 */
#define ST_DEFINESHAPE4			83 /* version 8 */
#define ST_DEFINEMORPHSHAPE2    84 /* version 8 */
#define ST_SCENEDESCRIPTION		86 /* version 9 */
#define ST_DEFINEBINARY			87 /* version 9 */
#define ST_DEFINEFONTNAME		88 /* version 9 */

#define ST_CAMTASIA           	700 /* to identify generator software */
/* custom tags- only valid for swftools */
#define ST_REFLEX             	777 /* to identify generator software */
#define ST_GLYPHNAMES          	778
/*------------------------- SWF Tag types------------------------*/
#define MB_END                  0xED
#define MB_SHOWFRAME            0xFA
#define MB_SOUNDSTREAMBLOCK     0xDB
#define MB_PLACEOBJECT2         0xE2
#define MB_DEFINESHAPE3         0xD3
#define MB_DEFINEBITSLOSSLESS   0xB1
#define MB_DEFINEBITSLOSSLESS2  0xB2
#define MB_SOUNDSTREAMHEAD2     0x2A
#define MB_REMOVEOBJECT2        0x2C

#if 0
typedef unsigned char uint8_t;
typedef signed char int8_t;
typedef unsigned short uint16_t;
typedef signed short int16_t;
typedef unsigned int uint32_t;
typedef signed int int32_t;
#endif

uint8_t   sign0800[9] = {0x78, 0x00, 0x07, 0xd0, 0x00, 0x00, 0x17, 0x70, 0x00};
uint8_t   sign1024[9] = {0x80, 0x00, 0x02, 0x80, 0x00, 0x00, 0x01, 0xE0, 0x00};
/*
 * 1000.0000-0000.0000-0000.0010-1000.0000-0000.0000-0000.0000-0000.0001-1110.0000-0000.0000
 * NBits = 10000 = 16
 * Xmin = 000-0000.0000-0000.0 = 0
 * XMax = 010-1000.0000-0000.0 = 0101.0000.0000.0000 = 0x5000 / 20  
 * Ymin = 000-0000.0000-0000.0 = 0
 * Ymax = 001-1110.0000-0000.0 = 0011.1100.0000.0000 = 0x3C00 / 20
 */
uint16_t  g_tag[1024]; /* global variables : tag table */
static const char* tagName[1024];

static void init_tag()
{
	int i;
	
	for(i = 0; i < 1024; i++) g_tag[i] = 0;
	g_tag[ST_END]                 = 1;
	g_tag[ST_SHOWFRAME]           = 1;
	g_tag[ST_SOUNDSTREAMBLOCK]    = 1;
	g_tag[ST_DOACTION]            = 1;
	g_tag[ST_PLACEOBJECT2]        = 1;
	g_tag[ST_DEFINESHAPE3]        = 1;
	g_tag[ST_DEFINEBITSLOSSLESS2] = 1;
	g_tag[ST_FRAMELABEL]          = 1;
	g_tag[ST_SOUNDSTREAMHEAD2]    = 1;
	g_tag[ST_CAMTASIA]            = 1;
	g_tag[ST_FILEATTRIBUTES]      = 1;
	g_tag[ST_METADATA]            = 1;
	g_tag[ST_REMOVEOBJECT2]       = 1;
    
	for(i = 0; i < 1024; i++) tagName[i] = 0;
    tagName[ST_END] = "ST_END";
    tagName[ST_SHOWFRAME] = "ST_SHOWFRAME";
    tagName[ST_SOUNDSTREAMBLOCK] = "ST_SOUNDSTREAMBLOCK";
    tagName[ST_DOACTION] = "ST_DOACTION";
    tagName[ST_PLACEOBJECT2] = "ST_PLACEOBJECT2";
    tagName[ST_DEFINESHAPE3] = "ST_DEFINESHAPE3";
    tagName[ST_DEFINEBITSLOSSLESS2] = "ST_DEFINEBITSLOSSLESS2";
    tagName[ST_FRAMELABEL] = "ST_FRAMELABEL";
    tagName[ST_SOUNDSTREAMHEAD2] = "ST_SOUNDSTREAMHEAD2";
    tagName[ST_CAMTASIA] = "ST_CAMTASIA";
    tagName[ST_FILEATTRIBUTES] = "ST_FILEATTRIBUTES";
    tagName[ST_METADATA] = "ST_METADATA";
    tagName[ST_REMOVEOBJECT2] = "ST_REMOVEOBJECT2";
  
}

#define U8      uint8_t
#define S16     int16_t
#define U16     uint16_t
#define S32     int32_t
#define U32     uint32_t

#define SCOORD  int32_t
#define SFIXED  int32_t

#define SWF_Abs(v)			((v)<0?(-(v)):(v))
#define SWF_Max(a,b)		((a)>(b)?(a):(b))
#define SWF_Min(a,b)		((a)<(b)?(a):(b))

typedef struct SRECT {	// Note that a rectangle is considered empty if xmin == rectEmptyFlag
    SCOORD xmin;
    SCOORD xmax;
    SCOORD ymin;
    SCOORD ymax;
} SRECT, * P_SRECT;

typedef struct MATRIX {
    SFIXED a;
    SFIXED b;
    SFIXED c;
    SFIXED d;
    SCOORD tx;
    SCOORD ty;
} MATRIX;

	// The low level parser
class SParser {
public:
    U8* script;  /* contains the SWF stream */
    S32 pos; /* the current position of script */

    // Bit Handling
    U32 bitBuf;
    int bitPos;

public:
    // Tag Parser
    U32 tagPos;		// the start pos of the tag
    U32 tagEnd;
    U16 tagCode;
    U8  tagType;
    // return -1 if the tag is not yet loaded given len data
    int GetTag(S32 len = 0x1FFFFFFF) 
    {
        tagPos = pos;
        if (len - pos < 2)
            return -1;	// we need more data before we can process this tag. each tag is 2 bytes

        tagCode = GetWord();
        tagType = 'S';
        U32 tagLen = tagCode & 0x3F;
        if (tagLen == 0x3f) { /* it is a long tag */
            tagType = 'L';
            if (len - pos < 4) {
                pos = tagPos;
                return -1;	// we need more data before we can process this tag
            }
            tagLen = GetDWord();
        }
        tagEnd = pos + tagLen;
        if (tagEnd > len) {
            pos = tagPos;
            return -1;	// we need more data before we can process this tag
        }
        tagCode = tagCode >> 6;

        return tagCode;
    }
    void GoToNextTag()
    {
        pos = tagEnd;
    }
public:
    SParser()
    {
        script = NULL;
        pos = 0;
        bitBuf = 0;
        bitPos = 0;
        tagPos = 0;
        tagEnd = 0;
        tagCode = 0;
    }

    ~SParser() {}

    void Attach(U8* s, S32 start, S32 e = (1L << 29))
    {
        script = s;
        pos = start;
        tagEnd = e;
    }

    void SkipBytes(int n) { pos += n; }
    // Get data from the script
    U8 GetByte() { return script[pos++]; }
    U16 GetWord() 
    {
        U8* s = script + pos; 
        pos += 2;
        return (U16)s[0] | ((U16)s[1] << 8);
    }
    U32 GetDWord()
    {
        U8* s = script + pos;
        pos += 4;
        return (U32)s[0] | ((U32)s[1] << 8) | ((U32)s[2] << 16) | ((U32)s[3] << 24);
    }

    // returns the actual number of bytes read could 
    // be less than len if we hit the end of a tag
    U32 GetData(void* data, U32 len)
    {
        U32 n = SWF_Min(len, tagEnd - pos);
        memcpy(data, script + pos, n);
        pos += n;
        return n;
    }

    void GetRect(SRECT* r)
    {
        InitBits();
        int nBits = (int)GetBits(5);
        r->xmin = GetSBits(nBits) / 20;
        r->xmax = GetSBits(nBits) / 20;
        r->ymin = GetSBits(nBits) / 20;
        r->ymax = GetSBits(nBits) / 20;
    }

    void GetMatrix(MATRIX* mat)
    {
        InitBits();
        // Scale terms
        if (GetBits(1)) 
        {
            int nBits = (int)GetBits(5);
            GetSBits(nBits);
            GetSBits(nBits);
            mat->a = mat->d = 1;
        }
        else 
        {
            mat->a = mat->d = 1;
        }

        // Rotate/skew terms
        if (GetBits(1)) 
        {
            int nBits = (int)GetBits(5);
            GetSBits(nBits);
            GetSBits(nBits);
            mat->b = mat->c = 0;
        }
        else 
        {
            mat->b = mat->c = 0;
        }

        {// Translate terms
            int nBits = (int)GetBits(5);
            mat->tx = GetSBits(nBits) / 20;
            mat->ty = GetSBits(nBits) / 20;
        }
    }

    // Routines for reading arbitrary sized bit fields from the stream
    //	always call start bits before gettings bits and do not intermix 
    //	this calls with GetByte, etc...	
    void InitBits() { bitPos = 0; bitBuf = 0; }
    U32 GetBits(int n)	// get n bits from the stream
    {
        U32 v = 0;
        for (;;) 
        {
            int s = n - bitPos;
            if (s > 0) {
                // Consume the entire buffer
                v |= bitBuf << s;
                n -= bitPos;

                // Get the next buffer
                bitBuf = GetByte();
                bitPos = 8;
            }
            else {
                // Consume a portion of the buffer
                v |= bitBuf >> -s;
                bitPos -= n;
                bitBuf &= 0xFF >> (8 - bitPos);	// mask off the consumed bits
                return v;
            }
        }
    }

    S32 GetSBits(int n)	// extend the sign bit
    {
        S32 v = GetBits(n);
        if (v & (1L << (n - 1))) {
            v |= (-1L << n);
        }
        return v;
    }
};

MATRIX MaT = { 0 };
MATRIX* M = &MaT;

int main(int argc, char* argv[])
{
uint32_t  size, len, tagIdx;
int       ret, MEET = 0;
FILE     *fi, *fo;
uint8_t* inbuf = NULL;
uint8_t  *p;
uint32_t *psize;
uint16_t  tagCL, tagId, framecount;
uint32_t  taglen, bmplen, skip, counter;
uint32_t  bmpSize = 0;
SParser     sp;

    if(argc < 2) {
        printf("SWF parser usage: %s swf_file\n", argv[0]);
    }
    
    init_tag();
    
    fi = fopen(argv[1], "rb");
    if(NULL == fi) {
		printf("cannot open swf file [%s]!\n", argv[1]);
        return 0;
    }
    
    fseek(fi, 0L, SEEK_END);
    size = ftell(fi);
    printf("fie size is %d bytes!\n", size);
    
    fseek(fi, 0L, SEEK_SET);
    
    inbuf = (uint8_t*)malloc(size);
    if(NULL == inbuf) {
        printf("Cannot allocate %d bytes memory!\n", size);
        return 0;
    }
   
    ret = fread(inbuf, size, 1, fi);   
	if(1 != ret) {
        printf("Cannot read %d bytes from SWF file!\n", size);
        goto _exit_app;
    }
    fclose(fi);
    
    p = inbuf; 
    if(p[0] != 'F' || p[1] != 'W' || p[2] != 'S' || p[3] != 0x08) {
        printf("Signature is wrong!\n");
        goto _exit_app;
    }
    printf("SWF header is good!\n");
    
    psize = (uint32_t *)(p+4);
    printf("SWF file size is: %d - %d bytes\n", size, *psize);
    
    if(0 == memcmp(p+8, sign0800, 9)) {
        printf("it is 800 X 600 size\n");
    } else if(0 == memcmp(p+8, sign1024, 9)) { 
        printf("it is 1024 X 768 size\n");
    } else {
        printf("demision is not standard size\n");
    }
    
    if(p[17]) { printf(" frame count is wrong! p[17]=%d\n", p[17]); }
    
    printf("frame rate is %d/seconds\n", p[18]);
    framecount = (uint16_t)*(p+20); 
    framecount <<= 8;
    framecount += (uint16_t)*(p+19); 
    printf("frame count is %d\n", framecount);
    framecount = *((uint16_t*)(p+19));
    printf("frame count is %d\n", framecount);
    if(framecount > 16000) {  /* swf is 16000 frames or less */
        printf("Frame Count[%d] is wrong!\n", framecount);
        goto _exit_app;
    }
    
    p = inbuf + 21;  /* p --> the first tag */
    tagIdx = 0;
    uint32_t TAGLEN;
    sp.Attach(inbuf, 21);
    U16 chacterId, w, h, depth;
    U8 bmpFormat, nFills, I, fillStyle;
    SRECT rect;
    do {
        ret = sp.GetTag();
        if(ret < 0) break;
        
        tagId = (U16)ret;
        printf("[%04d] -- [%c][%08d]%s[%d](%d)\n", tagIdx, sp.tagType, (int)(sp.tagPos), tagName[tagId], tagId, sp.tagEnd - sp.pos);

        if(ST_END == tagId) break;
        
        if(ST_DEFINESHAPE3 == tagId) {
            chacterId = sp.GetWord();
            sp.GetRect(&rect);
            nFills = sp.GetByte();
            printf("---> st_DEFINESHAPE3: shapeId=%d ShapeBounds(%d,%d,%d,%d) w=%d, h=%d | nFills=%d\n", chacterId,
                    rect.xmin, rect.xmax, rect.ymin, rect.ymax, (rect.xmax - rect.xmin), (rect.ymax - rect.ymin)
                    ,nFills
                    );
            for(I=1; I<=nFills; I++)
            {
                fillStyle = sp.GetByte();
                if(fillStyle & 0x40) 
                {
                    chacterId = sp.GetWord();
                    sp.GetMatrix(M);
                    printf("  st_DEFINESHAPE3[%d]: fillStyle=%02X, chacterId=%d, Matrix[a=%d, b=%d, c=%d, d=%d, tx=%d, ty=%d]\n",
                                I, fillStyle, chacterId,
                                (int)(M->a), (int)(M->b), (int)(M->c), (int)(M->d), (int)(M->tx), (int)(M->ty));
                }
                else printf("!!!!!!!!!!!!!!!!NOT BITMAP[%d]!!!!!!!!!!!!!!!!!!\n", I);
            }
        }

        if(ST_DEFINEBITSLOSSLESS2 == tagId) {
            chacterId = sp.GetWord(); 
            bmpFormat = sp.GetByte();
            w = sp.GetWord(); 
            h = sp.GetWord();
            printf("---> st_DEFINEBITSLOSSLESS2: chacterId=%d bmpFormat:%d, w=%d, h=%d\n", 
                    chacterId, bmpFormat, w, h);
        }

        if(ST_PLACEOBJECT2 == tagId) {
            fillStyle = sp.GetByte();
            depth = sp.GetWord();
            chacterId = sp.GetWord();
            sp.GetMatrix(M);
            printf("---> st_PLACEOBJECT2: [%02X] chacterId=%04d Depth:%04d, Matrix[a=%d, b=%d, c=%d, d=%d, tx=%d, ty=%d]\n",
                fillStyle, chacterId, depth,
                (int)(M->a), (int)(M->b), (int)(M->c), (int)(M->d), (int)(M->tx), (int)(M->ty));
        }

        sp.GoToNextTag();
        tagIdx++;
    } while(1);
    
#if 0        
    do {
        tagCL = *((uint16_t *)p); /* get the TagCodeAndLength 2 bytes */
        taglen = tagCL & 0x3F;
        tagid  = (tagCL >> 6) & 0x03FF; /* 11 1111,1111*/
        if(0 == g_tag[tagid]) { /* we are sure that the camtasia video only use 13 tags */
            printf("----- Invalid tag: %d\n", tagid);
            goto _exit_app;
        }
        else g_tag[tagid]++; /* we count how many times each tag in the swf file here */
        
        TAGLEN = taglen;
        if(0x3F == taglen) TAGLEN = *((uint32_t*)(p+2)); /* get the next 4 bytes */
        printf("[%04d] -- [%08d]%s[%d](%d)\n", tagIdx, (int)(p - inbuf), tagName[tagid], tagid, TAGLEN);
        
        if(ST_DEFINEBITSLOSSLESS2 == tagid) {
#if 10            
            uint16_t characterid, w, h;
            uint8_t bmpformat;
            characterid = *((uint16_t *)(p+6));
            bmpformat = *(p+8);
            w = *((uint16_t *)(p+9)); h = *((uint16_t *)(p+11));
            printf("----> [%04d]-st_DEFINEBITSLOSSLESS2: characterid=%d, bmpformat=%d, w=%d, h=%d\n",
            tagIdx, characterid, bmpformat, w, h);
            bmpSize += (w*h)<<2;
#endif             
        }

        if(ST_SOUNDSTREAMHEAD2 == tagid) {
#if 0            
            uint8_t b;
            printf("[%d]-ST_SOUNDSTREAMHEAD2: tagid=%d, taglen=%d\n", tagIdx, tagid, taglen);
            /* printf("%2X-%2X-%2X-%2X\n", p[2],p[3],p[4],p[5]); */
            b = (p[2] & 0xF0) >> 4;
            printf("-- Reserved=%d\n", b);
            b = (p[2] & 0x0C) >> 2;
            printf("-- PlaybackSoundRate=%d\n", b);
            b = (p[2] & 0x02) >> 1;
            printf("-- PlaybackSoundSize=%d\n", b);
            b = (p[2] & 0x01);
            printf("-- PlaybackSoundType=%d\n", b);
            b = (p[3] & 0xF0) >> 4;
            printf("-- StreamSoundCompression=%d\n", b);
            b = (p[3] & 0x0C) >> 2;
            printf("-- StreamSoundRate=%d\n", b);
            b = (p[3] & 0x02) >> 1;
            printf("-- StreamSoundSize=%d\n", b);
            b = (p[3] & 0x01);
            printf("-- StreamSoundType=%d\n", b);
            /*
            [9]-ST_SOUNDSTREAMHEAD2: tagid=45, taglen=6
            F-2F-7C- B 
            0000.1111-0010.1111-0111.1100-0000.1011
            */
#endif            
        }

        if(ST_SHOWFRAME == tagid) {
            /* printf("[%d]-ST_SHOWFRAME: tagid=%d, taglen=%d\n", tagIdx, tagid, taglen); */
        }
        
        if(ST_PLACEOBJECT2 == tagid) {
#if 1            
            uint8_t b;
            uint8_t PlaceFlagHasClipActions = 0;
            uint8_t PlaceFlagHasClipDepth = 0;
            uint8_t PlaceFlagHasName = 0;
            uint8_t PlaceFlagHasRatio = 0;
            uint8_t PlaceFlagHasColorTransform = 0;
            uint8_t PlaceFlagHasMatrix = 0;
            uint8_t PlaceFlagHasCharacter = 0;
            uint8_t PlaceFlagMove = 0;
            uint16_t Depth, CharacterId;
            b = p[2];
            PlaceFlagHasClipActions = (0 != (b & 0x80));
            PlaceFlagHasClipDepth = (0 != (b & 0x40));
            PlaceFlagHasName = (0 != (b & 0x20));
            PlaceFlagHasRatio = (0 != (b & 0x10));
            PlaceFlagHasColorTransform = (0 != (b & 0x08));
            PlaceFlagHasMatrix = (0 != (b & 0x04));
            PlaceFlagHasCharacter = (0 != (b & 0x02));
            PlaceFlagMove = (0 != (b & 0x01));
            Depth = *((uint16_t *)(p+3));
            CharacterId = *((uint16_t *)(p+5));
            printf("[%02X]-st_PLACEOBJECT2: Depth=%d CharacterId=%d PlaceFlagHasCharacter=%d PlaceFlagHasMatrix = %d\n"
                    ,b
                    ,Depth, CharacterId
                    ,PlaceFlagHasCharacter
                    ,PlaceFlagHasMatrix);
#endif                     
        }
        
        if(ST_DEFINESHAPE3 == tagid) {
            uint16_t ShapeId;
            if(0x3F == taglen) ShapeId = *((uint16_t *)(p+6));
            else ShapeId = *((uint16_t *)(p+2));
            printf("----> [%04d]-st_DEFINESHAPE3: ShapeId=%d\n",
            tagIdx, ShapeId);
        }
        
        if(ST_SOUNDSTREAMBLOCK == tagid) {
        }
        
        if(ST_SOUNDSTREAMBLOCK == tagid) {
        }
        
        if(ST_SOUNDSTREAMBLOCK == tagid) {
        }
        
        if(ST_SOUNDSTREAMBLOCK == tagid) {
        }
        
        if(ST_SOUNDSTREAMBLOCK == tagid) {
        }
        
        if(0x3F == taglen) 	{ /* it is a long tag */
            skip = 4 + TAGLEN;
        } else {
            skip = taglen;
        }
        p += (skip + 2); /* go to the next tag */
        tagIdx++;
    } while (ST_END != tagid);
    
    if(framecount != g_tag[ST_SHOWFRAME]-1) { /* check the frame count is ok?*/
        printf("The frame count is error![%d] - [%d]\n", framecount, g_tag[ST_SHOWFRAME] - 1);
    }
    
	printf("===== parser successfuly! ======\n");

	printf("g_tag[ST_END] = %d\n", g_tag[ST_END]-1);
	printf("g_tag[ST_SHOWFRAME] = %d\n", g_tag[ST_SHOWFRAME]-1);
	printf("g_tag[ST_SOUNDSTREAMBLOCK] = %d\n", g_tag[ST_SOUNDSTREAMBLOCK]-1);
	printf("g_tag[ST_PLACEOBJECT2] = %d\n", g_tag[ST_PLACEOBJECT2]-1);
	printf("g_tag[ST_DEFINESHAPE3] = %d\n", g_tag[ST_DEFINESHAPE3]-1);
	printf("g_tag[ST_DEFINEBITSLOSSLESS2] = %d\n", g_tag[ST_DEFINEBITSLOSSLESS2]-1);
	printf("g_tag[ST_SOUNDSTREAMHEAD2] = %d\n", g_tag[ST_SOUNDSTREAMHEAD2]-1);
	printf("g_tag[ST_REMOVEOBJECT2] = %d\n", g_tag[ST_REMOVEOBJECT2]-1);
	printf("--------------------------------------------\n");
	printf("g_tag[ST_DOACTION] = %d\n", g_tag[ST_DOACTION]-1);
	printf("g_tag[ST_FRAMELABEL] = %d\n", g_tag[ST_FRAMELABEL]-1);
	printf("g_tag[ST_CAMTASIA] = %d\n", g_tag[ST_CAMTASIA]-1);
	printf("g_tag[ST_FILEATTRIBUTES] = %d\n", g_tag[ST_FILEATTRIBUTES]-1);
	printf("g_tag[ST_METADATA] = %d\n", g_tag[ST_METADATA]-1);
    
    printf("bmpSize is %d bytes = %d MB\n", bmpSize, bmpSize>>20);
#endif
    
_exit_app:
	if(NULL != inbuf) free(inbuf);
    return 0;
}
