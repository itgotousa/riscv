/****************************************************************************
CONFIDENTIAL AND PROPRIETARY INFORMATION.  The entire contents of this file
is Copyright ?Macromedia, Inc. 1993-1998, All Rights Reserved.  This
document is an unpublished trade secret of Macromedia, Inc. and may not be
viewed, copied or distributed by anyone, without the specific, written
permission of Macromedia, Inc. 
****************************************************************************/

/****************************************************************************
Porting Version of Flash 4 SDK
Middlesoft, Inc. October 1999
Release 10/22/1999 Lee Thomason, lee@middlesoft.com 
****************************************************************************/

#ifndef _NATIVEPLAYERWND_H_
#define _NATIVEPLAYERWND_H_

#include "..//splayer.h"
#include "..//mboolib.h"

/*!
*	The NativePlayerWnd is the link between the OS messages/events and Flash. 
*	It is the main objects, and creates or aggregrates almost all of the 
*	Flash player.
*	<br>
*	In addition to the functions implemented below, NativePlayerWnd needs
*	to react to menu selection (if relevant to your version of the player). Also,
*	a SetMenuState call can be used at any time to trigger a EnableMenus call.
*	The menus, and the resulting calls, are as follows:
*	<br>
*		FILE MENU:<br>
*		Open calls ControlOpen( char* filenameToOpen )<br>
*		Close calls ControlClose()<br>
*		Exit handled by native code.<br>
*		CONTROL MENU: <br>
*		Play calls ControlPlay()<br>
*		StepForward calls ControlForward()<br>
*		StepBack calls ControlBack()<br>
*/
class NativePlayerWnd : public SPlayer 
{
public:	
	CallBackProc callback_func;
	LPVOID uData;
	char *watermark;
	int watermark_len;

	/*! */
	NativePlayerWnd();	
	/*! */
	~NativePlayerWnd();	

	/*! There are two timers:<br>
	*	1. PlayTimer, which fires every frame to redraw, and <br>
	*	2. CursorTimer, which causes the edit text cursor to blink.<br>
	*	How the timers work is left completely up to the implementation. When the PlayerTimer fires, it 
	*  calls DoPlay( true ). When the CursorTimer fires, it calls BlinkCursor(). 
	*  The time passed in to StartTimer is in milliseconds.
	*/
	virtual BOOL StartTimer( int playTimerInterval);
	/*! Stops both timers. */
	virtual void StopTimer();													

	/*! Screen function to get the size of the client window (The client window is the
	*  drawing area for Flash) into SRECT. NOTE: the returned rectangle
	*	must be 0 based. (That is xmin == ymin == 0.)
	*/
	virtual void ClientRect( SRECT* );

	/*! Flash uses this call to request a cursor shape change. Update Cursor
	*	calls GetCursorType() to get the description of the current cursor type.
	*/
	virtual BOOL UpdateCursor();	

	/*! Requests an OS repaint message be sent for the (0 based) SRECT passed in.
	*	It is acceptabe to generate a message for the entire client window.
	*/
	virtual void InvalidateScreenArea( SRECT* );

	/*! Screen function to set the size of the client window. (The client window is the
	*  drawing area for Flash.) If you have a fixed size window, meaning your client 
	*  window can't or doesn't want to change size, this call should do nothing.
	*/
	virtual void AdjustWindow( int width, int height );

	/*! Streaming function. See the SPlayer::StreamPostURLNotify
	*	reference for a full description. Note that the post is not
	*	supported, at this time, in the demo version.
	*/
	virtual void StreamPostURLNotify(	const char* url, 
		const char* window,
		U32			len, 
		const char* buf, 
		void*		notifyData )	
	{}

	/*! Streaming function. See the SPlayer::StreamGetURLNotify
	*	reference for a full description.
	*/
	virtual void StreamGetURLNotify(	const char* url,
		const char* lpData = NULL,
		const DWORD dwLen = 0
		);

	// ------ Public methods used by Win32				    --------
	// ------ These are NOT part of the standard interface. --------
	void initialize( HWND hwnd );

	HDC  GetNWindowDC();				// This is a call for the Flash code to use
	void ReleaseWindowDC()		{}		// This is a call for the Flash code to use

	void SetDC( HDC dc ) { windowDC = dc; }  // Only for use by the Window Message Handler

	int Width()					{ SRECT rect; ClientRect( &rect ); return ( rect.xmax - rect.xmin + 1 ); } 
	int Height()				{ SRECT rect; ClientRect( &rect ); return ( rect.ymax - rect.ymin + 1 ); }

	bool PlayTimerFire();

protected:
	HPALETTE idealPalette;
	HCURSOR	cursorArrow;
	HWND hwnd;
	int playTimer;
	HDC windowDC;
};

#define MBOOLIBWINDOWCLASS "MBoo_Lib_Window_Class"

ATOM				MBLRegisterClass(HINSTANCE hInstance);
BOOL				MBLCreateWindow(DWORD dwStyle, int x, int y, int nWidth, int nHeight, HWND hWndParent, HINSTANCE hInstance, HWND *hwndMBL);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);

typedef struct MBOO_WINCLASS {
	NativePlayerWnd* flashWin;
}MBOO_WINCLASS;

#endif
