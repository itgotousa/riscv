// Version information.

#define PLATFORM_STRING "WIN"

// The 1000+ 3rd paremeter indicates a porting build.
#define MAJOR_VERSION "4"
#define MINOR_VERSION "1001"
#define VERSION_STRING MAJOR_VERSION "." MINOR_VERSION
