/****************************************************************************
CONFIDENTIAL AND PROPRIETARY INFORMATION.  The entire contents of this file
is Copyright ?Macromedia, Inc. 1993-1998, All Rights Reserved.  This
document is an unpublished trade secret of Macromedia, Inc. and may not be
viewed, copied or distributed by anyone, without the specific, written
permission of Macromedia, Inc. 
****************************************************************************/

/****************************************************************************
  Porting Version of Flash 4 SDK
  Middlesoft, Inc. October 1999
  Release 10/22/1999 Lee Thomason, lee@middlesoft.com 
****************************************************************************/
#include "../stdafx.h"
#include "version.h"

#include "playerwnd.h"

#include "../global.h"
#include "../stags.h"
#include "../sobject.h"
#include "../memcop.h"

#include "util.h"

#include "stdio.h"
#include "../mboolib.h"

#define MAX_LOADSTRING 100
#define TIMER_PLAY		1

//
//  FUNCTION: MBLRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage is only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM MBLRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= NULL;
	wcex.hCursor		= NULL;
	wcex.hbrBackground	= NULL; 
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= MBOOLIBWINDOWCLASS;
	wcex.hIconSm		= NULL;

	return RegisterClassEx(&wcex);
}

//
//   FUNCTION: InitInstance(HANDLE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL MBLCreateWindow(DWORD dwStyle, int x, int y, int nWidth, int nHeight, HWND hWndParent, HINSTANCE hInstance, HWND *hwndMBL)
{
   HWND hWnd;

//   if ((nWidth == 800 && nHeight == 600) || (nWidth == 1024 && nHeight == 768))
		hWnd = CreateWindowA(MBOOLIBWINDOWCLASS, NULL, dwStyle,
			x, y, nWidth, nHeight, hWndParent, NULL, hInstance, NULL);
//   else 
//	   hWnd = NULL;

   if (!hWnd)
   {
      *hwndMBL = NULL;
      return FALSE;
   }

   ShowWindow(hWnd, 1);
   UpdateWindow(hWnd);
   
   *hwndMBL = hWnd;
   return TRUE;
}

static NativePlayerWnd* GetFlashWin(HWND hWnd)
{
	NativePlayerWnd* flashWin;
	MBOO_WINCLASS* mWinClass;

	LONG_PTR plptrWin = GetWindowLongPtr(hWnd, GWLP_USERDATA);
	if (plptrWin == NULL) {
		exit(0);
	}
	mWinClass = (MBOO_WINCLASS*)plptrWin;
	flashWin = mWinClass->flashWin;
	return flashWin;
}

//
//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	NativePlayerWnd* flashWin;

	int wmId;
	PAINTSTRUCT ps;

	switch (message) 
	{
		case WM_TIMER:
			flashWin = GetFlashWin(hWnd);
			flashWin->SetDC( GetDC( hWnd ) );			// the mouse sometimes causes a draw

			wmId = wParam;             // timer identifier 
			if ( wmId == TIMER_PLAY ) {
				bool atEnd = flashWin->PlayTimerFire();
				if (atEnd && flashWin->callback_func) {
					flashWin->Suspend();
					flashWin->callback_func(hWnd, MBL_END, wParam, lParam, flashWin->uData);
				}
			} else
				FLASHASSERT( 0 );

			ReleaseDC( hWnd, flashWin->GetNWindowDC() );
			flashWin->SetDC( 0 );			// the mouse sometimes causes a draw
			break;

		case WM_CREATE:
			{
				flashWin = new NativePlayerWnd();
				flashWin->initialize( hWnd );
				MBOO_WINCLASS* mWinClass = (MBOO_WINCLASS*)malloc(sizeof(MBOO_WINCLASS));
				if(NULL == mWinClass) {
					return DefWindowProc(hWnd, message, wParam, lParam);
				}
				mWinClass->flashWin = flashWin;
				SetWindowLongPtr(hWnd, GWL_USERDATA,(LONG)(LONG_PTR)mWinClass);
//				flashWin->ControlOpen("c:\\bbk5648.bwf");
			}
			break;

		case WM_DESTROY:
			flashWin = GetFlashWin(hWnd);
			PostQuitMessage(0);
			delete flashWin;
			flashWin = 0;
			break;

		case WM_PAINT:
			flashWin = GetFlashWin(hWnd);
			flashWin->SetDC( BeginPaint(hWnd, &ps) );

			SRECT rect;
			rect.xmin = ps.rcPaint.left;
			rect.ymin = ps.rcPaint.top;
			rect.xmax = ps.rcPaint.right;
			rect.ymax = ps.rcPaint.bottom;
			
			flashWin->Repaint( &rect );

			flashWin->SetDC( 0 );
			EndPaint(hWnd, &ps);
			return 0;

		case WM_SIZE:
			flashWin = GetFlashWin(hWnd);
			flashWin->FreeBuffer();
			break;

		case WM_SETCURSOR: 
			{
				flashWin = GetFlashWin(hWnd);
				int nHittest = LOWORD(lParam);
				if ( nHittest == HTCLIENT && flashWin->UpdateCursor() )
					return true;
				else
					return DefWindowProc(hWnd, message, wParam, lParam);
			} 
			break;				
		case WM_KEYDOWN:
		case WM_CHAR:
		case WM_MOUSEMOVE:
		case WM_LBUTTONDOWN:
		case WM_LBUTTONUP:
		case WM_RBUTTONDOWN: 
		case WM_RBUTTONUP:
		case WM_LBUTTONDBLCLK:
		case WM_RBUTTONDBLCLK:
			{
				flashWin = GetFlashWin(hWnd);
				if (flashWin->callback_func)
					flashWin->callback_func(hWnd, message, wParam, lParam, flashWin->uData);
			}
			break;
		case WM_ACTIVATEAPP:
			{
				if ( BOOL( wParam ) )
				{
					HPALETTE hPalIdeal = NativePalette::CreateIdentityPalette( hWnd );
					HDC hDC = GetDC(hWnd);

					// Realize our ideal palette to be sure all the colors are used in the device palette
					HPALETTE hOldPal = SelectPalette(hDC, hPalIdeal, FALSE);
					RealizePalette(hDC);

					// Restore the old palette
					SelectPalette(hDC, hOldPal, TRUE);
					
					ReleaseDC(hWnd, hDC);
					DeleteObject(hPalIdeal);
				}
			}
			break;
			
		case MBL_PUTMOVIEFROMMEMORY:
			{
				flashWin = GetFlashWin(hWnd);
				MBLPutMovieFromMemory* info = (MBLPutMovieFromMemory*)lParam;

				flashWin->ControlMemory((char*)info->lpData, info->dwSize, info->dwNew);
			}
			break;
		case MBL_LOADMOVIE:
			{
				flashWin = GetFlashWin(hWnd);
				MBLLoadMovie* info = (MBLLoadMovie*)lParam;

				flashWin->ControlOpen((char *)info->lpData);
			}
			break;
		case MBL_LOADWATERMARK:
			{
				flashWin = GetFlashWin(hWnd);
				MBLLoadWatermark* info = (MBLLoadWatermark*)lParam;
				flashWin->watermark_len = strlen((const char *)(info->lpData));

				if ( flashWin->watermark_len > 0) {
					flashWin->watermark = (char *)malloc(flashWin->watermark_len + 1);
					memset(flashWin->watermark, 0, flashWin->watermark_len + 1);
					if (flashWin->watermark)
						strncpy(flashWin->watermark, (const char *)(info->lpData), flashWin->watermark_len);
				} else {
					if (flashWin->watermark)
						free(flashWin->watermark);
					flashWin->watermark = NULL;
				}
			}
			break;
		case MBL_PLAY:
			{
				flashWin = GetFlashWin(hWnd);
				MBLPlay* mbl_play = (MBLPlay*)lParam;

				BOOL loaded = flashWin->IsLoaded();
				if (loaded) {
					flashWin->Run();
					flashWin->Play();
					mbl_play->hr = S_OK;
				}
			}
			break;
		case MBL_STOP:
			{
				flashWin = GetFlashWin(hWnd);
				MBLStop* mbl_stop = (MBLStop*)lParam;

				BOOL loaded = flashWin->IsLoaded();
				if (loaded) {
					flashWin->GotoFrame(0);
					flashWin->StopPlay();
					mbl_stop->hr = S_OK;
				}
			}
			break;
		case MBL_PAUSE:
			{
				flashWin = GetFlashWin(hWnd);
				MBLPause* mbl_pause = (MBLPause*)lParam;
				
				BOOL loaded = flashWin->IsLoaded();
				if (loaded) {
					flashWin->StopPlay();
					mbl_pause->hr = S_OK;
				}
			}
			break;
		case MBL_GOTOFRAME:
			{
				flashWin = GetFlashWin(hWnd);
				MBLGotoFrame* mbl_gotoframe = (MBLGotoFrame*)lParam;

				BOOL loaded = flashWin->IsLoaded();
				if (loaded) {
					flashWin->GotoFrame(mbl_gotoframe->FrameNum);
					mbl_gotoframe->hr = S_OK;
				}
			}
			break;
		case MBL_SETVOLUME:
			{
				flashWin = GetFlashWin(hWnd);
				MBLSetVolume* mbl_setvolume = (MBLSetVolume*)lParam;

				BOOL loaded = flashWin->IsLoaded();
				if (loaded) {
					DWORD dwVolume;
					dwVolume = (DWORD)(mbl_setvolume->lVolume + (mbl_setvolume->rVolume));
					waveOutSetVolume(0,dwVolume);
					mbl_setvolume->hr = S_OK;
				}
			}
			break;
		case MBL_ENABLESOUND:
			{
				flashWin = GetFlashWin(hWnd);
				MBLEnableSound* mbl_enablesound = (MBLEnableSound*)lParam;

				flashWin->ControlSound(mbl_enablesound->enabled);
				mbl_enablesound->hr = S_OK;
			}
			break;
		case MBL_SETCALLBACK:
			{
				flashWin = GetFlashWin(hWnd);
				MBLSetCallBack* mbl_setcallback = (MBLSetCallBack*)lParam;

				flashWin->callback_func = (CallBackProc)mbl_setcallback->callbackFunc;
				flashWin->uData = mbl_setcallback->uData;
				mbl_setcallback->hr = S_OK;
			}
			break;
		case MBL_CURRENTFRAME:
			{
				flashWin = GetFlashWin(hWnd);
				MBLCurrentFrame* mbl_currentframe = (MBLCurrentFrame*)lParam;

				BOOL loaded = flashWin->IsLoaded();
				if (loaded) {
					mbl_currentframe->currentFrame = flashWin->CurrentFrame();
					mbl_currentframe->hr = S_OK;
				}
			}
			break;
		case MBL_TOTALFRAMES:
			{
				flashWin = GetFlashWin(hWnd);
				MBLTotalFrames* mbl_totalframes = (MBLTotalFrames*)lParam;

				BOOL loaded = flashWin->IsLoaded();
				if (loaded) {
					mbl_totalframes->totalFrames = flashWin->TotalFrames();
					mbl_totalframes->hr = S_OK;
				}
			}
			break;
		case MBL_GETVIDEOSIZE:
			{
				flashWin = GetFlashWin(hWnd);
				MBLGetVideoSize* mbl_getvideosize = (GetVideoSize*)lParam;
				SRECT frame;

				BOOL loaded = flashWin->IsLoaded();
				if (loaded) {
					flashWin->GetVideoSize(&frame);
					mbl_getvideosize->xmax = frame.xmax;
					mbl_getvideosize->ymax = frame.ymax;
					mbl_getvideosize->hr = S_OK;
				}
			}
			break;
		case MBL_GETFRAMERATE:
			{
				flashWin = GetFlashWin(hWnd);
				MBLGetFrameRate* mbl_getframerate = (MBLGetFrameRate*)lParam;

				BOOL loaded = flashWin->IsLoaded();
				if (loaded) {
					mbl_getframerate->frameRate = flashWin->GetFrameRate();
					mbl_getframerate->hr = S_OK;
				}
			}
			break;
		case MBL_ISMUTE:
			{
				flashWin = GetFlashWin(hWnd);
				MBLIsMute* mbl_ismute = (MBLIsMute*)lParam;

				BOOL loaded = flashWin->IsLoaded();
				if (loaded) {
					BOOL ismute = flashWin->IsMute();
					if (ismute)
						mbl_ismute->isMute = 1;
					else
						mbl_ismute->isMute = 0;
					mbl_ismute->hr = S_OK;
				}
			}
			break;
		case MBL_ISPLAYING:
			{
				flashWin = GetFlashWin(hWnd);
				MBLIsPlaying* mbl_isplaying = (MBLIsPlaying*)lParam;

				BOOL loaded = flashWin->IsLoaded();
				if (loaded) {
					BOOL isplaying = flashWin->IsPlaying();
					if (isplaying)
						mbl_isplaying->isPlaying = 1;
					else
						mbl_isplaying->isPlaying = 0;
					mbl_isplaying->hr = S_OK;
				}
			}
			break;
		case MBL_HAVINGVIDEO:
			{
				flashWin = GetFlashWin(hWnd);
				MBLHavingVideo* mbl_havingvideo = (MBLHavingVideo*)lParam;

				BOOL loaded = flashWin->IsLoaded();
				if (loaded)
					mbl_havingvideo->havingVideo = 1;
				else
					mbl_havingvideo->havingVideo = 0;
				mbl_havingvideo->hr = S_OK;
			}
			break;
		case MBL_CLOSEVIDEO:
			{
				flashWin = GetFlashWin(hWnd);
				MBLCloseVideo* mbl_closevideo = (MBLCloseVideo*)lParam;

				BOOL loaded = flashWin->IsLoaded();
				if (loaded) {
					flashWin->ControlClose();
					mbl_closevideo->hr = S_OK;
				}
			}
			break;
 		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

//-----------------------------------------------------------------------------
// So much for the Windows stuff. NativePlayerWnd follows.
//-----------------------------------------------------------------------------

NativePlayerWnd::NativePlayerWnd()
{
	hwnd = 0;
	callback_func = NULL;
	uData = NULL;
	watermark = NULL;
	watermark_len = 0;
}

NativePlayerWnd::~NativePlayerWnd()
{
	ClearScript();
}

void NativePlayerWnd::initialize( HWND _hwnd )
{
	hwnd = _hwnd;

	cursorArrow		= LoadCursor( NULL, IDC_ARROW );
	ClientRect(&player.frame);
}

bool NativePlayerWnd::PlayTimerFire()
{
	DoPlay( true );

	if (player.curFrame + 1 == player.numFrames) {
		return true;
	} else {
		return false;
	}
}

void NativePlayerWnd::ClientRect( SRECT* rect )
{
	RECT r;

	if ( hwnd )
	{
		GetClientRect( hwnd, &r );

		rect->xmin = 0;
		rect->xmax = r.right - r.left;
		rect->ymin = 0;
		rect->ymax = r.bottom - r.top;
	}
	else
	{
		memset( rect, 0, sizeof( SRECT ) );
	}
	FLASHASSERT( r.bottom >= r.top );
}

void NativePlayerWnd::InvalidateScreenArea( SRECT* )
{
	// the simple solution is too send a repaint for the whole thing
	InvalidateRect( hwnd, NULL, false );
}

void NativePlayerWnd::AdjustWindow( int width, int height )
{	
	return;
	SetWindowPos( hwnd, NULL, 0, 0, width, height, SWP_NOZORDER | SWP_NOMOVE );
}

BOOL NativePlayerWnd::StartTimer( int playTimerInterval)
{
	if ( !loaded ) 
		return false;

	FLASHASSERT( playTimerInterval );
	
	playTimer = SetTimer( hwnd, TIMER_PLAY, playTimerInterval, 0 );
	return true;	
}

void NativePlayerWnd::StopTimer()
{
	KillTimer( hwnd, playTimer );
}

BOOL NativePlayerWnd::UpdateCursor()
{
	SetCursor( cursorArrow );
	return true;
}

HDC NativePlayerWnd::GetNWindowDC()
{
	FLASHASSERT( windowDC );
	return windowDC;
}

void NativePlayerWnd::StreamGetURLNotify(	const char* url,
											const char* lpData,
											const DWORD dwLen)
{
	if (url) {
		// We now have an fname that may or may not be a valid file. Try to open it:
		FILE* fp = fopen( url, "rb" );
		if ( fp )
		{
				StreamData streamData;
				char block[256];
				int  read;

				StreamInNew(&streamData);
				while ( read = fread( block, 1, 256, fp ) )
				{
					StreamInWrite( &streamData, &block, read, false);
				}
				StreamInDestroy( &streamData );
				fclose(fp);
		}
	} else {
			StreamData streamData;

			StreamInNew(&streamData);
			StreamInWrite( &streamData, (void *)lpData, dwLen, true);
			StreamInDestroy( &streamData );
	}
} 