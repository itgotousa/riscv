//=====================================================================================================
#ifndef _MBOOLIB_
#define _MBOOLIB_
//=====================================================================================================

#include "Windows.h"

//=====================================================================================================
#ifdef __cplusplus
extern "C" {
#endif
//=====================================================================================================

//=====================================================================================================
// MBoo Lib messages

#define MBL_FIRST           (WM_USER + 0x1000)     

typedef struct MBLPutMovieFromMemory
{
    // [in]
    LPVOID lpData;
    // [in]
    DWORD dwSize;
	// [in]
	DWORD dwNew;

} MBLPutMovieFromMemory;

#define MBL_PUTMOVIEFROMMEMORY                 (MBL_FIRST + 1)


//================================================================================
// Method: Play
// Return type: void

typedef struct MBLPlay
{
	// [out]
	HRESULT hr;

} MBLPlay;

#define MBL_PLAY		(MBL_FIRST + 2)

//================================================================================

//================================================================================
// Method: Stop
// Return type: void

typedef struct MBLStop
{
	// [out]
	HRESULT hr;

} MBLStop;

#define MBL_STOP		(MBL_FIRST + 3)

//================================================================================


//================================================================================
// Method: StopPlay
// Return type: void

typedef struct MBLPause
{
	// [out]
	HRESULT hr;

} MBLPause;

#define MBL_PAUSE		(MBL_FIRST + 4)

//================================================================================

//================================================================================
// Method: GotoFrame
// Return type: void

typedef struct MBLGotoFrame
{
	// [in] FrameNum
	long FrameNum;

	// [out]
	HRESULT hr;

} MBLGotoFrame;

#define MBL_GOTOFRAME		(MBL_FIRST + 5)

//================================================================================

//================================================================================
// Method: CurrentFrame
// Return type: long

typedef struct MBLCurrentFrame
{
	// [out, retval]
	long currentFrame;

	// [out]
	HRESULT hr;

} MBLCurrentFrame;

#define MBL_CURRENTFRAME		(MBL_FIRST + 6)

//================================================================================
// Method: TotalFrame
// Return type: long

typedef struct MBLTotalFrames
{
	// [out, retval]
	long totalFrames;

	// [out]
	HRESULT hr;

} MBLTotalFrames;

#define MBL_TOTALFRAMES		(MBL_FIRST + 7)

typedef struct MBLLoadMovie
{
    // [in]
    LPVOID lpData;

} MBLLoadMovie;

#define MBL_LOADMOVIE                 (MBL_FIRST + 8)

//================================================================================
// Method: EnableSound
// Return type: void

typedef struct MBLEnableSound
{
	// [in] FrameNum
	long enabled;

	// [out]
	HRESULT hr;

} MBLEnableSound;

#define MBL_ENABLESOUND		(MBL_FIRST + 9)

//================================================================================
// Method: EnableSound
// Return type: void

typedef struct MBLSetCallBack
{
	// [in] FrameNum
	LPVOID callbackFunc;
	LPVOID uData;

	// [out]
	HRESULT hr;

} MBLSetCallBack;

#define MBL_SETCALLBACK		(MBL_FIRST + 10)

//================================================================================
// Method: GetVideoSize
// Return type: long
typedef struct GetVideoSize
{
	// [out, retval]
	long xmax;
	long ymax;

	// [out]
	HRESULT hr;

} MBLGetVideoSize;

#define MBL_GETVIDEOSIZE		(MBL_FIRST + 11)

//================================================================================
// Method: GetFrameRate
// Return type: long
typedef struct GetFrameRate
{
	// [out, retval]
	long frameRate;

	// [out]
	HRESULT hr;

} MBLGetFrameRate;

#define MBL_GETFRAMERATE		(MBL_FIRST + 12)

//================================================================================
// Method: IsMute
// Return type: long
typedef struct IsMute
{
	// [out, retval]
	long isMute;

	// [out]
	HRESULT hr;

} MBLIsMute;

#define MBL_ISMUTE		(MBL_FIRST + 13)

//================================================================================
// Method: IsPlaying
// Return type: long
typedef struct IsPlaying
{
	// [out, retval]
	long isPlaying;

	// [out]
	HRESULT hr;

} MBLIsPlaying;

#define MBL_ISPLAYING		(MBL_FIRST + 14)

//================================================================================
// Method: HavingVideo
// Return type: long
typedef struct HavingVideo
{
	// [out, retval]
	long havingVideo;

	// [out]
	HRESULT hr;

} MBLHavingVideo;

#define MBL_HAVINGVIDEO		(MBL_FIRST + 15)

//================================================================================
// Method: CloseVideo
// Return type: long
typedef struct CloseVideo
{
	// [out]
	HRESULT hr;

} MBLCloseVideo;

#define MBL_CLOSEVIDEO		(MBL_FIRST + 16)

#define MBL_END		(MBL_FIRST + 17)

//================================================================================
// Method: SetVolume
// Return type: void

typedef struct MBLSetVolume
{
	// [in] FrameNum
	long lVolume;
	long rVolume;

	// [out]
	HRESULT hr;

} MBLSetVolume;

#define MBL_SETVOLUME		(MBL_FIRST + 18)

//================================================================================
// Method: LoadWatermark
// Return type: void
typedef struct MBLLoadWatermark
{
    // [in]
    LPVOID lpData;

} MBLLoadWatermark;

#define MBL_LOADWATERMARK                 (MBL_FIRST + 19)
//================================================================================

typedef LRESULT (*CallBackProc)(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam, LPVOID udata);

//================================================================================
BOOL WINAPI RegisterMBLWindowClass(HINSTANCE hInstance);

HRESULT WINAPI MBL_Play(/* in */ HWND hwndMBL);

HRESULT WINAPI MBL_Stop(/* in */ HWND hwndMBL);

HRESULT WINAPI MBL_Pause(/* in */ HWND hwndMBL);

HRESULT WINAPI MBL_GotoFrame(/* in */ HWND hwndMBL, /* in */ WORD FrameNum);

HRESULT WINAPI MBL_TotalFrames(/* in */ HWND hwndMBL, /* out */ WORD* TotalFrames);

HRESULT WINAPI MBL_CurrentFrame(/* in */ HWND hwndMBL, /* out */ WORD* CurrentFrame);

HRESULT WINAPI MBL_EnableSound(/* in */ HWND hwndMBL, /* in */ BOOL Enabled);

HRESULT WINAPI MBL_SetCallBack(/* in */ HWND hwndMBL, /* in */ CallBackProc callback_func, /* in */ LPVOID uData);

HRESULT WINAPI MBL_GetVideoSize(/* in */ HWND hwndMBL, /* out */ UINT* videoSize);

HRESULT WINAPI MBL_GetFrameRate(/* in */ HWND hwndMBL, /* out */ WORD* frameRate);

HRESULT WINAPI MBL_IsMute(/* in */ HWND hwndMBL, /* out */ BOOL* isMute);

HRESULT WINAPI MBL_IsPlaying(/* in */ HWND hwndMBL, /* out */ BOOL* isPlaying);

HRESULT WINAPI MBL_HavingVideo(/* in */ HWND hwndMBL, /* out */ BOOL* havingVideo);

HRESULT WINAPI MBL_CloseVideo(/* in */ HWND hwndMBL);

HRESULT WINAPI MBL_SetVolume(/* in */ HWND hwndMBL, /* in */ DWORD Volume);

HWND WINAPI MBL_CreateWindow(
                       DWORD dwStyle,
                       int x,
                       int y,
                       int nWidth,
                       int nHeight,
                       HWND hWndParent,
                       HINSTANCE hInstance);

BOOL WINAPI MBL_PutMovieFromMemory(HWND hwndFlashPlayerControl, LPVOID lpData, DWORD dwSize, DWORD dwNew);
BOOL WINAPI MBL_LoadMovie(HWND hwndFlashPlayerControl, LPVOID lpData);
BOOL WINAPI MBL_LoadWatermark(HWND hwndFlashPlayerControl, LPVOID lpData);


//=====================================================================================================
#ifdef __cplusplus
}
#endif
//=====================================================================================================

//=====================================================================================================
#endif // !_MBOOLIB_
//=====================================================================================================
