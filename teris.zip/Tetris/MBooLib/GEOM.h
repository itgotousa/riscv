/****************************************************************************
CONFIDENTIAL AND PROPRIETARY INFORMATION.  The entire contents of this file
is Copyright ?Macromedia, Inc. 1993-1998, All Rights Reserved.  This
document is an unpublished trade secret of Macromedia, Inc. and may not be
viewed, copied or distributed by anyone, without the specific, written
permission of Macromedia, Inc. 
****************************************************************************/

#ifndef GEOM_INCLUDED
#define GEOM_INCLUDED

#ifndef FIXED_INCLUDED
#include "fixed.h"
#endif

//
// TYPES
//
#define oneInch 1440L

typedef S32 SCOORD, *P_SCOORD;

typedef struct SPOINT {
	SCOORD x;
	SCOORD y;
} SPOINT, *P_SPOINT;

#define rectEmptyFlag 0x80000000L
typedef struct SRECT {	// Note that a rectangle is considered empty if xmin == rectEmptyFlag
	SCOORD xmin;
	SCOORD xmax;
	SCOORD ymin;
	SCOORD ymax;
} SRECT, *P_SRECT;

enum { // reference points on a rectangle
	rectTopLeft = 0, rectTopRight, rectBottomRight, rectBottomLeft, 
	rectTopCenter, rectCenterRight, rectBottomCenter, rectCenterLeft,
	rectCenter
};

typedef struct MATRIX {
	SFIXED a;
	SFIXED b;
	SFIXED c;
	SFIXED d;
	SCOORD tx;
	SCOORD ty;
} MATRIX, *P_MATRIX;

//
// SPOINT FUNCTIONS
//

//
// Inline Functions
//
inline void PointAverage(P_SPOINT pt1, P_SPOINT pt2, P_SPOINT dst)
{
	dst->x = (pt1->x + pt2->x)>>1;
	dst->y = (pt1->y + pt2->y)>>1;
}

//
// SRECT FUNCTIONS
//
void RectSet(SCOORD xmin, SCOORD ymin, SCOORD xmax, SCOORD ymax, P_SRECT dst);
void RectSetPoint(P_SPOINT pt, P_SRECT dst);
void RectSetEmpty(P_SRECT dst);
void RectValidate(P_SRECT dst);
void RectInset(SCOORD dist, P_SRECT dst);

#define RectIsEmpty(r) ((r)->xmin == rectEmptyFlag)
void RectGetPoint(P_SRECT r, int ref, P_SPOINT pt);
void RectUnion(P_SRECT r1, P_SRECT r2, P_SRECT dst);
void RectUnionPoint(P_SPOINT pt, P_SRECT dst);
void RectIntersect(P_SRECT r1, P_SRECT r2, P_SRECT dst);
BOOL RectTestIntersect(P_SRECT r1, P_SRECT r2);
#define RectWidth(r) ((r)->xmax - (r)->xmin)
#define RectHeight(r) ((r)->ymax - (r)->ymin)

//
// MATRIX FUNCTIONS
//
void MatrixTransformPoint(P_MATRIX m, P_SPOINT p, P_SPOINT dst);
void MatrixTransformRect(P_MATRIX m, P_SRECT r, P_SRECT dst);
void MatrixConcat(P_MATRIX m1, P_MATRIX m2, P_MATRIX dst);
// Given m1 that maps from A to B and m2 that maps from B to C
// Generates dst that maps from A to C

void MatrixInvert(P_MATRIX m, P_MATRIX dst);
void MatrixIdentity(P_MATRIX m);

#endif
