/****************************************************************************
CONFIDENTIAL AND PROPRIETARY INFORMATION.  The entire contents of this file
is Copyright ?Macromedia, Inc. 1993-1998, All Rights Reserved.  This
document is an unpublished trade secret of Macromedia, Inc. and may not be
viewed, copied or distributed by anyone, without the specific, written
permission of Macromedia, Inc. 
****************************************************************************/
//	990325	mnk	"fixed1" -> "fixed_1"


#include <stddef.h>
#include <memory.h>
#include <math.h>

#include "splay.h"

#include "bitbuf.h"
#include "stags.h"
#include "sobject.h"
#include "splayer.h"
#include "memcop.h"
#include NATIVE_SOUND 
#include NATIVE_UTIL

#include "zlib.h"

#include <stdio.h>

//
// Simple Parser
//
int SParser::GetTag(S32 len, ScriptPlayer* p)
{
	tagPos = pos;
	if ( len-pos < 2 ) 
		return -1;	// we need more data before we can process this tag

	tagCode = GetWord();
	if (p->fileType == FILETYPE_BWF) {
		S32 tagLen = (tagCode & 0xfc00) >> 10;
		if ( tagLen == 0x3f ) {
			if ( len-pos < 4 ) {
				pos = tagPos;
				return -1;	// we need more data before we can process this tag
			}
			tagLen = GetDWord();
		}
		tagEnd = pos + tagLen;
		if ( tagEnd > len ) {
			pos = tagPos;
			return -1;	// we need more data before we can process this tag
		}
		tagCode = tagCode & 0x00ff ^ p->Key;
		switch (tagCode) {
			case MB_DEFINEBITSLOSSLESS2:
				tagCode = stagDefineBitsLossless2;
				break;
			case MB_SHOWFRAME:
				tagCode = stagShowFrame;
				break;
			case MB_SOUNDSTREAMBLOCK:
				tagCode = stagSoundStreamBlock;
				break;
			case MB_DEFINESHAPE3:
				tagCode = stagDefineShape3;
				break;
			case MB_PLACEOBJECT2:
				tagCode = stagPlaceObject2;
				break;
			case MB_REMOVEOBJECT2:
				tagCode = stagRemoveObject2;
				break;
			case MB_SOUNDSTREAMHEAD2:
				tagCode = stagSoundStreamHead2;
				break;
			case MB_END:
				tagCode = stagEnd;
				break;
			case MB_DEFINEBITSLOSSLESS:
				tagCode = stagDefineBitsLossless;
				break;
			default:
				tagCode = 1023;
				break;
		}
		return tagCode;
	}
	if (p->fileType == FILETYPE_SWF) {
		S32 tagLen = tagCode & 0x3f;
		if ( tagLen == 0x3f ) {
			if ( len-pos < 4 ) {
				pos = tagPos;
				return -1;	// we need more data before we can process this tag
			}
			tagLen = GetDWord();
		}
		tagEnd = pos + tagLen;
		if ( tagEnd > len ) {
			pos = tagPos;
			return -1;	// we need more data before we can process this tag
		}
		tagCode = tagCode >> 6;
		return tagCode;
	}
	return 0;
}

S32 SParser::GetData(void * data, S32 len)
// returns the actual number of bytes read could 
//	be less than len if we hit the end of a tag
{
 	S32 n = Min(len, tagEnd-pos);
	memcpy(data, script+pos, n);
	pos+=n;
	return n;
}

void SParser::GetRect(SRECT* r)
{
	InitBits();
	int nBits = (int)GetBits(5);
	r->xmin = GetSBits(nBits) / 20;
	r->xmax = GetSBits(nBits) / 20;
	r->ymin = GetSBits(nBits) / 20;
	r->ymax = GetSBits(nBits) / 20;
}

void SParser::GetMatrix(MATRIX* mat)
{
	InitBits();
	// Scale terms
	if ( GetBits(1) ) {
		int nBits = (int)GetBits(5);
		GetSBits(nBits);
		GetSBits(nBits);
		mat->a = mat->d = 1;
	} else {
	 	mat->a = mat->d = 1;
	}

	// Rotate/skew terms
	if ( GetBits(1) ) {
		int nBits = (int)GetBits(5);
		GetSBits(nBits);
		GetSBits(nBits);
		mat->b = mat->c = 0;
	} else {
	 	mat->b = mat->c = 0;
	}

	{// Translate terms
		int nBits = (int)GetBits(5);
		mat->tx = GetSBits(nBits) / 20;
		mat->ty = GetSBits(nBits) / 20;
	}
}

void SParser::InitBits()
{
	bitPos = 0;
	bitBuf = 0;
}

U32 SParser::GetBits(int n)
// get n bits from the stream
{
	U32 v = 0;
	for (;;) {
		int s = n-bitPos;
		if ( s > 0 ) {
			// Consume the entire buffer
			v |= bitBuf << s;
			n -= bitPos;

			// Get the next buffer
			bitBuf = GetByte();
			bitPos = 8;
		} else {
		 	// Consume a portion of the buffer
			v |= bitBuf >> -s;
			bitPos -= n;
			bitBuf &= 0xFF >> (8-bitPos);	// mask off the consumed bits
			return v;
		}
	}
}

S32 SParser::GetSBits(int n)
// Get bits w/ sign extension
{
 	S32 v = GetBits(n);
	if ( v & (1L<<(n-1)) ) {
		v |= -1L << n;
	}
	return v;
}


//
// The Shape Parser
//

SShapeParser::SShapeParser(ScriptPlayer* p, U8 * data, S32 start, MATRIX* m)
{
	raster = 0;
	localColors = 0;
	colorList = &localColors;
	mat = *m;
	layer = 0;
	nLines = nFills = 0;

	// Init the default state
	line = fill[0] = fill[1] = 0;
	curPt.x = curPt.y = 0;
	MatrixTransformPoint(&mat, &curPt, &curPtX);

	// Attach the parser to the script
	player = p; 
	display = p->display;
	SParser::Attach(data, start); 
	FLASHASSERT(player && display);

	fillIndex = fillIndexMem;
	lineIndex = lineIndexMem;
}

SShapeParser::~SShapeParser()
{
	// Free the index mem if they are "large"
	if ( fillIndex != fillIndexMem ) 
		delete [] fillIndex;
 	if ( lineIndex != lineIndexMem ) 
		delete [] lineIndex;

	// Free the colors if we have a local list
	RColor* color = localColors;
 	while ( color ) {
	 	RColor* next = color->nextColor;
		display->FreeColor(color);
		color = next;
	}
}

typedef RColor *PRColor;

void SShapeParser::SetupColor(RColor* color)
// Set up the colors for the current CRaster
{
	if ( !raster ) return;
	   
	//color->raster = raster;
	switch ( color->colorType ) {
		case colorBitmap: {
			// Set up the transforms
			MatrixInvert(&color->bm.savedMat, &color->bm.invMat);

			SBitmapCore* bits = color->bm.bitmap;
			color->transparent = int( bits->transparent );
			color->BuildCache();	// this locks the bitmap so it cannot be purged...
		} break;
	}
	color->BuildCache();
}

BOOL SShapeParser::GetStyles()
{
	FLASHASSERT(!*colorList || (*colorList)->colorType != colorClip);
	{// Get the fills
		nFills = GetByte();
		if ( nFills == 255 ) {
			// We have a "large number"
			nFills = GetWord();
			if ( fillIndex != fillIndexMem ) 
				delete [] fillIndex;
			fillIndex = new PRColor[nFills+1];
			if ( !fillIndex ) {
				fillIndex = fillIndexMem;
				return false;
			}
		}

		fillIndex[0] = 0;
		for ( int i = 1; i <= nFills; i++ ) {
			RColor* color = display->CreateColor();
			if ( !color ) 
				return false;

			color->SetUp(raster);

			color->nextColor = *colorList;
			*colorList = color;
			fillIndex[i] = color;

			color->order = layer + i;
			FLASHASSERT(color->order < 0x10000);

			int fillStyle = GetByte();
			if ( fillStyle & fillBits ) {
				// A bitmap fill
				U16 tag = GetWord();		// the bitmap tag
				GetMatrix(&color->bm.savedMat);	// the bitmap matrix
				SCharacter* ch = player->FindCharacter(tag);

				if ( ch && ch->type == bitsChar ) {
					// We found the bits, set up the color
					color->colorType = colorBitmap;
					color->bm.bitmap = &ch->bits;
					color->bm.bitsStyle = fillStyle;
					player->BuildBits(ch);	// be sure the bits are decompressed and available
				}
			} 
			SetupColor(color);		// the buildcache in this function must be called immediately after BuildBits()
		}
	}
	
	{// Get the lines
		nLines = GetByte();
		if ( nLines == 255 ) {
			// We have a "large number"
			nLines = GetWord();
			if ( lineIndex != lineIndexMem ) 
				delete [] lineIndex;
			lineIndex = new SLine[nLines+1];
			if ( !lineIndex ) {
				lineIndex = lineIndexMem;
				return false;
			}
		}

		lineIndex[0].color = 0;
		lineIndex[0].thickness = 0;
	}

	InitBits();
	nFillBits = (int)GetBits(4);
	nLineBits = (int)GetBits(4);
	return true;
}

BOOL SShapeParser::FreeBilts()
{
	{// Get the fills
		nFills = GetByte();

		for ( int i = 1; i <= nFills; i++ ) {
			int fillStyle = GetByte();
			if ( fillStyle & fillBits ) {
				// A bitmap fill
				U16 tag = GetWord();		// the bitmap tag
				MATRIX mat;
				GetMatrix(&mat);
				SCharacter* ch = player->FindCharacter(tag);

				if ( ch && ch->type == bitsChar ) {
					ch->use--;
					if ((ch->use < 1) && ch->bits.baseAddr) {
						ch->bits.PIFree();
					}
				}
			} 
		}
	}
	
	return true;
}

BOOL SShapeParser::UseBilts()
{
	{// Get the fills
		nFills = GetByte();

		for ( int i = 1; i <= nFills; i++ ) {
			int fillStyle = GetByte();
			if ( fillStyle & fillBits ) {
				// A bitmap fill
				U16 tag = GetWord();		// the bitmap tag
				MATRIX mat;
				GetMatrix(&mat);
				SCharacter* ch = player->FindCharacter(tag);

				if ( ch && ch->type == bitsChar ) {
					ch->use++;
				}
			} 
		}
	}
	
	return true;
}

BOOL SShapeParser::NullBilts()
{
	{// Get the fills
		nFills = GetByte();

		for ( int i = 1; i <= nFills; i++ ) {
			int fillStyle = GetByte();
			if ( fillStyle & fillBits ) {
				// A bitmap fill
				U16 tag = GetWord();		// the bitmap tag
				SCharacter* ch = player->FindCharacter(tag);

				if ( ch && ch->type == bitsChar && ch->bits.baseAddr == 0) {
					return true;
				}
			} 
		}
	}
	
	return false;
}

int SShapeParser::GetEdge(CURVE* c)
{
	BOOL isEdge = (int)GetBits(1);
	if ( !isEdge ) {
		// Handle a state change
		int flags = (int)GetBits(5);

		if ( flags == 0 ) 
			// at end, do nothing
			return eflagsEnd;

		// Process a MoveTo
		if ( flags & eflagsMoveTo ) {
			int nBits = (int)GetBits(5);
			curPt.x = GetSBits(nBits) / 20;
			curPt.y = GetSBits(nBits) / 20;
			MatrixTransformPoint(&mat, &curPt, &curPtX);
		}

		// Get new fill info
		if ( flags & eflagsFill0 ) 
			fill[0] = (int)GetBits(nFillBits);
		if ( flags & eflagsFill1 ) 
			fill[1] = (int)GetBits(nFillBits);

		// Get new line info
		if ( flags & eflagsLine )
			line = (int)GetBits(nLineBits);

		// Check to get a new set of styles for a new shape layer
		if ( flags & eflagsNewStyles ) {
		 	layer += nFills+nLines;
			GetStyles();
		}

		FLASHASSERT(fill[0]<=nFills && fill[1]<=nFills && line<=nLines);	// be sure the styles are loaded

		return flags;

	} else {
		// Create an edge
		c->anchor1 = curPtX;

		c->isLine = (int) GetBits(1);
		if ( c->isLine ) {
			// Handle a line
			int nBits = (int)GetBits(4)+2;	// nBits is biased by 2

			// Save the deltas
			BOOL generalLine = (int)GetBits(1);
			if ( generalLine ) {
				// Handle a general line
				curPt.x += GetSBits(nBits);
				curPt.y += GetSBits(nBits);
			} else {
				// Handle a vert or horiz line
				BOOL vertical = (int)GetBits(1);
				if ( vertical ) {
					// Vertical line
					curPt.y += GetSBits(nBits) / 20;
				} else {
					// Horizontal line
					curPt.x += GetSBits(nBits) / 20;
				}
			}

			MatrixTransformPoint(&mat, &curPt, &c->anchor2);
			PointAverage(&c->anchor1, &c->anchor2, &c->control);

		} else {
		 	// Handle a curve
			int nBits = (int)GetBits(4)+2;	// nBits is biased by 2

			// Get the control
			curPt.x += GetSBits(nBits);
			curPt.y += GetSBits(nBits);

			MatrixTransformPoint(&mat, &curPt, &c->control);

			// Get the anchor
			curPt.x += GetSBits(nBits);
			curPt.y += GetSBits(nBits);

			MatrixTransformPoint(&mat, &curPt, &c->anchor2);
		}

		curPtX = c->anchor2;
		return 0;
	}
}


//
// Script Player
//

ScriptThread::ScriptThread()
{
	script = 0;
	display = 0;
	rootObject = 0;
	layerDepth = 0;

	player = 0;
	next = 0;
    len = 0;
    startPos = 0;

    justSeeked = true;
    justSeekedNegative = false;

	#ifdef SOUND
	needBuffer = true;
	sndChannel = 0;
    snd.Init();
	#endif

	ClearState();
}

ScriptThread::~ScriptThread()
{
	#ifdef SOUND
	StopStream();
	#endif

	if ( display ) 
		display->RemoveThread(this);
}


void ScriptThread::ClearState()
{
	// Reset the script attributes
	curFrame = -1;
	atEnd = false;
	seeking = false;

	len = 0;
	pos = 0;
	script = 0;

	#ifdef SOUND
	StopStream();
	mixFormat = snd22K16Stereo;
	#endif

	numFrames = 0;
	scriptErr = 0;

	playing = true;
}


//
// Handle Specific Tags
//

void ScriptThread::PlaceObject2()
{
	FLASHASSERT(rootObject);

	PlaceInfo info;
	info.flags = GetByte();
	info.depth = GetWord();

	info.character = player->FindCharacter(GetWord());
	GetMatrix(&info.mat);

	display->PlaceObject(rootObject, &info);
}


void ScriptThread::RemoveObject()
{
	if ( tagCode == stagRemoveObject ) // the old style remove has the unneed tag
		SkipBytes(2);					//GetWord();		//U16 tag = 
	U16 depth = GetWord();

	display->RemoveObject(rootObject, depth);

}

void ScriptThread::DefineShape()
{
	U16 tag = GetWord();

	SCharacter* ch = player->CreateCharacter(tag);
	if ( !ch ) return;

	// Set up object
	ch->type = shapeChar;
	ch->tagCode = tagCode;

	// Get the bounds
	GetRect(&ch->bounds);

	// Simply save a pointer to the original data
	ch->data = AttachData(pos, tagEnd);//script+pos;

	MATRIX m;
	SShapeParser parser(player, ch->data, 0, &m);
	parser.UseBilts();
}

void ScriptThread::BuildBits(SCharacter* ch)
{
	if ( !ch->bits.HasBits() ) {
		// Decompress the bits of the bitmap
		ch->bits.PIFree();

		SParser parser;
		parser.Attach(ch->data, 0);
		int code = parser.GetTag(0x1FFFFFFF, player);
		parser.GetWord();	// skip character tag

		switch ( code ) {
			case stagDefineBitsLossless:
			case stagDefineBitsLossless2: {
				// Decompress lossless data
				int err;
				z_stream d_stream; /* decompression stream */

				d_stream.zalloc = (alloc_func)0;
				d_stream.zfree = (free_func)0;
				d_stream.opaque = (voidpf)0;

				{
					int format = parser.GetByte();
					int width = parser.GetWord();
					int height = parser.GetWord();

					// Get the color table size
					int nColors = format <= bm8Bit ? parser.GetByte()+1 : 0;
					{
						err = inflateInit(&d_stream);
						if ( err != 0 ) goto AbortL;

						d_stream.next_in = (Bytef*)parser.script + parser.pos;
						d_stream.avail_in = parser.tagEnd-parser.pos;

						// Get the color table
						SColorTable ctab;

						// Set up the bitmap
						ch->bits.PICreate(format, width, height, format <= bm8Bit ? &ctab : 0, true);
						ch->bits.transparent = code == stagDefineBitsLossless2;

						if ( !ch->bits.HasBits() ) 
							goto AbortL;

						ch->bits.LockBits();
						S32 size = height*ch->bits.rowBytes;
						d_stream.next_out  = (Bytef*)ch->bits.baseAddr;
						d_stream.avail_out = size;
						while ( true ) {
							err = inflate(&d_stream, Z_NO_FLUSH);
							if ( err != Z_OK ) break;
						}
						FLASHASSERT(err==Z_STREAM_END);
						SBitmapSwapBits(ch->bits.baseAddr, size, ch->bits.bmFormat);
						ch->bits.UnlockBits();
					}
				}

			AbortL:
				err = inflateEnd(&d_stream);
				FLASHASSERT(err==0);
			} break;
		}
	}
}

void ScriptThread::DefineBits()
// Create a bitmap
{
	U16 tag = GetWord();

	SCharacter* ch = player->CreateCharacter(tag);
	if ( !ch ) return;

	// Set up object
	ch->type = bitsChar;
	ch->data = AttachData(pos-8, tagEnd);//script+pos-8;

	ch->bits.PIInit();
	ch->use = 0;
	ch->bits.tag = tag;
}

#ifdef SOUND
BOOL ScriptStreamProc(CSoundChannel* channel)
// WARNING: this is called at interupt time on the Mac, don't do any memory allocations...
{
	ScriptThread* thread = (ScriptThread*)(channel->refPtr);
	FLASHASSERT(thread->sndChannel == channel);
	return thread->DoSoundFrame();
}

void ScriptThread::StopStream()
{
	if ( sndChannel ) {
		sndChannel->Stop();
		sndChannel->Release();
		sndChannel = 0;
	}
	needBuffer = (player == this);//true;	// don't start the sound until we have a decent amount loaded (for the streaming thread)
}

void ScriptThread::AdjustMp3Streaming()
{
    if (justSeeked)
    {
        
        justSeeked = false;
        if (sndChannel->blockSamples > 0)
        {
            FLASHASSERT(sndChannel->seekSamples >= 0);
            justSeekedNegative = true;
            AdjustMp3Streaming(); // recurse
        }
        else if (sndChannel->blockSamples == 0 && sndChannel->seekSamples == 0)
        {
            // do nothing here
            return;
        }
        else if (sndChannel->seekSamples < 0)
        {
            justSeekedNegative = true;
            AdjustMp3Streaming(); // recurse
        }
        else
        {
            FLASHASSERT(0);
        }   
    }
    else
    {
        if (justSeekedNegative && sndChannel->blockSamples > 0)
        {
            FLASHASSERT(sndChannel->seekSamples >= 0);
            justSeekedNegative = false;
            sndChannel->blockSamples -= sndChannel->seekSamples;
              
            // throw away the samples that don't belong in this
            // frame. These samples actually belong in the previous
            // frame. If we read ahead one frame we could actually
            // use it (!!@ should we read ahead one frame). But
            // this really should not be noticable by an average
            // human. If you are above average come and talk to me
            // SBL
            sndChannel->decomp->Decompress(0, sndChannel->seekSamples);
        }
            
        if (sndChannel->seekSamples < 0)
            justSeekedNegative = true;
    }
}

BOOL ScriptThread::DoSoundFrame()
// Process the sound commands for the next frame
// WARNING: this is called at interupt time on the Mac, don't do any memory allocations...
{
	FLASHASSERT(sndChannel);

	if ( sndAtEnd ) 
		return false;

	// Check to prebuffer 5 seconds of sound
	// The sound prebuffering amount can be customized through the
	// _soundbuftime property.
	if ( needBuffer ) {
		FLASHASSERT(player == this);	// this should only happen on the main thread

		int soundBufferTime = 5;
		if (player->splayer) {
			soundBufferTime = player->splayer->nSoundBufferTime;
		}
		S32 count = player->frameDelay > 0 ? (soundBufferTime*1000)/player->frameDelay : 100;
		if ( !player->FrameComplete(sndFrame+count) ) {
			return false;
		}
		needBuffer = false;
	}

	SParser savedState = *(SParser*)this;
	while ( true ) {
		pos = sndPos;
		int code = GetTag(len, player);
		if ( code < 0 ) {
			needBuffer = true;			// we ran out so rebuffer the sound
			*(SParser*)this = savedState;
			FLASHASSERT(player == this);	// this should only happen on the main thread
			splayer->theSoundMix.LeaveCritical();
			return player->ScriptComplete();	// return true at the end of the script
		}
		sndPos = tagEnd;	// start at the next pos
		FLASHASSERT(sndPos >= 0);

		switch ( code ) {
			case stagEnd:
				sndAtEnd = true;
				goto Done;
			case stagShowFrame:
				sndFrame++;
				goto Done;
			case stagSoundStreamBlock: {
				// Set up the decompression for the block
                if (snd.CompressFormat() == sndCompressMP3)
                {
				    sndChannel->blockSamples = GetWord();
                    sndChannel->seekSamples = (S16) GetWord();
                    sndChannel->blockCanBeZero = true;
                }
                else
                {
				    sndChannel->blockSamples = snd.nSamples;
                }
				snd.samples = script+pos;
                snd.dataLen = tagEnd - pos;

                if ( sndChannel->decomp )
                {
                    // make sure setup does not skip past delay
                    // with streaming sound we do that manually
                    int delaySav = snd.delay;
                    snd.delay = 0;
					sndChannel->decomp->Setup(&snd, justSeeked);
                    snd.delay = delaySav;
                    
                    // adjust mp3 channel according to the
                    // hind data the outoring has provided
                    if (snd.CompressFormat() == sndCompressMP3)
                        AdjustMp3Streaming();
                }
				else
					sndChannel->pos = 0;
			} break;
		}
	}
Done:
	
	*(SParser*)this = savedState;
	return true;	// we got the block
}

void ScriptThread::SoundStreamHead()
// Set up the stream formats
{
	mixFormat = GetByte();

	// The stream settings
    snd.Init();
	snd.format = GetByte();
	snd.nSamples = GetWord();

	if (snd.CompressFormat() == sndCompressMP3)
    {
        // get the compression delay in samples
        snd.delay = GetWord();
    }
}

void ScriptThread::SoundStreamBlock()
{
	FLASHASSERT(!sndChannel);
	FLASHASSERT(player);
	if ( !playing ) return;
	if ( player->mute ) return;	// the player is muted
	if ( player->splayer && !player->splayer->running ) return; // the splayer is not running
	if ( snd.CompressFormat() > sndCompressNoneI ) return;	// we don't support this compression format

	// Create a new channel
	sndChannel = new CSoundChannel();

	if ( sndChannel ) {
		sndChannel->AddRef();
		sndChannel->sound = &snd;
		sndChannel->samplesPlayed = curFrame > 0 ? snd.nSamples*curFrame : 0;	// adjust the number of samples for the starting frame number
		sndChannel->refPtr = this;
		sndChannel->streamProc = ScriptStreamProc;

		sndAtEnd = false;
		sndFrame = curFrame;
		sndPos = pos-6;	// the start of the tag
		FLASHASSERT(sndPos >= 0);

		splayer->theSoundMix.AddSound(sndChannel);
	}
}
#endif

int ScriptThread::DoTag()
// Process a single tag
{
	{
		// DrawFrame checks these...
		FLASHASSERT(script && !scriptErr);

		if ( atEnd ) 
			return playAtEnd;
		
		splayer->theSoundMix.EnterCritical();
		int code = GetTag(len, player);
		if ( code < 0 ) {
			splayer->theSoundMix.LeaveCritical();
			return playNeedData;	// we need more data before we can process this tag
		}
		switch ( code ) {
			case stagDefineBitsLossless:
			case stagDefineBitsLossless2:
				DefineBits();
				break;
			case stagShowFrame:
				curFrame++;
				break;
			#ifdef SOUND
			case stagSoundStreamBlock:
				if ( !sndChannel && !seeking )
					SoundStreamBlock();
				break;
			#endif
			case stagDefineShape3:
				DefineShape(); 
				break;
			case stagPlaceObject2:
				PlaceObject2();
				break;
			case stagRemoveObject2:
				RemoveObject();
				break;
			#ifdef SOUND			
			case stagSoundStreamHead2:
				SoundStreamHead();
				break;
			#endif
			case stagEnd: 
				atEnd = true;
				break;
			default:
				break;
		}
		pos = tagEnd;
		splayer->theSoundMix.LeaveCritical();
		return scriptErr;
	}
}

int ScriptThread::DoTags(int fnum)
{
	int res = playOK;
	while ( curFrame < fnum && res == playOK ) {
		res = DoTag();
	}
	return res;
}

int ScriptThread::DrawFrame(int fnum, BOOL seek)
{
	if ( scriptErr ) 
		return scriptErr;

	if ( !player->gotHeader ) 
		return playNeedData;

	if ( !rootObject ) {
		// Create a root object on the display for this player
		SCharacter* ch = player->CreateCharacter(ctagThreadRoot);
		if ( ch ) {
			// Set up object
			ch->type = rootChar;
		} else {
			ch = player->FindCharacter(ctagThreadRoot);
		}

		if ( ch ) {
			PlaceInfo info;
			info.flags = splaceCharacter;
			MatrixIdentity(&info.mat);	
			info.depth = layerDepth;
			info.character = ch;
			rootObject = display->PlaceObject(&display->root, &info);
		}
		if ( !rootObject )
			return noMemErr;
	}

	int res = playOK;
	if ( seek ) {
		if ( curFrame > fnum ) {
			// Seek backwards

			// Rewind the movie...
			pos = startPos;		// seek to the beginning
			curFrame = -1;
			atEnd = false;
		
			// Marks all objects to be removed unless they are added again
		 	rootObject->FreeChildren();
			
	{// Free the characters
		SCharacter** index = player->charIndex;
		for ( int i = 0; i < player->charIndexSize; i++, index++ ) {
			SCharacter* ch = *index;
			while ( ch ) {
				SCharacter* nextChar = ch->next;
				if (ch->bits.baseAddr == NULL)
					player->FreeCharacter(ch);
				ch = nextChar;
			}
			*index = 0;
		}
	}
			// Skip over frames
			seeking = true;
            justSeeked = true;      // tell mp3 sound stream to adjust itself
			res = DoTags(fnum-1);
			seeking = false;

			// Do the destination frame
			res = DoTags(fnum);

		} else {

			// Skip over frames
			seeking = true;
            justSeeked = true;      // tell mp3 sound stream to adjust itself
			res = DoTags(fnum-1);
			seeking = false;

			// Do the destination frame
			res = DoTags(fnum);
		}
	} else {
		// Build the frame
		res = DoTags(fnum);
	}

	return res;
}

// delta & bForceRebuild are optional parameters added for the
// flash asset xtra. they are never used by the flash player, 
// so in flash, delta = 1 and bForceRebuild = false.
void ScriptThread::DoFrame(int delta, BOOL bForceRebuild)
{
	if (!playing && !bForceRebuild)
		return;

	int thisFrame = GetFrame();				// !!sprite_xtra
	int frameNum =  thisFrame + delta;

	// Check to stall if the next frame is not loaded
	if ( this == player && frameNum > player->numFramesComplete ) {
		frameNum = player->numFramesComplete;
	}

	int res;
	
	if (bForceRebuild)
	{
		// we do not advance in the forceRebuild case either.
		curFrame = thisFrame + 1;   // hack to get it to rewind, forcing rebuild of frame
 		res = DrawFrame(thisFrame /* + delta */, true);
	}
	else
		res = DrawFrame(frameNum, false);

	if ( res == ScriptPlayer::playNeedData ) {
		return;
	} else if ( res < ScriptPlayer::noErr ) {
		// We got an error, let the thread terminate
		#ifdef SOUND
		StopStream();
		#endif
		playing = false;
		return;
	} else if ( res == ScriptPlayer::playAtEnd ) {
		#ifdef SOUND
		StopStream();
		#endif
		playing = false;
	}
}

// Start and stop the main layer
void ScriptThread::Play(BOOL rewind)
{
    // tell mp3 sound stream to adjust itself
    justSeeked = true;

	// Rewind if they are at the end
	if ( rewind && curFrame >= numFrames-1 )
		Seek(0);

	playing = true;
}

void ScriptThread::StopPlay()
{
	playing = false;

	#ifdef SOUND
	StopStream();
	#endif
}

void ScriptThread::Seek(int f)
{
	StopPlay();
	if ( f < 0 ) 
		f = 0;
	DrawFrame(f, true);
	Play();
}

//
// Script Player
//

ScriptPlayer::ScriptPlayer() : 
				characterAlloc(sizeof(SCharacter), 32, true, 0x66666666)
{
	player = this;

	bFileScript = false;

	memset(charIndex, 0, sizeof(charIndex));
	version = 0;

	splayer = 0;
	nextLayer = 0;
	stream = 0;
    scriptRefCount = 0;

	#ifdef SOUND
	mute = false;
	#endif
	
	startPos = 0;
	len = 0;
	ClearScript();
}

ScriptPlayer::~ScriptPlayer()
{
	ClearScript();
}


void ScriptPlayer::FreeCharacter(SCharacter* c)
{
	ReleaseData(c->data);
	switch ( c->type ) {
		case bitsChar: {
			// Free the uncompressed bitmap
			c->bits.PIFree();
		} break;

		#ifdef SOUND
		case soundChar: {
			// Stop the sound if it is playing
			splayer->theSoundMix.FreeSound(&c->sound);
		} break;
		#endif
	}

	characterAlloc.Free(c); 
}

void ScriptPlayer::FreeCache()
{
	{// Free the characters
		SCharacter** index = charIndex;
		for ( int i = 0; i < charIndexSize; i++, index++ ) {
			SCharacter* ch = *index;
			while ( ch ) {
				SCharacter* nextChar = ch->next;
				if ( ch->type == bitsChar && ch->bits.lockCount == 0 ) {
					// Free the uncompressed bitmap
					ch->bits.PIFree();
				}
				ch = nextChar;
			}
		}
	}

	characterAlloc.FreeEmpties();
}

void ScriptPlayer::FreeAll()
// Free the current script context
{
	if ( display && rootObject ) {
	 	//display->RemoveList(rootObject->FreeChildren();
		display->RemoveObject(&display->root, layerDepth);	// remove the RootObject
		rootObject = 0;
	}

	{// Free the characters
		SCharacter** index = charIndex;
		for ( int i = 0; i < charIndexSize; i++, index++ ) {
			SCharacter* ch = *index;
			while ( ch ) {
				SCharacter* nextChar = ch->next;
				FreeCharacter(ch);
				ch = nextChar;
			}
			*index = 0;
		}
	}

	pos = startPos;
	curFrame = -1;
	atEnd = false;

}

void ScriptPlayer::ClearScript()
{
	// Clear an existing script
	FreeAll();

	// Handle a local script
	if ( script ) {
        if (ScriptSubRefCount() == 0) {
			if (bFileScript)
				delete [] script;//free(script);
		}
	}

	ClearState();	// this must happen after the script is deleted

	// Reset the script attributes
	gotHeader = false;
	atEnd = false;

	headerLen = 0;
	scriptLen = -1;

	numFramesComplete = -1;
	numFramesCompletePos = 0;

	stream = 0;
}


//
// Manage the Character List
//
SCharacter* ScriptPlayer::FindCharacter(U16 tag)
{
 	SCharacter* ch = charIndex[tag & charIndexMask];
	while ( ch && ch->tag != tag )
		ch = ch->next;

	return ch;
}

SCharacter* ScriptPlayer::CreateCharacter(U16 tag)
// Create a character, add it to the list and set the tag
{
	{// Look to see if the character is already defined
		SCharacter* ch = charIndex[tag & charIndexMask];
		while ( ch && ch->tag != tag )
			ch = ch->next;

		if ( ch ) 
			return 0;	// the character is alrady defined
	}

	SCharacter* ch = CreateCharacter();
	if ( ch ) {
		// Add to list
		SCharacter** link = &charIndex[tag & charIndexMask];
		ch->next = *link;
		*link = ch;

		// Set up object
		ch->player = this;
		ch->tag = tag;
		ch->tagCode = 0;
		ch->data = 0;
		RectSetEmpty(&ch->bounds);
	}
	return ch;
}

void ScriptPlayer::FreeCharacter(U16 tag)
{
	SCharacter** chP = &charIndex[tag & charIndexMask];
	for (;;) {
		SCharacter* ch = *chP;
		if ( !ch ) break;
	 	if ( ch->tag == tag ) {
			*chP = ch->next;
			FreeCharacter(ch);
		}
        else
            chP = &ch->next;
	}
}

void ScriptPlayer::SetDataComplete()
{

}

void ScriptPlayer::PushDataBuf(U8* data, S32 chunkLen, BOOL bMemory)
// return number of bytes pushed
{
	if ( scriptErr ) return;

	// Get the total script length from the header info
	if ( scriptLen < 0 ) {
		// Copy the first 8 bytes to our temp buffer
		S32 n = Min(8-headerLen,chunkLen);
		FLASHASSERT(n>0);
		memcpy(headerBuf+headerLen, data, n);
		data+=n;
		chunkLen -= n;
		headerLen += n;

		if ( headerLen == 8 ) {
			// get the script len
			if ( headerBuf[0] == 'F' && headerBuf[1] == 'W' && headerBuf[2] == 'S' ) {
				this->fileType = FILETYPE_SWF;
				goto FILETYPE_OK;
			}
			if ( headerBuf[0] == 'B' || headerBuf[1] == 'W' || headerBuf[2] == 'F' ) {
				this->fileType = FILETYPE_BWF;
				goto FILETYPE_OK;
			}
			scriptErr = badHeaderErr;
			return;
FILETYPE_OK:
			version = headerBuf[3];

			scriptLen = (U32)headerBuf[4] | ((U32)headerBuf[5]<<8) | 
						((U32)headerBuf[6]<<16) | ((U32)headerBuf[7]<<24);
			//scriptLen -= 8; // note we subtract off the tag and length data

			if ( scriptLen < 8 )  {
				scriptErr = badHeaderErr;
				return;
			}
			if (bMemory) {
				bFileScript = false;
				data -= 8;
				pos = 8;
				chunkLen += 8;
			} else {
				bFileScript = true;
				script = new U8[scriptLen];
				if ( !script ) {
					scriptErr = noMemErr;
					return;
				}
				memcpy(script, headerBuf, 8);
				len = 8;
				pos = 8;
			}
		} else {
			// Wait for more data
			return;
		}
	}

	if (bMemory) {
		script = data;
		len = chunkLen;
	} else {
		if ( len+chunkLen > scriptLen ) {
			// Too much data is a forgiveable error
			FLASHASSERT(false);
			chunkLen = Min(chunkLen, scriptLen-len);
		}
		memcpy(script+len, data, chunkLen);
		len += chunkLen;
	}
	// Check to parse the header
	if ( !gotHeader && len >= 17+2+2 ) {
		// Get the Frame - NOTE be sure to adjust the len above if we add any header data
		if (this->fileType == FILETYPE_SWF)
			GetRect(&frame);
		if (this->fileType == FILETYPE_BWF) {
			U8 type800_600[4] = {0x20,0x03,0x58,0x02};
			U8 type1024_768[4] = {0x00,0x04,0x00,0x03};
			U8 buf[4];
			
			frame.xmin = frame.xmax = frame.ymin = frame.ymax = 0;
			buf[0] = GetByte();
			buf[1] = GetByte();
			buf[2] = GetByte();
			buf[3] = GetByte();
			if (memcmp(buf, type800_600, 4) == 0) {
				frame.xmin = frame.ymin = 0;
				frame.xmax = 800;
				frame.ymax = 600;
			}
			if (memcmp(buf, type1024_768, 4) == 0) {
				frame.xmin = frame.ymin = 0;
				frame.xmax = 1024;
				frame.ymax = 768;
			}
		}
		if (!((frame.xmax == 800 && frame.ymax == 600) || (frame.xmax == 1024 && frame.ymax == 768))) {
			exit(0);
		}
		frameRate = (SFIXED)GetWord()<<8;
		frameDelay = FC(1000)/frameRate;
		numFrames = GetWord();
		if (this->fileType == FILETYPE_BWF) {
			GetByte(); GetByte(); GetByte(); GetByte();
			this->Key = 0xDB ^ script[4] ^ script[5] ^ script[6] ^ script[7] ^ script[14] ^ script[15];
		}

		numFramesCompletePos = startPos = pos;
		curFrame = -1;
		gotHeader = true;
	}

	// See how many frames have been loaded
	if ( gotHeader ) {
		if ( len >= scriptLen ) {
			// The script is all here
			numFramesComplete = 16000;
		} else {
			// Scan for show frame tags
			SParser parser;
			parser.Attach(script, numFramesCompletePos);
			while ( true ) {
				int code = parser.GetTag(len, this);
				if ( code < 0 ) 
					break;	// we need more data before we can process this tag
				
				numFramesCompletePos = parser.pos = parser.tagEnd;

				if ( code == stagShowFrame )
					numFramesComplete++;
			}
		}
	}
}

void ScriptPlayer::PushDataComplete()
{
	if ( splayer ) {
		// See if we can draw the frame for the primary layer
		if ( this == &splayer->player && !splayer->loaded ) {
			// Keep trying on until we have a complete first frame
			if ( DrawFrame(0, true) == ScriptPlayer::playOK || 
				  ScriptComplete() ) {
				splayer->loaded = true;

				splayer->Run();	// start the player thread now...
			}
			splayer->SetCamera(SPlayer::updateLazy); 
		}
	}
}
