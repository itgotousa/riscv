/****************************************************************************
CONFIDENTIAL AND PROPRIETARY INFORMATION.  The entire contents of this file
is Copyright ?Macromedia, Inc. 1993-1998, All Rights Reserved.  This
document is an unpublished trade secret of Macromedia, Inc. and may not be
viewed, copied or distributed by anyone, without the specific, written
permission of Macromedia, Inc. 
****************************************************************************/


#ifdef SOUND
#ifdef FLASHMP3

#ifndef min
#define min(a, b) ((a)<(b)?(a):(b))
#endif

#include <memory.h>
#include "mp3decoder.h"
#include "sndmix.h"

///////////////////////////////////////////
//
// mp3 decoder used by flash
//
CMp3Decomp::CMp3Decomp()
{
    src = 0;            // mpeg src data
    bufLength = 0;      // number of bytes last filled with
    bufIndex = 0;       // index into the out buffer
    srcIndex = 0;
    snd = 0;
	hDec = MP3_decode_init();
}

CMp3Decomp::~CMp3Decomp()
{
	if(hDec)
	MP3_decode_close(hDec);
}

void CMp3Decomp::Setup(CSound* snd, bool reset)
{
    FLASHASSERT(snd->CompressFormat() == sndCompressMP3);

	src = (U8 *) snd->samples;
    len = snd->dataLen;
    srcIndex = 0;
	mpa_Index = 0;
	
	bufLength = 0;      // number of bytes last filled with
    bufIndex = 0;       // index into the out buffer
    this->snd = snd;

    if (reset)
	{
		if(hDec)
			MP3_decode_close(hDec);
		hDec = MP3_decode_init();
	}
    // skip past the mp3 compression delay
    // Decompress(0, snd->delay);
}

//////////////////////////////////////////////////
//
// Get buffered data. If return value == input n
// then we had enough data in the buffer
//
long CMp3Decomp::GetBufferedData(S8 *dst, S32 n)
{
    U8	*TmPPtr;
	int bytesToCopy = n < (bufLength - bufIndex) ? n : (bufLength - bufIndex);

    // dst can bee 0 during seeking
	TmPPtr = &pcmBuf[bufIndex];
    if (dst)
        memcpy(dst, TmPPtr, bytesToCopy);

    // adjust the callers index and the current buff pointer
    bufIndex += bytesToCopy;

    if (bufIndex >= bufLength)
        bufIndex = bufLength = 0;

    return bytesToCopy;
}

void CMp3Decomp::Decompress(S16* dstWord, S32 nSamples) 
{
    long            bytesCleared;
    S32             nBytes  = nSamples * snd->BytesPerBlock();
    S8              *dstByte = (S8 *) dstWord;
    bool            seeking = (!dstWord) ? (true) : false;

	int nDataLen;
	int				CopyLen=0;
	uint32_t		nFrameSize=0;
	uint32_t		nFrame_Size=0;
	uint32_t		nFrameLen=0;

    // check first if there is any buffered data
    if ((bytesCleared = GetBufferedData(dstByte, nBytes)) == nBytes)
        goto exit_gracefully;
    else if (!hDec)
    {
        // fill with silence
        if (dstByte)
            memset(dstByte, 0x00, nBytes);

        goto exit_gracefully;
    }
    else
    {
        nBytes -= bytesCleared;

        // dst byte can be zero during seeking
        if (dstByte)
            dstByte += bytesCleared;
    }

    // Loop until error occurs or bytes are saved for next pass
	while(nBytes > 0)
	{
		if(srcIndex >= len)
		{
			break;
		}

		CopyLen = 0;
		if(mpa_Index < 4)
		{
			CopyLen = 4 - mpa_Index;
			memcpy(mpa_data+mpa_Index, src, 4);
			mpa_Index = 4;
		}
		src += CopyLen;
		srcIndex += CopyLen;
		nFrame_Size = nFrameSize;
		nFrameSize = MP3_GetFrameSize(*(uint32_t*)mpa_data);
		if(nFrameSize==0)
		{
	
			int samplesToSkip = nBytes / snd->BytesPerBlock();

			// see if we are seeking and data has at least four bytes left
			if (samplesToSkip > 0)
			{
				// skip full frames of sound
				if((len - srcIndex) < samplesToSkip-mpa_Index)
				{
					memcpy(mpa_data+mpa_Index, src, len - srcIndex);
					src += len - srcIndex;
					srcIndex = len;
					mpa_Index += len - srcIndex;
					break;
				}
				memcpy(mpa_data+mpa_Index, src, samplesToSkip-mpa_Index);
				src += samplesToSkip-mpa_Index;
				srcIndex += samplesToSkip-mpa_Index;
				mpa_Index = 0;
				if(srcIndex >= len)
				{
					break;
				}
				continue;
			}
			else
				goto	exit_gracefully;
		}

		if((int)(len - srcIndex) < (int)(nFrameSize-mpa_Index))
		{
			memcpy(mpa_data+mpa_Index, src, len - srcIndex);
			src += len - srcIndex;
			srcIndex = len;
			mpa_Index += len - srcIndex;
			break;
		}
		memcpy(mpa_data+mpa_Index, src, nFrameSize-mpa_Index);
		src += nFrameSize-mpa_Index;
		srcIndex += nFrameSize-mpa_Index;
		mpa_Index = 0;
		nFrameLen = MP3_decode_frame(hDec, pcmBuf, &nDataLen, mpa_data, nFrameSize);
		if(nDataLen>0)
		{
			bufLength = nDataLen;
			bytesCleared = GetBufferedData(dstByte, nBytes);
			nBytes -= bytesCleared;
			
			// dst byte can be zero during seeking
			if (dstByte)
				dstByte += bytesCleared;			
		}

	}

exit_gracefully:
    ;
}

#endif
#endif