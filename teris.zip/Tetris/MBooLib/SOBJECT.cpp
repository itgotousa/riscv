/****************************************************************************
CONFIDENTIAL AND PROPRIETARY INFORMATION.  The entire contents of this file
is Copyright ?Macromedia, Inc. 1993-1998, All Rights Reserved.  This
document is an unpublished trade secret of Macromedia, Inc. and may not be
viewed, copied or distributed by anyone, without the specific, written
permission of Macromedia, Inc. 
****************************************************************************/
//	990325	mnk	"fixed1" -> "fixed_1"

#include "stdafx.h"

#include "sobject.h"

#include "stags.h"
#include "splay.h"
#include "splayer.h"

void MakeVertLine(CURVE* c, SCOORD x)
{
	c->anchor1.x = c->control.x = c->anchor2.x = x;
	if ( c->anchor1.y < -32000 ) c->anchor1.y = -32000;
	if ( c->anchor2.y >  32000 ) c->anchor2.y = 32000;
	c->control.y = (c->anchor1.y + c->anchor2.y)/2;
	c->isLine = true;
}

void SCharacterParser::AddCurve(P_CURVE src)
{
	CURVE c;
	S32 dir;

	c = *src;

	// Sort the anchors
	if ( c.anchor1.y <= c.anchor2.y ) {
		dir = 1;
	} else {
		dir = -1;
		Swap(c.anchor1, c.anchor2, SPOINT);
	}

	if ( c.anchor1.y == c.anchor2.y ) 
		return;	// this is a horizontal edge, we can ignore it

	// Set up a new edge
	REdge* edge = display->CreateEdge();
	if ( !edge ) return;

	// Set up the curve
	edge->Set(&c);
	edge->dir = (S8)dir;

	// Track the colors
	edge->fillRule = fillRule;
	edge->color1 = color1;
	edge->color2 = color2;

	// Add to the edge list
	edge->nextObj = obj->edges;
	obj->edges = edge;
}

void SCharacterParser::BuildEdges(BOOL getStyles, SRECT* devBounds)
{
	depth = 0;

	raster = &obj->display->raster;
	if ( !raster->bits ) 
		raster = 0;
	colorList = &obj->colors;	// we want to keep the colors
	if ( getStyles ) {
		if ( !GetStyles() ) 
			return;
	} else {
		// See how large we need the fill and line tags to be
		InitBits();
		nFillBits = (int)GetBits(4);
		nLineBits = (int)GetBits(4);
	}

	// Get the edges
	BOOL hasFill, hasLine;

	color1 = color2 = 0;
	hasLine = hasFill = false;
	for (;;){
		CURVE c;
		int flags = GetEdge(&c);
		if ( flags ) {
			// Process a state change

			// Are we at the end
			if ( flags == eflagsEnd ) {
				break;
			}

			if ( flags & (eflagsFill0|eflagsFill1) ) {
				// Get new fill info
				color1 = fillIndex[fill[0]];
				color2 = fillIndex[fill[1]];

				if ( !color1 && color2 ) {
					color1 = color2;
					color2 = 0;
				}
				fillRule = color2 ? fillEdgeRule : fillEvenOddRule;
				hasFill = color1 || color2;
			}
		} else {
			// Add an edge
			if ( hasFill )
				AddCurve(&c);
		}
	}
}

//
// The Object Methods
//

void SObject::FreeCache()
{
	{// Free the edges
		REdge* e = edges;
		while ( e ) {
			REdge* next = e->nextObj;
			display->FreeEdge(e);
			e = next;
		}
		edges = 0;
	}

	{// Free the colors
		RColor* c = colors;
		while ( c ) {
			RColor* next = c->nextColor;
			display->FreeColor(c);
			c = next;
		}
		colors = 0;
	}
}

void SObject::Free()
{
	FreeCache();

	if (character && character->type == shapeChar) {
		MATRIX m;
		SShapeParser parser(character->player, character->data, 0, &m);
		parser.FreeBilts();
	}
}

void SObject::CalcDevBounds(MATRIX* mat)
{
	// Calculate the device matrix
	if ( !character ) {
		RectSetEmpty(&devBounds);
	} else {
		MatrixTransformRect(mat, &character->bounds, &devBounds);
	}
}

void SObject::BuildEdges(STransform* x)
{
	ScriptPlayer* player = character->player;
	
	if ( edges || colors || player->scriptErr ) return;

	switch ( character->type ) {
		case shapeChar: {
			SCharacterParser parser(player, character->data, 0, &x->mat);
			parser.obj = this;
			parser.BuildEdges(true, &devBounds);
		} break;
	}
}

void SObject::FreeChildren()
{
	SObject* obj = bottomChild;
	bottomChild = 0;
	while ( obj ) {
		SObject* next = obj->above;

		// Remove any children
		obj->FreeChildren();

		// Free the object
		if ( obj->drawn )
			display->InvalidateRect(&obj->devBounds);

		obj->Free();
		display->FreeObject(obj);

		obj = next;
	}

}

void SObject::Modify()
{
	display->dirty = true;
	dirty = true;
}

void SObject::CalcUpdate(MATRIX* m, BOOL forceDirty)
{
	MATRIX mat;
	MatrixConcat(&xform.mat, m, &mat);
	forceDirty |= dirty;
	if ( forceDirty ) {
		// The cache is no longer valid
		FreeCache();

		if ( drawn ) {
			display->InvalidateRect(&devBounds);
			drawn = false;
		}

		CalcDevBounds(&mat);

		display->InvalidateRect(&devBounds);
		dirty = false;
	}
	for ( SObject* obj = bottomChild; obj; obj = obj->above )
		obj->CalcUpdate(&mat, forceDirty);
}

void SObject::Draw(CRaster* raster, STransform* x, RColor* clipColor)
{
	if (!visible)
		return;

	x->Concat(&xform);
	if ( RectTestIntersect(&devBounds, &raster->edgeClip) ) {
		{
			BuildEdges(x);
			raster->AddEdges(edges, colors, clipColor);
		}
		drawn = true;
	}

	for ( SObject* obj = bottomChild; obj; ) {
			obj->Draw(raster, x, clipColor);
			obj = obj->above;
	}
}
