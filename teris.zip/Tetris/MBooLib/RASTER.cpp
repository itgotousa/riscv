/****************************************************************************
CONFIDENTIAL AND PROPRIETARY INFORMATION.  The entire contents of this file
is Copyright ?Macromedia, Inc. 1993-1998, All Rights Reserved.  This
document is an unpublished trade secret of Macromedia, Inc. and may not be
viewed, copied or distributed by anyone, without the specific, written
permission of Macromedia, Inc. 
****************************************************************************/

#include <memory.h>	   // lee@middlesoft - thanks E. Hyche, RealNetworks, for providing header corrections.
#include "raster.h"
#include "bitbuf.h"
#include "sbitmap.h"

#include NATIVE_SOUND
#include "sndmix.h"

enum { RGBSlabChunkSize=256 };

// Rendering tables

CoverEntry PixCoverage[8][8];
BOOL renderTablesBuilt = false;

void BuildRenderTables()
{
	renderTablesBuilt = true;

	// Build the coverage table
 	for ( int xf = 0; xf < 8; xf++ ) {
		for ( int yf = 0; yf < 8; yf++ ) {
			int* ce = PixCoverage[xf][yf].ce;
			ce[0] = (8-xf)*(8-yf);
			ce[1] = xf*(8-yf);
			ce[2] = (8-xf)*yf;
			ce[3] = xf*yf;

			// Normalize the sum of coverages to 8
			int big = 0;	// add the error to the largest weight
			int sum = 0;
			for ( int j = 0; j <= 3; j++ ) {
				ce[j] = (ce[j]+4)/8;
				sum += ce[j];
				if ( ce[j] > ce[big] ) big = j;
			}
			int err = 8-sum;
			ce[big] += err;
		}
	}
}

// Use more distinctive patterns on PC for higher dpi screens
#define linePatBits 	0x39C6 // diag lines
#define fillPatBits 	0x33CC // 2x2 blocks

#define solidPatBits 	0xFFFF // solid
#define disablePatBits 	0xA5A5 // 50% 

//
// Proc Tables
//
const DrawRGBSlabProc DrawRGBSlabProcs[9] = {
	DrawRGBSlab1,
	DrawRGBSlab2,
	DrawRGBSlab4,
	DrawRGBSlab8,
	DrawRGBSlab16,
	DrawRGBSlab16A,
	DrawRGBSlab24,
	DrawRGBSlab32,
	DrawRGBSlab32A
};

//
// Doubly Linked List
//

// head must be the pointer to the list start
// elem must have a next and prev field

// Add to the elem to the front of the list
#define DListAdd(head, elem, type) { \
		if ( head ) \
			head->prev = elem; \
		elem->next = head; \
		elem->prev = 0; \
		head = elem; \
	}

// Add elem after node
#define DListInsertAfter(node, elem, type) { \
		type *tmp; \
		if ( (tmp = node->next) != 0 ) \
			tmp->prev = elem; \
		elem->next = tmp; \
		elem->prev = node; \
		node->next = elem; \
	}

// Remove elem from the list
#define DListRemove(head, elem, type) \
	{ \
		type *tmp; \
		if ( (tmp = elem->prev) != 0 ) \
			tmp->next = elem->next; \
		else if ( head == elem ) \
			head = elem->next; \
		if ( (tmp = elem->next) != 0 ) \
			tmp->prev = elem->prev; \
		elem->next = elem->prev = 0; \
	}

// Swap two elements, first must be immediately before second
#define DListSwap(head, first, second, type) \
	{ \
		DListRemove(head, first, type); \
		DListInsertAfter(second, first, type); \
	}

//
// Low-Level Compositing Functions
//
inline void CompositeRGB(RGBI* src, RGBI* dst, int n)
{
	memcpy(dst, src, n + n + n + n);
}

//
// The Color Object
// 
void RColor::SetUp(CRaster* r)
{
	raster = r;
	nextColor = nextActive = 0;
	visible = 0;
	transparent = false;
	colorType = colorSolid;
	cacheValid = false;
}

void RColor::FreeCache()
{
	if ( cacheValid ) {
		cacheValid = false;
		switch ( colorType ) {
			case colorBitmap:
				bm.bitmap->UnlockBits();
				break;
		}
	}
}

static const BltProc FastBltProcs16[] = {	// index by dest pixel format
		0,	//bm1Bit
		0,	//bm2Bit
		0,	//bm4Bit
		0,	//bm8Bit
		(BltProc)Blt16to16,	//bm16Bit
		0,  //bm32Bit
	};

static const BltProc FastBltProcs32[] = {	// index by dest pixel format
		0,	//bm1Bit
		0,	//bm2Bit
		0,	//bm4Bit
		0,  //bm8Bit
		(BltProc)Blt16to32,	//bm16Bit
		0,  //bm32Bit
	};

static const BltProc* FastBltProcs[] = {	// index by source bitmap format
		0,		// pix1
		0,		// pix2
		0,		// pix4
		0,
		FastBltProcs16,
		0,		// pix16A
		0,		// pix24
		FastBltProcs32,
		0		// pix32A
	};

static const BltProc GeneralBltProcs[] = {	// index by bitmap format
		(BltProc)BltXtoI,
		(BltProc)BltXtoI,
		(BltProc)BltXtoI,
		(BltProc)BltXtoI,
		(BltProc)BltXtoI,
		(BltProc)Blt32toI
	};

void RColor::BuildCache()
{
	if ( cacheValid ) return;

	switch ( colorType ) {
		case colorBitmap: {
			{
				drawSlabProc = DrawBitmapSlab;
				compositeSlabProc = transparent ? CompositeBitmapSlab : BuildBitmapSlab;

				bm.bitmap->LockBits();	// the Mac puts bits in handles

				bm.bi.color = this;
				bm.bi.baseAddr = (U8*)bm.bitmap->baseAddr;
				bm.bi.rowBytes = bm.bitmap->rowBytes;
				bm.bi.width = bm.bitmap->width;
				bm.bi.height = bm.bitmap->height;
				bm.bi.colors = bm.bitmap->cTab ? bm.bitmap->cTab->colors : 0;
			
				bm.bltProc = GeneralBltProcs[bm.bitmap->bmFormat];
				const BltProc* procs = FastBltProcs[raster->pixelFormat];
				if ( procs && procs[bm.bitmap->bmFormat]) 
					bm.bltProc = procs[bm.bitmap->bmFormat];
			}
		} break;
	}
	cacheValid = true;
}

//
// The Edge structures
//

typedef void (*DoEdgeProc)(CRaster*, RActiveEdge*);
typedef void (*StepProc)(RActiveEdge*, S32 yline);

struct RActiveEdge {
	RActiveEdge *next, *prev;
	S32 x;
	S32 ymax;

	SPOINT d, d2;		// difference stored as 10.22
	SCOORD xl, yl;		// location stored as 16.16
	S32 stepLimit;		// countdown to zero so we know when t == 1
	
	RColor *color1, *color2;
	int dir;

	DoEdgeProc doEdgeProc;
	StepProc stepProc;
	
	void SetUp(REdge* e, S32 y);
};

void StepLine(RActiveEdge* edge, S32 yline)
{
 	// Step down a line
	edge->xl += edge->d.x;
	edge->x = (edge->xl + 0x8000L) >> 16;
}

void RActiveEdge::SetUp(REdge* e, S32 y)
{
	// Set up the difference equation
	if ( e->isLine ) {
		// Do a straight line
		stepProc = StepLine;

	 	SCOORD dx = (SCOORD)e->anchor2x - (SCOORD)e->anchor1x;
	 	SCOORD dy = (SCOORD)e->anchor2y - (SCOORD)e->anchor1y;
			
		// Set up the difference equation
		d.x = (dx << 16)/dy;
		xl = (SCOORD)e->anchor1x << 16;
			
		// Adjust for missed lines
		dy = y - (SCOORD)e->anchor1y;
		if ( dy != 0 )
			xl += d.x*dy;
		
		x = (xl+0x8000L)>>16;
		
	} 	
	ymax = e->anchor2y;
	
	color1 = e->color1;
	color2 = e->color2;
	doEdgeProc = DoEdgeEvenOddRule;
	dir = e->dir;
}

//
// The Renderer Object
//
CRaster::CRaster() :
				activeEdgeAlloc(sizeof(RActiveEdge), 64, true, 0x33333333)
{
	if ( !renderTablesBuilt )
		BuildRenderTables();

	//activeColors = 0;
	topColor = 0;

	firstActive = 0;
	yindex = 0;
	yindexSize = 0;

	bits = 0;
	cinfo = 0;
	baseAddr = 0;
	
	topColorXleft = 0;
}

CRaster::~CRaster() 
{
	delete [] yindex;
}

void CRaster::FreeEmpties()
{
	activeEdgeAlloc.FreeEmpties();
}

//
// Painting code
//

BOOL CRaster::BitsValid()
{
	return bits && bits->BitsValid();
}

void CRaster::Attach(CBitBuffer* b, SRECT* c)
{
	if ( b ) {
		bits = b;
		cinfo = bits->getSColorInfo();	//m_cinfo;
		inverted = bits->inverted();	//m_inverted;
		bitHeight = bits->height();		//m_bufHeight;
		baseAddr = bits->baseAddess();	//b(char*)bits->m_baseAddr;
		rowBytes = bits->scanLine();	//m_rowBytes;

		xorg = bits->xorg();
		pixelFormat = bits->pixelFormat();
		drawRGBSlab = DrawRGBSlabProcs[pixelFormat];
	} else {
	 	bits = 0;
		cinfo = 0;
		baseAddr = 0;
	}

	RectSet(0, 0, bits->width(), bits->height(), &bitClip);
	if ( c ) 
		RectIntersect(c, &bitClip, &bitClip);

	edgeClip = bitClip;

	ylines = edgeClip.ymax - edgeClip.ymin + 1;
	if ( ylines <= 0 ) {
		ylines = 0;	    
		FLASHASSERT(false);
	}
}

typedef REdge* PREdge;

void CRaster::BeginPaint()
{
	FLASHASSERT(baseAddr);

	// Setup the y index
	S32 newSize = ylines;
	if ( newSize > yindexSize ) {
		delete [] yindex;//free(yindex);
		yindex = new PREdge[newSize];
		if ( !yindex ) {
			yindexSize = 0;
			return;
		}
		yindexSize = newSize;
	}

	memset(yindex, 0, (int)(newSize * (sizeof(PREdge))));

	firstActive = 0;
	topColor = 0;

	needFlush = false;
	layerDepth = 0;
}

void CRaster::AddEdges(REdge* edge)
{
	if ( !edge ) return;
	while ( edge ) {
		if ( edge->anchor1y <= edgeClip.ymax && edge->anchor2y > edgeClip.ymin ) {
			// Insert this edge at the proper scanline
			S32 i = edge->anchor1y - edgeClip.ymin;
			if ( i < 0 ) i = 0;
			edge->nextActive = yindex[i];
			yindex[i] = edge;
		}
		edge = edge->nextObj;
	}
	needFlush = true;
}

void CRaster::AddEdges(REdge* edge, RColor* colors, RColor* clipColor)
// Add the edges and adjust the color depths for the current layering
{
	AddEdges(edge);
	while ( colors ) {
		colors->order = (colors->order & 0xFFFF) | layerDepth;
		colors = colors->nextColor;
	}
	layerDepth += 0x10000;
}

void CRaster::AddActive()
{// Add new active edge entries
	REdge *e;
	RActiveEdge *a, *pos;
	REdge** index;
	S32 x;
	
	pos = firstActive;
	index = yindex + y-edgeClip.ymin;
	for ( e = *index; e; e = e->nextActive ) {
		a = CreateActiveEdge();
		if ( !a ) return;
		
		a->SetUp(e, y);
		
		// Insert into the active edge list
		if ( pos ) {
			// Find the proper position
			x = a->x;
			if ( pos->x < x ) {
				while ( pos->x < x && pos->next )
					pos = pos->next;
			} else if ( pos->x > x ) {
				while ( pos->x > x && pos->prev )
					pos = pos->prev;
			}
			
			DListInsertAfter(pos, a, RActiveEdge);
			
		} else {
			// Insert into an empty list
			DListAdd(firstActive, a, RActiveEdge);
		}
		pos = a;
	}
}

void CRaster::SortActive()
{// Sort the active edges
	RActiveEdge *a, *b, *stop;
	BOOL swapped;
	
	stop = 0;
	do {
		swapped = false;
		a = firstActive;
		
		while ( a != 0 && (b = a->next) != 0 ) {
			if ( a->x > b->x ) {
				// Swap
			 	DListSwap(firstActive, a, b, RActiveEdge);
			 	if ( !swapped && b->prev && b->prev->x > b->x )
			 		swapped = true;
			} else {
				// Just keep going
				a = b;
			}
		}
	} while ( swapped );
}

//
// Drawing with an alpha channel
//

void CRaster::CompositeSlab(S32 xleft, S32 xright, RColor** stack, int n)
{
	// Apply the colors
	while ( xleft < xright ) {
		RGBI pixBuf[RGBSlabChunkSize];
		S32 limit = Min(xright, xleft+RGBSlabChunkSize);

		RColor** c = stack+n-1;
		int i = n;

		while ( i > 0 ) {
			// Composite the slab to the buffer
			((*c)->compositeSlabProc)(*c, xleft, limit, pixBuf);
			c--;i--;
		}
		drawRGBSlab(this, xleft, limit, pixBuf);
		xleft = limit;
	}
}

//
// Paint a slab of color
//

void CRaster::PaintSlab(S32 xright)
// Apply a slab to the current run using the topColor
{
	S32 xleft = topColorXleft;
	topColorXleft = xright;

	if ( topColor ) {
		{
			// Clip to the bitmap
			if ( xleft < bitClip.xmin )
				xleft = bitClip.xmin;
			if ( xright > bitClip.xmax )
				xright = bitClip.xmax;

			if ( xright > xleft ) {
				// Build a bottom up list of visible colors
				RColor* stack[255];
				int n = 0;

				{// Build a stack of colors
					RColor* c = topColor;
					while ( c ) {
						if ( n < 255 ) // we always want to keep the bottom color since it is usually not tranparent
							n++;
						stack[n-1] = c;
						c = c->nextActive;
					}
				}

				if ( n > 0 ) {
					if ( !stack[0]->transparent )
						(stack[0]->drawSlabProc)(stack[0], xleft, xright);	// The top color is opaque, just draw it
					else
						CompositeSlab(xleft, xright, stack, n);		// composite the entire stack
				}
			}
		}
	}
}

//
// Manage the color transitions
//

inline void CRaster::ShowColor(RColor* c, S32 x)
{
	// Find where to insert the color
	RColor** link = &topColor;
	while ( true ) {
		RColor* tc = *link;
		if ( !tc ) break;
		if ( c->order > tc->order ) {
			break;
		} else {
			link = &tc->nextActive;
		}
	}

	// Draw a slab if the new color is visible
	PaintSlab(x);

	// Insert the color
	c->nextActive = *link;
	*link = c;
}

inline void CRaster::HideColor(RColor* c, S32 x)
{
	// Find the color
	RColor** link = &topColor;
	while ( true ) {
		RColor* tc = *link;
		if ( tc == c ) {
			break;
		} else {
			link = &tc->nextActive;
		}
	}

	// Draw a slab if the old color was visible needed
	PaintSlab(x);

	// Remove the color
	*link = c->nextActive;
}

//
// Support the Edge rules
//
void DoEdgeEvenOddRule(CRaster* r, RActiveEdge* a)
{
	// Handle color1
	RColor* c = a->color1;
	if ( c->visible ) {
		r->HideColor(c, a->x);
	 	c->visible = false;
	} else {
		r->ShowColor(c, a->x);
	 	c->visible = true;
	}
}

void CRaster::PaintActive()
// Draw the slabs
{
	S32 ynext = y+1;

	SetYCoord(y);

	{// This should never happen but we can minimize the effect
		for ( RColor* c = topColor; c; c = c->nextActive )
		{
			c->visible = 0;
		}
		topColor = 0;
	}
    
	register RActiveEdge* a = firstActive;
    while ( a ) {
		// Track the active colors
		(a->doEdgeProc)(this, a);
    	
		// Remove out of date active edge entries
		// And calculate new x coordinates for the ones we keep
		if ( a->ymax > ynext ) {
			// Keep this edge
		 	a->stepProc(a, ynext);
		 	a = a->next;
		} else {
			// Remove this edge
    		RActiveEdge* next = a->next;
			DListRemove(firstActive, a, RActiveEdge);
			FreeActiveEdge(a);
			a = next;
		}
    }
}

//
// Main Paint routine
//

void CRaster::PaintBits()
{
	bits->Flush();

	// Paint the scanlines
	for ( y = edgeClip.ymin; y < edgeClip.ymax; y++ ) {
		AddActive();
		SortActive();
		PaintActive();

		if ( (y & 0x1f) == 0 ) {
			Spin();
			PollSound();
		}
	}

	// Free any excess active edges
	{
		for ( RActiveEdge* a = firstActive; a; ) {
			RActiveEdge* next = a->next;
			FreeActiveEdge(a);
			a = next;
		}
		firstActive = 0;
	}
}

void CRaster::Flush()
{
	if ( needFlush ) {
		PaintBits();
		BeginPaint();
	}
}

//
// Methods for setting the actual bits
//

void CRaster::SetYCoord(S32 yCoord)
{
	bitY = yCoord;

	if ( inverted ) {	
		// The rows are inverted for a Windows DIB
		rowAddr = baseAddr + (bitHeight-(bitY+1))*rowBytes;
	} else {
		// We are using a standard row order
		rowAddr = baseAddr + bitY*rowBytes;
	}
}

//
// DrawRGBSlab Procs
//
void DrawRGBSlab16(CRaster* r, S32 xmin, S32 xmax, RGBI* pix)
{
	U16 * dst = (U16 *)r->rowAddr + xmin  + r->xorg;
	{
		for ( S32 i = xmax-xmin; i--; pix++, dst++ ) {
			*dst = PackPix16(pix);
		}
	}
}

void DrawRGBSlab16A(CRaster* r, S32 xmin, S32 xmax, RGBI* pix)
{
	U16 * dst = (U16 *)r->rowAddr + xmin + r->xorg;
	{
		for ( S32 i = xmax-xmin; i--; pix++, dst++ ) {
			*dst = PackPix16A(pix);
		}
	}
}

void DrawRGBSlab24(CRaster* r, S32 xmin, S32 xmax, RGBI* pix)
{
	U8 * dst = (U8 *)r->rowAddr + 3*(xmin + r->xorg);
	for ( S32 i = xmax-xmin; i--; pix++, dst+=3 ) {
		dst[2] = (U8)pix->red;
		dst[1] = (U8)pix->green;
		dst[0] = (U8)pix->blue;
	}
}

void DrawRGBSlab32(CRaster* r, S32 xmin, S32 xmax, RGBI* pix)
{
	U32 * dst = (U32 *)r->rowAddr + xmin + r->xorg;
	int len = xmax - xmin;
	
	memcpy(dst, pix, len + len + len + len);
}

void DrawRGBSlab32A(CRaster* r, S32 xmin, S32 xmax, RGBI* pix)
{
	U32 * dst = (U32 *)r->rowAddr + xmin + r->xorg;
	for ( S32 i = xmax-xmin; i--; pix++, dst++ ) {
		*dst = PackPix32A(pix, 0xFF);
	}
}

//
// General Blts
//
inline void BltXtoI(BltInfo* bi, SPOINT& pt, int n, RGBI* pix)
{
	FLASHASSERT(false);
}

inline void Blt32toI(BltInfo* bi, SPOINT& pt, int n, RGBI* pix)
{				
	U32 * rowAddr = (U32 *)(bi->baseAddr + (pt.y)*bi->rowBytes + pt.x + pt.x + pt.x + pt.x);
	memcpy(pix, rowAddr, n + n + n + n);
}

void Blt16to16(BltInfo *bi, SPOINT& pt, int n, U16 * dst)
{
	U16 * src = (U16 *)(bi->baseAddr + (pt.y)*bi->rowBytes);
	
	src += pt.x;
	pt.x += n;
	while ( n-- )
		*dst++ = *src++;
}

void Blt16to32(BltInfo *bi, SPOINT& pt, int n, U32 * dst)
{
	U16 * src = (U16 *)(bi->baseAddr + pt.y*bi->rowBytes);
	while ( n-- ) {
		int pix = *(src + pt.x);
		*dst++ = Pix16To32(pix);
		pt.x++;
	}
}

void DrawBitmapSlab(RColor* color, S32 xmin, S32 xmax)
{
	CRaster* r = color->raster;

	// Calc the start point in bitmap src coordinates
	SPOINT pt;
	pt.x = xmin + color->bm.invMat.tx;
	pt.y = r->bitY + color->bm.invMat.ty;

	RGBI pix;
	int n = (int)(xmax-xmin);
	SBitmapCore* bitmap = color->bm.bitmap;

	if (pt.x + n >= bitmap->width) {
		bitmap->GetRGBPixel(pt.x + n, pt.y, &pix);
		xmax--;
		color->raster->drawRGBSlab(r, xmax, xmax+1, &pix);
	}

	// Draw the slab for the fast case
	// 		int pixSize = mapPixelFormatToDepth[r->pixelFormat]/8;
	int pixSize = NativeDisplayTester::PixelFormatToDepth( color->raster->pixelFormat ) / 8;
	FLASHASSERT(pixSize > 0);

	while ( xmin < xmax ) {
		// Expand the pixels to RGB values
		int n = Min((int)(xmax-xmin), RGBSlabChunkSize);
		color->bm.bltProc(&(color->bm.bi), pt, n, color->raster->rowAddr + xmin*pixSize);
		xmin += n;
	}
}

void BuildBitmapSlab(RColor* color, S32 xmin, S32 xmax, RGBI* buf)
{
	// Calc the start point in bitmap src coordinates
	SPOINT pt;
	pt.x = xmin + color->bm.invMat.tx;
	pt.y = color->raster->bitY + color->bm.invMat.ty;

	int n = (int)(xmax-xmin);
	SBitmapCore* bitmap = color->bm.bitmap;

	if (pt.x + n >= bitmap->width) {
		bitmap->GetRGBPixel(pt.x + n, pt.y, buf + n -1);
		xmax--;
	}

	// Draw the slab for the general case
	n = (int)(xmax-xmin);
	color->bm.bltProc(&(color->bm.bi), pt, n, buf);
}

//
// Composite Draw Procs
//
void CompositeBitmapSlab(RColor* color, S32 xmin, S32 xmax, RGBI* buf)
{
	FLASHASSERT(xmax-xmin<=RGBSlabChunkSize);

	BuildBitmapSlab(color, xmin, xmax, buf);
}
