/****************************************************************************
CONFIDENTIAL AND PROPRIETARY INFORMATION.  The entire contents of this file
is Copyright ?Macromedia, Inc. 1993-1998, All Rights Reserved.  This
document is an unpublished trade secret of Macromedia, Inc. and may not be
viewed, copied or distributed by anyone, without the specific, written
permission of Macromedia, Inc. 
****************************************************************************/

#include <memory.h>
#include <malloc.h>
#include "sbitmap.h"

#include "memcop.h"
#include "raster.h"

#include "zlib.h"

//
// Utility
//
int SBitmapCalcRowbytes(int bmFormat, int width)
{
	switch ( bmFormat ) {
		case bm32Bit:
			return 4*width;

		case bm1Bit: 
			return ((width + 31) >> 3) & ~3;

		case bm2Bit: 
			return ((width + 15) >> 2) & ~3;

		case bm4Bit: 
			return ((width + 7) >> 1) & ~3;

		case bm8Bit:
			return (width + 3) & ~3;

		case bm16Bit:
			return (2*width + 3) & ~3;
	}
	FLASHASSERT(false);
	return 0;
}


//
// SBitmapCore
//

void SBitmapCore::GetRGBPixel(int x, int y, RGBI* c)
{
	FLASHASSERT(baseAddr);

	// Clip to the edges
	if ( x < 0 ) x = 0;
	if ( y < 0 ) y = 0;
	if ( y >= height ) y = height-1;
	if ( x >= width ) x = width-1;

	U8 * rowAddr = (U8 *)baseAddr + y*rowBytes;
	switch ( bmFormat ) {
		
		case bm32Bit: {
			U32 pix = *((U32 *)rowAddr + x);
			memcpy(c, &pix, 4);
					  } return;

		case bm16Bit: {
			U16 pix = *((U16 *)rowAddr + x);
			UnpackPix16(pix, c);
					  } return;
	}
}

void SBitmapCore::PIInit()
{
	baseAddr = 0;
	cTab = 0;
	lockCount = 0;
	transparent = false;
}

BOOL HasTransparent(SColorTable* ctab)
{
	if ( !ctab )
		return false;
	RGB8* c = ctab->colors;
	for ( int i = ctab->n; i--; c++ ) {
		if ( c->alpha < 255 )
			return true;
	}
	return false;
}

BOOL SBitmapCore::PICreate(int format, int w, int h, SColorTable* c, BOOL allowPurge)
{
	baseAddr = 0;
	cTab = 0;
	lockCount = 0;
	transparent = ( HasTransparent(c) != 0 );

	bmFormat = format;
	width = w;
	height = h;
	rowBytes = SBitmapCalcRowbytes(bmFormat, width);

	if ( bmFormat <= bm8Bit ) {
		FLASHASSERT(c);

		// Create our color table
		int ctabSize = sizeof(SColorTable) - (256-c->n)*sizeof(RGB8);
		cTab = new SColorTable;
		if ( !cTab ) 
			return false;
		memcpy(cTab, c, ctabSize);
	}

	S32 size = (S32)rowBytes*height;

	baseAddr = (char*)malloc(size);
	return baseAddr != 0;
}

void SBitmapCore::PIFree()
{
	delete [] cTab;//free(cTab);
	cTab = 0;

	if ( baseAddr ) {
		free(baseAddr);
		baseAddr = 0;
	}
}

#ifdef BIG_ENDIAN
// Big-endian system: Defined as an empty inline function.
#else
// Little-endian system: Swap the bits within this function. 
void SBitmapSwapBits(void* data, S32 bytes, int bmFormat)
{
	if ( bmFormat == bm16Bit ) {
		U8 * w = (U8*)data;
		U8 tmp;
		for ( S32 i = bytes/4; i--; ) {
			tmp = w[0];
			w[0] = w[1];
			w[1] = tmp;
			w += 2;

			tmp = w[0];
			w[0] = w[1];
			w[1] = tmp;
			w += 2;
		}
	} else if ( bmFormat == bm32Bit ) {
		U8 * w = (U8*)data;
		U8 tmp;
		for ( S32 i = bytes/4; i--; ) {
			tmp = w[0];
			w[0] = w[3];
			w[3] = tmp;
			tmp = w[1];
			w[1] = w[2];
			w[2] = tmp;

			w += 4;
		}
	}
}
#endif

//PLAYER

//
// Pixel Packing support
//

#define Epnd16(x)  (((x)<<3)|0x7)
const int pix16Expand[32] = {	
	0, 			  Epnd16(0x01), Epnd16(0x02), Epnd16(0x03), 
	Epnd16(0x04), Epnd16(0x05), Epnd16(0x06), Epnd16(0x07), 
	Epnd16(0x08), Epnd16(0x09), Epnd16(0x0A), Epnd16(0x0B), 
	Epnd16(0x0B), Epnd16(0x0D), Epnd16(0x0E), Epnd16(0x0F),
	Epnd16(0x10), Epnd16(0x11), Epnd16(0x12), Epnd16(0x13), 
	Epnd16(0x14), Epnd16(0x15), Epnd16(0x16), Epnd16(0x17), 
	Epnd16(0x18), Epnd16(0x19), Epnd16(0x1A), Epnd16(0x1B), 
	Epnd16(0x1B), Epnd16(0x1D), Epnd16(0x1E), Epnd16(0x1F),
};

#define Epnd16R(x) ((Epnd16(x)<<16)|0xff000000L)	// add the alpha value
const U32 pix16ExpandR[32] = {	
	0xFF000000L,   Epnd16R(0x01), Epnd16R(0x02), Epnd16R(0x03), 
	Epnd16R(0x04), Epnd16R(0x05), Epnd16R(0x06), Epnd16R(0x07), 
	Epnd16R(0x08), Epnd16R(0x09), Epnd16R(0x0A), Epnd16R(0x0B), 
	Epnd16R(0x0B), Epnd16R(0x0D), Epnd16R(0x0E), Epnd16R(0x0F),
	Epnd16R(0x10), Epnd16R(0x11), Epnd16R(0x12), Epnd16R(0x13), 
	Epnd16R(0x14), Epnd16R(0x15), Epnd16R(0x16), Epnd16R(0x17), 
	Epnd16R(0x18), Epnd16R(0x19), Epnd16R(0x1A), Epnd16R(0x1B), 
	Epnd16R(0x1B), Epnd16R(0x1D), Epnd16R(0x1E), Epnd16R(0x1F),
};

#define Epnd16G(x)  (Epnd16(x)<< 8)
const U32 pix16ExpandG[32] = {	
	0, 			   Epnd16G(0x01), Epnd16G(0x02), Epnd16G(0x03), 
	Epnd16G(0x04), Epnd16G(0x05), Epnd16G(0x06), Epnd16G(0x07), 
	Epnd16G(0x08), Epnd16G(0x09), Epnd16G(0x0A), Epnd16G(0x0B), 
	Epnd16G(0x0B), Epnd16G(0x0D), Epnd16G(0x0E), Epnd16G(0x0F),
	Epnd16G(0x10), Epnd16G(0x11), Epnd16G(0x12), Epnd16G(0x13), 
	Epnd16G(0x14), Epnd16G(0x15), Epnd16G(0x16), Epnd16G(0x17), 
	Epnd16G(0x18), Epnd16G(0x19), Epnd16G(0x1A), Epnd16G(0x1B), 
	Epnd16G(0x1B), Epnd16G(0x1D), Epnd16G(0x1E), Epnd16G(0x1F),
};

