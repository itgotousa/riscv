/****************************************************************************
CONFIDENTIAL AND PROPRIETARY INFORMATION.  The entire contents of this file
is Copyright ?Macromedia, Inc. 1993-1998, All Rights Reserved.  This
document is an unpublished trade secret of Macromedia, Inc. and may not be
viewed, copied or distributed by anyone, without the specific, written
permission of Macromedia, Inc. 

This file contains routines for working with quadratic bezier curve segments
***************************************************************************/
#ifndef CURVE_INCLUDED
#define CURVE_INCLUDED

#ifndef GEOM_INCLUDED
#include "geom.h"
#endif

typedef struct {
	SPOINT anchor1;
	SPOINT control;
	SPOINT anchor2;
	int    isLine;
} CURVE, *P_CURVE;

#endif
