/****************************************************************************
CONFIDENTIAL AND PROPRIETARY INFORMATION.  The entire contents of this file
is Copyright ?Macromedia, Inc. 1993-1998, All Rights Reserved.  This
document is an unpublished trade secret of Macromedia, Inc. and may not be
viewed, copied or distributed by anyone, without the specific, written
permission of Macromedia, Inc. 
****************************************************************************/

#ifndef RASTER_INCLUDED
#define RASTER_INCLUDED

#ifndef SHAPE_INCLUDED
#include "shape.h"
#endif
#ifndef BITBUF_INCLUDED
#include "bitbuf.h"
#endif
#ifndef SBITMAP_INCLUDED
#include "sbitmap.h"
#endif

#define SMOOTHBITS 1

class CBitBuffer;
class CRaster;
class SBitmapCore;

struct RActiveEdge;
struct RColor;
struct REdge;
struct BltInfo;

typedef void (*DrawSlabProc)(RColor* color, S32 xmin, S32 xmax);
typedef void (*CompositeSlabProc)(RColor* color, S32 xmin, S32 xmax, RGBI* buf);
typedef void (*DrawRGBSlabProc)(CRaster*, S32 xmin, S32 xmax, RGBI* pix);
typedef void (*BltProc)(BltInfo* bi, SPOINT& pt, int n, void* dst);

//
// The Scan Line Renderer
//

enum { fillEdgeRule = 0, fillEvenOddRule, fillWindingRule };

class CRaster {
public:
	BOOL needFlush;
	U32 layerDepth;

public:
	CBitBuffer* bits;
	SColorInfo* cinfo;
	SRECT edgeClip;	// The clip rect in higher res coords (for antialiasing)
	SRECT bitClip;	// The clip rect in bitmap coords

private:
	// The active color list
	RColor *topColor;
	S32 topColorXleft;	// the left edge of the current slab being processed

	// Context for Paint()
	RActiveEdge* firstActive;
	REdge** yindex;
	S32 yindexSize;
	S32 ylines;
	S32 y;

private:
	// Fast Memory Allocators
	ChunkAlloc activeEdgeAlloc;;

	RActiveEdge* CreateActiveEdge() { return (RActiveEdge*)(activeEdgeAlloc.Alloc()); }
	void FreeActiveEdge(RActiveEdge* a) { activeEdgeAlloc.Free(a); }

	friend struct RColor;

	friend void DoEdgeEvenOddRule(CRaster*, RActiveEdge*);

private:
	// The sub steps for Painting
	void AddActive();
	void SortActive();

	void PaintSlab(S32 xright);
	void ShowColor(RColor*, S32 x);
	void HideColor(RColor*, S32 x);

	void PaintActive();

private:
	// Our local cached bitmap information
	BOOL inverted;
	char  * baseAddr;
	S32 rowBytes;		// should always be a multiple of 4 bytes
	int pixelFormat;
	S32 bitHeight;
	S32 xorg;			// x pixel alignment

	// Current line context
	char  * rowAddr;
	S32 bitY;

	// Draw procs
	DrawRGBSlabProc drawRGBSlab;

public:

	friend void BuildBitmapSlab (RColor*, S32 xmin, S32 xmax, RGBI* pixBuf);
	
	friend void DrawBitmapSlab	(RColor*, S32 xmin, S32 xmax);

	friend void DrawRGBSlab1(CRaster*, S32 xmin, S32 xmax, RGBI* pix) {};
	friend void DrawRGBSlab2(CRaster*, S32 xmin, S32 xmax, RGBI* pix) {};
	friend void DrawRGBSlab4(CRaster*, S32 xmin, S32 xmax, RGBI* pix) {};
	friend void DrawRGBSlab8(CRaster*, S32 xmin, S32 xmax, RGBI* pix) {};
	friend void DrawRGBSlab16(CRaster*, S32 xmin, S32 xmax, RGBI* pix);
	friend void DrawRGBSlab16A(CRaster*, S32 xmin, S32 xmax, RGBI* pix);
	friend void DrawRGBSlab24(CRaster*, S32 xmin, S32 xmax, RGBI* pix);
	friend void DrawRGBSlab32(CRaster*, S32 xmin, S32 xmax, RGBI* pix);
	friend void DrawRGBSlab32A(CRaster*, S32 xmin, S32 xmax, RGBI* pix);

	friend void CompositeBitmapSlab(RColor*, S32 xmin, S32 xmax, RGBI* buf);

	// General Blts
	friend inline void BltXtoI(BltInfo* bi, SPOINT& pt, int n, RGBI* pix);
	friend inline void Blt32toI(BltInfo* bi, SPOINT& pt, int n, RGBI* pix);
	friend void Blt16to16(BltInfo *bi, SPOINT& pt, int n, U16 * dst);
	friend void Blt16to32(BltInfo *bi, SPOINT& pt, int n, U32 * dst);

private:
	void SetYCoord(S32 y);
	void CompositeSlab(S32 xleft, S32 xright, RColor** stack, int n);

public:
	CRaster();
	~CRaster();
	void FreeEmpties();		// free unused memory chunks

	void Attach(CBitBuffer*, SRECT* clip);
	BOOL BitsValid();

	// Painting
	void BeginPaint();
	void AddEdges(REdge*, RColor* colors, RColor* clipColor=0);	// also adjust the colors for depth
	void AddEdges(REdge*);
	void PaintBits();
	void Flush();
};

//
// The Edge Structure
//

struct REdge {
	REdge *nextObj;		// The next edge belonging to this object
	REdge *nextActive;	// The next edge that becomes active on this scanline
	RColor *color1, *color2;
	S16 anchor1x;		// store the CURVE as 16 bit ints to save RAM
	S16 anchor1y;
	S16 controlx;
	S16 controly;
	S16 anchor2x;
	S16 anchor2y;
	int isLine;
	U8 fillRule;
	S8 dir;

	inline void Set(CURVE* c) {
		anchor1x = (S16)c->anchor1.x;
		anchor1y = (S16)c->anchor1.y;
		controlx = (S16)c->control.x;
		controly = (S16)c->control.y;
		anchor2x = (S16)c->anchor2.x;
		anchor2y = (S16)c->anchor2.y;
		isLine   = 1;
	}
};


//
// The Color Structure
//

struct BltInfo {
	RColor* color;

	U8 * baseAddr;	// source bitmap description
	S32 rowBytes;	
	RGB8* colors;
	int width;
	int height;
};

struct RColorBMInfo {
	U16 bitsStyle;
	SBitmapCore* bitmap;
	MATRIX savedMat;
	MATRIX invMat;

	BltProc bltProc;
	BltInfo bi;		// cached blting info
};

enum {
	colorSolid, 	// a solid RGB color
	colorBitmap, 	// a bitmap 
	colorGradient, 	// a gradient ramp
	colorClip 	// a clip color
};

struct RColor {
	CRaster* raster;		// The render object that owns this color
	RColor* nextActive;		// The next color in the active color list
	RColor* nextColor;		// The next entry in the color list
	U32 order;				// the stacking order

	U8 transparent;			// true if this color could have partial transparency
	S8 visible;				// 0 if not visible, != 0 if visible
	U8 colorType;			// solid, bitmap, gradient
	U8 cacheValid;

	DrawSlabProc drawSlabProc; // draw the bits direct to the device bits
	CompositeSlabProc compositeSlabProc; // draw or composite to an RGBI buffer

	RColorBMInfo bm;	// for bitmaps, the source bitmap info

	void SetUp(CRaster* r);

	void BuildCache();
	void FreeCache();
};

//
// Helper Functions
//
struct CoverEntry {
	int ce[4];
};
extern CoverEntry PixCoverage[8][8];

// JLH: Added for kraster.cpp
void CompositeRGB(RGBI* src, RGBI* dst, int n);

#endif
