/****************************************************************************
CONFIDENTIAL AND PROPRIETARY INFORMATION.  The entire contents of this file
is Copyright ?Macromedia, Inc. 1993-1998, All Rights Reserved.  This
document is an unpublished trade secret of Macromedia, Inc. and may not be
viewed, copied or distributed by anyone, without the specific, written
permission of Macromedia, Inc. 
****************************************************************************/

// The object is responsible for generating edges and colors in a format 
//	that the scan converter can use.

#ifndef SOBJECT_INCLUDED
#define SOBJECT_INCLUDED

#ifndef RASTER_INCLUDED
#include "raster.h"	// just for RGB16
#endif
#ifndef SNDMIX_INCLUDED
#include "sndmix.h"
#endif

class DisplayList;
class ScriptPlayer;
class ScriptThread;
struct SCharacter;

//
// The Character Maintains the unmapped edges of an object
//
enum { 
	shapeChar		    = 0, 
	bitsChar		    = 1, 
	buttonChar		    = 2, 
	fontChar		    = 3, 
	textChar		    = 4, 
	soundChar		    = 5, 
	spriteChar		    = 6,
	morphShapeChar	    = 7,
	commandChar		    = 8,			// used for the Flash Generator
	editTextChar	    = 9,
	videoChar			= 10,

	spriteExternalChar  = 97,
	rootChar		    = 98, 
	lostChar		    = 99 
};

struct SCharacter {
	SCharacter* next;
	ScriptPlayer* player;
	U16 tag;
	U8 type;
	U8 tagCode;	// the stag code from the define tag
	U8 * data;	// this must be first
	SRECT bounds;
	U16 use;
	union {
		SBitmapCore bits;
#ifdef SOUND
		CSound sound;
#endif
	};
};

//
// The Object keeps track of a set of colors and edges
// 	That have been mapped to the render device
//

struct STransform {
	MATRIX mat;

	void Concat(STransform* child) {
		MatrixConcat(&child->mat, &mat, &mat);
	}
	void Clear() {
		MatrixIdentity(&mat);
	}
};

//
// Display list update model
//
//  place - put the object on the display, mark as dirty
//	move - change transform, free cache mark as dirty
//	remove - if drawn, add inval rect
//	update - if dirty, calc devMat and devBounds, inval rect
//	freeCache - free cache

struct SObject {
	DisplayList* display;	// the display tree
	SObject* parent;
	SObject* above;
	SObject* bottomChild;

	SCharacter* character;
	U16 depth;			// the z order where this object should be drawn

	STransform xform;
	SRECT devBounds;

	U8 drawn;				// true if this object has been drawn and needs to be erased
	U8 dirty;
	U8 visible;             // if set to zero we dont draw or hit test the object

	REdge* edges;
	RColor* colors;

	void CalcDevBounds(MATRIX*);
	void BuildEdges(STransform*);
	void FreeCache();
	void Free();

	void FreeChildren();		// free all the children of the object
	void Modify();				// mark the object as need draw
	void CalcUpdate(MATRIX* m, BOOL forceDirty=false);	// calculate the update region based on the changes

	void Draw(CRaster* raster, STransform* x, RColor* clipColor = 0);
};

#endif
