/****************************************************************************
CONFIDENTIAL AND PROPRIETARY INFORMATION.  The entire contents of this file
is Copyright ?Macromedia, Inc. 1993-1998, All Rights Reserved.  This
document is an unpublished trade secret of Macromedia, Inc. and may not be
viewed, copied or distributed by anyone, without the specific, written
permission of Macromedia, Inc. 
****************************************************************************/

#ifndef SPLAYER_INCLUDED
#define SPLAYER_INCLUDED

// Define dragbuttons for now...
//#define DRAGBUTTONS
//#define ACTIONSCRIPT

#include "splay.h"
#include "bitbuf.h"

enum {
	CURSOR_TYPE_ARROW,		// the arrow
};

/*! The parent class of NativePlayerWnd, SPlayer deals with events (mouse, keyboard), drawing,
*	cursors, etc. at a "higher" OS-independant level. It aggregates the ScriptPlayer, DisplayList,
*	and CBitBuffer, acting as a sort of "main" object.
*/
class SPlayer {
public:

	// Our player Objects
	ScriptPlayer player;		// note that this is always layer #0 and the root of our layer list
	DisplayList display;
	CBitBuffer bits;

#ifdef SOUND
#ifdef ONE_SOUND_OBJECT
	static NativeSoundMix theSoundMix;		// there will only be one NativeSoundMix
#else
	NativeSoundMix theSoundMix;				// one NativeSoundMix per SPlayer
#endif
#endif

	// Sound prebuffer property
	int nSoundBufferTime;

	// Counters for autoquality settings
	int nTooSlow;
	int nTooFast;
	int nTotal;

	BOOL destructing;

	// Background playing control
	//BOOL syncToClock;	//	set if we should be skipping frames to keep the animation tightly synchronized to the clock
	S32 nextFrameTime;	// the tick value to display the next frame

	BOOL loaded;		// set when the first frame is loaded
	BOOL running;		// set if the player is running

	S32 mTimerOffset;

public:
	SPlayer();
	virtual ~SPlayer();

	enum { updateNone, updateNow, updateLazy };
	void SetCamera(int update);
	void FreeLayers();
	void ClearScript();
	void GotoFrame(int);
	int CurrentFrame() { return player.GetFrame(); }
	
	/*! Deletes the bitmap backing the window, invalidates the display. Flash will 
	*  rebuild the bitmap with the current screen depth and palette.
	*/
	void FreeBuffer();
	BOOL UpdateBuffer(BOOL render = true);
	void UnlockBuffer() { bits.UnlockBits(); }

	void ClearLayer(int layerDepth);

	void Run();
	void Suspend();

	void Play(BOOL rewind=true) { player.Play(rewind); }
	void StopPlay() { player.StopPlay(); }

	void DoPlay(BOOL wait);	// a routine to call repeatedly in response to timer messages or null events

	// The Scripting API
	int TotalFrames() { return player.numFrames; }
	int PercentLoaded() { return (int)(player.len*100/player.scriptLen); }
	BOOL FrameLoaded(int frameNum) { return player.FrameComplete(frameNum); }
	BOOL IsPlaying() { return player.playing; }
	BOOL IsLoaded() { return loaded; }
	BOOL IsMute() { return player.mute; }
	WORD GetFrameRate() { return player.frameRate >> 16; }
	BOOL GetVideoSize(SRECT* frame) { frame->xmax = player.frame.xmax; frame->ymax = player.frame.ymax; return true; }

	void UpdateScreen();	// update the screen immediately

	/*! OnDraw is a method provided for use by the native code. <br>
	*  OnDraw should be called when the play timer fires, or when
	*	the screen should be rendered.
	*/
	void OnDraw();

	/*! OnDraw is a method provided for use by the native code. <br>
	*	It is used to request a repaint of a screen rectangle. Usefull
	*	for responding to re-paint requests from the OS.
	*/
	void Repaint( SRECT* rect );

	void CheckUpdate();		// generate an InvalidateRect if the screen needs redrawn

	virtual BOOL StartTimer( int playTimerInterval) = 0;		
	virtual void StopTimer() = 0;
	virtual void InvalidateScreenArea( SRECT* ) = 0;
	virtual void ClientRect(SRECT*) = 0;
	virtual void AdjustWindow( int width, int height ) = 0;

	/*! StreamGetURLNotify is a call made to the Native code to start a Get.
	*	It mimics the netscape call NPN_GetURLNotify (See the plug-in guide
	*	at http://developer.netscape.com/docs/manuals/ )
	*	\param		url		URL of the GET request, specified by the plug-in.
	*	\param		window	Target window. For values, see NPN_GetURL.
	*	\param		notifydata    Plug-in-private value	 */
	virtual void StreamGetURLNotify(const char* url,
		const char* lpData = NULL,
		const DWORD dwLen = 0
		) = 0;

	/*! A data stream is delivered to Flash in 3 steps:<br>
	*	1) StreamInNew<br>
	*	2) StreamInWrite<br>
	*	3) StreamInDestroy<br>
	*	Note that Flash has only one thread and these calls need to be on that thread; it may 
	*	be necessary to perform synchronization in native code.<br>
	*	StreamInNew is either a response to a POST or GET,
	*	or can be used to initiate streaming (and loading a movie) without 
	*  a request from Flash. If used to initiate streaming, it is possible
	*  the incoming stream will confilct with the existing movie. There
	*  are 2 solutions to this problem:<br>
	*	1) only use StreamGetURLNotify to load the first movie - useful for plugins<br>
	*  2) use ControlOpen to start streaming, which will clear existing movies and strings.<br>
	*	StreamInNew is modeled after the netscape NPP_NewStream.
	*	\param		streamData		Storage space for data -- used by Flash core.
	*	\param		url				URL of the request, which was (usually) passed to the native code
	by StreamGetURLNotify.
	*	\param		notifyData		The data passed in by StreamGetURLNotify -- null if the stream is
	*								initiated by the native code.
	*/
	void StreamInNew(	StreamData* streamData);

	/*!	StreamInWrite delivers a block of SWF data to the Flash core. Based on netscape NPP_Write.
	*	Returns >= 0 to continue, return -1 if error
	*	\param		streamData		Storage space for data -- used by Flash core.
	*	\param		buffer			Pointer to a block o' SWF data.
	*	\param		length			length of that block.
	*/
	int StreamInWrite(	StreamData*	streamData,
		void* buffer,
		int	  length,
		BOOL bMemory);

	/*!	StreamInDestroy ends the delivery of SWF data to the Flash core. 
	*	Based on netscape NPP_DestroyStream. Deallocates memory stored by streamData.
	*	\param		streamData		Storage space for data -- used by Flash core.
	*/
	void StreamInDestroy( StreamData* streamData );	

	/*! The Control* methods are provided for use by the native code. Their
	*  functionality (and names) reflects menu item choices.<br>
	*	ControlOpen opens and plays a movie given a URL to a local or remote object.
	*/
	void ControlOpen( char* url );
	void ControlMemory(char *lpData, DWORD dwSize, DWORD dwNew);
	void ControlClose();
	void ControlSound(int enabled);

	void LoadMovie(char* path);

	/*! Currently not used. Writes an "ideal" palette into ctab. Just a suggestion.
	*/
	void CreateIdealPalette( SColorTable* ctab );

	virtual BOOL UpdateCursor() = 0;
};

#endif
