/****************************************************************************
CONFIDENTIAL AND PROPRIETARY INFORMATION.  The entire contents of this file
is Copyright ?Macromedia, Inc. 1993-1998, All Rights Reserved.  This
document is an unpublished trade secret of Macromedia, Inc. and may not be
viewed, copied or distributed by anyone, without the specific, written
permission of Macromedia, Inc. 
****************************************************************************/
//	990325	mnk	"fixed1" -> "fixed_1"

#include <stddef.h>
#include <memory.h>
#include <math.h>
#include <stdio.h>

#include "splayer.h"

#include "stags.h"
#include "sobject.h"
#include "memcop.h"
#include "splay.h"

#include NATIVE_VERSION
#include NATIVE_UTIL
#include NATIVE_SOUND

char *ConvertIntegerToString(int value);

/*-------------------------------------------------------------------------*/

#ifdef SOUND
	#ifdef ONE_SOUND_OBJECT
	// If there is only one sound object, initialize it.
	NativeSoundMix SPlayer::theSoundMix;
	#endif
#endif SOUND

SPlayer::SPlayer()
{
	#ifdef SOUND
		display.theSoundMix = &theSoundMix;
	#endif

	// Our Player
	player.SetDisplay(&display);	// the player draws into the display list
	player.splayer = this;
	display.SetBits(&bits);			// the display list draws into the bit buffer

	// Counters for auto quality settings
	nTooSlow = 0;
	nTooFast = 0;
	nTotal = 0;
	//starved = false;

	// # of seconds to prebuffer sound
	nSoundBufferTime = 5;

	// Offset for GetTimer
	mTimerOffset = GetTimeMSec();

	// Play Control
	loaded = false;
	running = false;
	nextFrameTime = 0;

	destructing = false;

	#ifdef SOUND
	theSoundMix.Construct();
	#endif
}

SPlayer::~SPlayer()
{
	FLASHOUTPUT( "Deleting: SPlayer\n" );

	destructing = true;		// We cannon call NativePlayerWnd functions any more - since NPW has
							// been deleted. Set this flag so NPW functions can be wrapped in
							// if ( !destructing ) calls.
	ClearScript();

	FreeLayers();

#ifdef SOUND
	theSoundMix.Destruct();
#endif
}

ScriptPlayer* FindLayer(ScriptPlayer* layer, int layerDepth)
{
	while ( layer ) {
		if ( layer->layerDepth == layerDepth )
			return layer;
		layer = layer->nextLayer;
	}
	return 0;
}

void SPlayer::ClearLayer(int layerDepth)
{
	if ( layerDepth == 0 ) {
		// For layer 0, reset everything
		ClearScript();
	} else {
		// For all other layers, delete the player
		ScriptPlayer** link = &player.nextLayer;
		while ( true ) {
			ScriptPlayer* layer = *link;
			if ( !layer ) break;
			if ( layer->layerDepth == layerDepth ) {
				*link = layer->nextLayer;
				delete layer;
				return;
			}
			link = &layer->nextLayer;
		}
	}
}

void SPlayer::SetCamera(int update)
// Set the camera mat so that the picture frame fills the window
{
	SRECT vr;
	ClientRect(&vr);
	display.SetCamera();
	switch ( update ) {
		case updateLazy:
			CheckUpdate();
			break;			
		case updateNow:
			UpdateScreen();
			break;
	}
}

void SPlayer::FreeLayers()
{
	// Note layer[0] is special and should not be deleted
	while (true) {
		ScriptPlayer* layer = player.nextLayer;
		if ( !layer ) 
			break;
		player.nextLayer = layer->nextLayer;
		delete layer;
	}

	player.ClearScript();
}

void SPlayer::ClearScript()
// Clear all of the layers in the movie
{
	Suspend();

	FreeLayers();

	loaded = false;

	// This is a spagetti situation:
	// SetCamera will call 
	//		NativePlayerWnd::ClientRect(&vr)
	// which is already destroyed. So we set a 
	// flag to suppress this call.
	if ( !destructing )
	{
		SetCamera(updateLazy);
	}
}

void SPlayer::GotoFrame(int f)
{
	FLASHOUTPUT("Goto %i\n", f);
	player.Seek(f);
	CheckUpdate();
}

void SPlayer::FreeBuffer()
{
	bits.FreeBits();
	display.Invalidate();
}

void SPlayer::DoPlay(BOOL wait)
{
	// If the first frame isn't loaded yet, we must not perform DoPlay, because movie clips
	// may start animating before we're ready to execute actions.
	if (!loaded) {
		return;
	}

	S32 time = GetTimeMSec();
	int nFramesToAdvance = 1;

	#ifdef SOUND
	ScriptThread* syncThread = 0;
	{// Look for a thread with streaming sound...
		theSoundMix.EnterCritical();
		for ( ScriptThread* t = display.threads; t; t = t->next ) {
			CSoundChannel* c = t->sndChannel;
			if ( c && c->IsPlaying() && !c->streamStalled ) {
				// Use the streaming sound as the clock...
				nFramesToAdvance = c->ElapsedFrames() - t->GetFrame();
				syncThread = t;
				if ( nFramesToAdvance <= 0 ) {
					theSoundMix.LeaveCritical();
					return;
				}
				goto Advance;
			}
		}
		
	}
	#endif

	// Is it time to show the next frame yet???
	if ( wait && time < nextFrameTime ) {
		theSoundMix.LeaveCritical();
		return;
	}

  Advance:
	theSoundMix.LeaveCritical();
	// Always try to maintain the frame delay and slow down if we can't keep up
	nextFrameTime = time + player.frameDelay;

	#ifdef DEBUG
	if ( nFramesToAdvance > 1 )
		FLASHOUTPUT("Skipped %i frames\n", nFramesToAdvance);
	#endif

	while ( nFramesToAdvance-- ) {
		// Process the timeline for all threads
		for ( ScriptThread* t = display.threads; t; t = t->next ) {
			#ifdef SOUND
			if ( t->sndChannel && t != syncThread && t->sndChannel->IsPlaying() ) {
				if ( t->sndChannel->ElapsedFrames() >= t->GetFrame() || t->sndAtEnd ) {
					// Don't get ahead of a sound channel
					t->DoFrame();
				}
			} else 
			#endif
			{
				// Advance a single frame
				t->DoFrame();
			}
		}
	}
	UpdateScreen();
}

void SPlayer::LoadMovie( char* path )
{
	ClearScript();			       //SPlayer

	StreamGetURLNotify(path);
}

void SPlayer::ControlOpen( char* filename )
{
	if ( filename && *filename )
	{
		display.Reset();
		LoadMovie( filename );
		
		if ( player.ParseHeader() )
		{
			int width = (int)RectWidth( &player.frame );
			int height = (int)RectHeight( &player.frame );
			AdjustWindow( width, height );
		}
	}
}

void SPlayer::ControlMemory(char *lpData, DWORD dwSize, DWORD dwNew)
{
	if (dwNew) {
		display.Reset();
		ClearScript();
		StreamGetURLNotify( NULL, lpData, dwSize);

		if ( player.ParseHeader() )
		{
			int width = (int)RectWidth( &player.frame );
			int height = (int)RectHeight( &player.frame );
			AdjustWindow( width, height );
		}
	} else {
		StreamGetURLNotify( NULL, lpData, dwSize);
	}
}

void SPlayer::ControlSound(int enabled)
{
	if (enabled) {
		player.mute = false;
	} else {
		player.mute = true;
		player.StopStream();
	}
}

void SPlayer::ControlClose()
{
	ClearScript();
}

void SPlayer::Run()
{
	int delay = player.frameDelay / 10;
    if ( delay < 0 )
        delay = 1;

	if ( !running && StartTimer( delay ) )
	{
		// Start the timer
		running = true;
		nextFrameTime = GetTimeMSec();
	}
}

void SPlayer::Suspend()
{
	if ( running )
	{
		// Nothing should be running
		if ( !destructing )
		{
			StopTimer();		// once again, this is a native call - we can't call this in
								// a destructor.
		}
		running = false;

		#ifdef SOUND
		for ( ScriptThread* t = display.threads; t; t = t->next )
		{
			t->StopStream();
			theSoundMix.RemoveTagged((U32)t);	// stop all the sounds when we go away
		}
		#endif
	}
}

void SPlayer::CreateIdealPalette( SColorTable* ctab )
{
	const U8 colorRamp6[] = { 0, 0x33, 0x66, 0x99, 0xCC, 0xff };

	// Set up the a Palette of colors that we would like to be available.
	// Fill in the color ramp - 6 levels of each color
	int i = 0;
	for ( int b = 0; b <= 5; b++ ) {
		for ( int g = 0; g <= 5; g++ ) {
			for ( int r = 0; r <= 5; r++ ) {
				if ( r == g && g == b ) 
					continue;// don't do any grays here
				ctab->colors[i].red   = colorRamp6[r];
				ctab->colors[i].green = colorRamp6[g];
				ctab->colors[i].blue  = colorRamp6[b];
				ctab->colors[i].alpha = 0;
				i++;
			}
		}
	}
	ctab->n = i;
}

// update the buffer and blt to the screen given a DC
void SPlayer::OnDraw()
{
	// BACKCAST
	NativePlayerWnd* native = (NativePlayerWnd*)(this);

	if ( UpdateBuffer() && bits.LockBits() ) 
	{
		if ( !RectIsEmpty( &display.screenDirtyRgn ) ) 
		{
			// simply blt the buffer to the screen
			bits.bltToScreen(	native,
								display.screenDirtyRgn.xmin, display.screenDirtyRgn.ymin,
 								RectWidth(&display.screenDirtyRgn), RectHeight(&display.screenDirtyRgn),
								display.screenDirtyRgn.xmin, display.screenDirtyRgn.ymin
							);
		}

		UnlockBuffer();
		bits.UnlockBits();
	} else {
		bits.clearScreen( native );
	}
}

void SPlayer::Repaint( SRECT* rect )
{
	SRECT dev = *rect;

	display.InvalidateRect( &dev );
	OnDraw();
	RectSetEmpty(&display.screenDirtyRgn);
}

void SPlayer::UpdateScreen()
{
	// Copy to the screen
	SRECT dirty;

	display.CalcBitsDirty(&dirty);
	RectUnion(&dirty, &display.screenDirtyRgn, &dirty);

 	if ( !RectIsEmpty(&dirty) )
	{
		OnDraw();
	}
	RectSetEmpty(&display.screenDirtyRgn);
}

BOOL SPlayer::UpdateBuffer(BOOL render)
{
	// Check to create the offscreen bitmap
	if ( !bits.LockBits() ) {
		
 		SRECT cr;		
		ClientRect( &cr );

		if ( cr.xmin == cr.xmax || cr.ymin == cr.ymax ) {
			// The Window is empty, just exit
			return true;
		}
		bits.setAllowPurge( true );

		// Back-casting.
		NativePlayerWnd* native = (NativePlayerWnd*)( this );
		bits.CreateScreenBits( native, &cr );
		if ( !bits.LockBits() )
			return false;
		SetCamera(updateNone);
		display.ModifyCamera();	// be sure cached colors get flushed and display gets rebuilt...
        InvalidateScreenArea( &cr );
	}

	if ( render ) {
		// Be sure the bits are up to date
		display.Update();
	}
	return true;
}

void SPlayer::CheckUpdate()
// generate an InvalidateRect if the screen needs redrawn
{	
	SRECT dirty;
	display.CalcBitsDirty(&dirty);
	RectUnion(&dirty, &display.screenDirtyRgn, &dirty);
 	if ( !RectIsEmpty(&dirty) ) 
	{
        InvalidateScreenArea( &dirty );
		RectSetEmpty(&display.screenDirtyRgn);
	}
}

void SPlayer::StreamInNew( StreamData* streamData)
{
	FLASHOUTPUT( "StreamInNew %x\n", streamData );

    ScriptPlayer* p = (ScriptPlayer*)&player;
	p->stream = streamData;	// link the objects
	streamData->scriptPlayer = p;

	return;
}

int SPlayer::StreamInWrite( StreamData*	streamData,
							void* buffer,
							int	  length,
							BOOL bMemory)
{
	ScriptPlayer* p = streamData->scriptPlayer;
	if ( p ) {
		p->PushData((U8*)buffer, length, bMemory);

		return length;
	}
	
	return -1;	// we want to abort the stream...
}

void SPlayer::StreamInDestroy( StreamData* streamData )
{
	FLASHOUTPUT( "StreamInDestroy %x\n", streamData );
    ScriptPlayer* p = streamData->scriptPlayer;
	if ( p ) {
		p->stream = 0;
		p->SetDataComplete();
	}
}