#include "mboolib.h"
#include "Win32/PlayerWnd.h"
#define DEF_ZERO_IT(var)	MemoryZero(&(var), sizeof(var))

void MemoryZero(LPVOID p, DWORD dwSize)
{
    LPBYTE lp = (LPBYTE)p;

	for (DWORD i = 0; i < dwSize; i++, lp++)
        *lp = 0;
}

BOOL WINAPI RegisterMBLWindowClass(HINSTANCE hInstance)
{
    return MBLRegisterClass(hInstance);
}

HRESULT WINAPI MBL_Play(/* in */ HWND hwndMBL)
{
    MBLPlay MBLPlay; DEF_ZERO_IT(MBLPlay);

    MBLPlay.hr = E_FAIL;


    ::SendMessage(hwndMBL, MBL_PLAY, NULL, (LPARAM)&MBLPlay);

    return MBLPlay.hr;
}

HRESULT WINAPI MBL_Stop(/* in */ HWND hwndMBL)
{
    MBLStop MBLStop; DEF_ZERO_IT(MBLStop);

    MBLStop.hr = E_FAIL;


    ::SendMessage(hwndMBL, MBL_STOP, NULL, (LPARAM)&MBLStop);

    return MBLStop.hr;
}

HRESULT WINAPI MBL_Pause(/* in */ HWND hwndMBL)
{
    MBLPause MBLPause; DEF_ZERO_IT(MBLPause);

    MBLPause.hr = E_FAIL;


    ::SendMessage(hwndMBL, MBL_PAUSE, NULL, (LPARAM)&MBLPause);

    return MBLPause.hr;
}

HRESULT WINAPI MBL_GotoFrame(/* in */ HWND hwndMBL, /* in */ WORD FrameNum)
{
    MBLGotoFrame MBLGotoFrame; DEF_ZERO_IT(MBLGotoFrame);

    MBLGotoFrame.hr = E_FAIL;

    MBLGotoFrame.FrameNum = FrameNum;
	
    ::SendMessage(hwndMBL, MBL_GOTOFRAME, NULL, (LPARAM)&MBLGotoFrame);

    return MBLGotoFrame.hr;
}

HRESULT WINAPI MBL_CurrentFrame(/* in */ HWND hwndMBL, /* out */ WORD* currentFrame)
{
    MBLCurrentFrame MBLCurrentFrame; DEF_ZERO_IT(MBLCurrentFrame);

    MBLCurrentFrame.hr = E_FAIL;

    if (NULL == currentFrame)
        return E_POINTER;

    ::SendMessage(hwndMBL, MBL_CURRENTFRAME, NULL, (LPARAM)&MBLCurrentFrame);

    if (S_OK == MBLCurrentFrame.hr)
        *currentFrame = (WORD)MBLCurrentFrame.currentFrame;

    return MBLCurrentFrame.hr;
}

HRESULT WINAPI MBL_TotalFrames(/* in */ HWND hwndMBL, /* out */ WORD* totalFrames)
{
    MBLTotalFrames MBLTotalFrames; DEF_ZERO_IT(MBLTotalFrames);

    MBLTotalFrames.hr = E_FAIL;

    if (NULL == totalFrames)
        return E_POINTER;

    ::SendMessage(hwndMBL, MBL_TOTALFRAMES, NULL, (LPARAM)&MBLTotalFrames);

    if (S_OK == MBLTotalFrames.hr)
        *totalFrames = (WORD)MBLTotalFrames.totalFrames;

    return MBLTotalFrames.hr;
}

BOOL WINAPI MBL_PutMovieFromMemory(HWND hwndMBL, LPVOID lpData, DWORD dwSize, DWORD dwNew)
{
	if (NULL == hwndMBL)
		return FALSE;

	MBLPutMovieFromMemory info; DEF_ZERO_IT(info);
	
	info.lpData = lpData;
	info.dwSize = dwSize;
	info.dwNew = dwNew;

	::SendMessage(hwndMBL, MBL_PUTMOVIEFROMMEMORY, 0, (LPARAM)&info);

	return TRUE;
}

HRESULT WINAPI MBL_EnableSound(/* in */ HWND hwndMBL, /* in */ BOOL Enabled)
{
    MBLEnableSound MBLEnableSound; DEF_ZERO_IT(MBLEnableSound);

    MBLEnableSound.hr = E_FAIL;

	if (Enabled)
		MBLEnableSound.enabled = 1;
	else
		MBLEnableSound.enabled = 0;
	
    ::SendMessage(hwndMBL, MBL_ENABLESOUND, NULL, (LPARAM)&MBLEnableSound);

    return MBLEnableSound.hr;
}

HRESULT WINAPI MBL_GetVideoSize(/* in */ HWND hwndMBL, /* out */ UINT* videoSize)
{
    MBLGetVideoSize MBLGetVideoSize; DEF_ZERO_IT(MBLGetVideoSize);
	
	if (NULL == videoSize)
        return E_POINTER;

    MBLGetVideoSize.hr = E_FAIL;

    ::SendMessage(hwndMBL, MBL_GETVIDEOSIZE, NULL, (LPARAM)&MBLGetVideoSize);
	if(MBLGetVideoSize.hr == S_OK) {
		UINT xmax = MBLGetVideoSize.xmax;
		UINT ymax = MBLGetVideoSize.ymax;
		*videoSize = (xmax << 16) + ymax;
	}

    return MBLGetVideoSize.hr;
}

HRESULT WINAPI MBL_GetFrameRate(/* in */ HWND hwndMBL, /* out */ WORD* frameRate)
{
    MBLGetFrameRate MBLGetFrameRate; DEF_ZERO_IT(MBLGetFrameRate);
	
	if (NULL == frameRate)
        return E_POINTER;

    MBLGetFrameRate.hr = E_FAIL;

    ::SendMessage(hwndMBL, MBL_GETFRAMERATE, NULL, (LPARAM)&MBLGetFrameRate);
	if(MBLGetFrameRate.hr == S_OK) {
		*frameRate = (WORD)MBLGetFrameRate.frameRate;
	}

    return MBLGetFrameRate.hr;
}

HRESULT WINAPI MBL_IsMute(/* in */ HWND hwndMBL, /* out */ BOOL* isMute)
{
    MBLIsMute MBLIsMute; DEF_ZERO_IT(MBLIsMute);
	
	if (NULL == isMute)
        return E_POINTER;

    MBLIsMute.hr = E_FAIL;

    ::SendMessage(hwndMBL, MBL_ISMUTE, NULL, (LPARAM)&MBLIsMute);
	if(MBLIsMute.hr == S_OK) {
		if (MBLIsMute.isMute)
			*isMute = true;
		else
			*isMute = false;
	}

    return MBLIsMute.hr;
}

HRESULT WINAPI MBL_IsPlaying(/* in */ HWND hwndMBL, /* out */ BOOL* isPlaying)
{
    MBLIsPlaying MBLIsPlaying; DEF_ZERO_IT(MBLIsPlaying);
	
	if (NULL == isPlaying)
        return E_POINTER;

    MBLIsPlaying.hr = E_FAIL;

    ::SendMessage(hwndMBL, MBL_ISPLAYING, NULL, (LPARAM)&MBLIsPlaying);
	if(MBLIsPlaying.hr == S_OK) {
		if (MBLIsPlaying.isPlaying)
			*isPlaying = true;
		else
			*isPlaying = false;
	}

    return MBLIsPlaying.hr;
}

HRESULT WINAPI MBL_HavingVideo(/* in */ HWND hwndMBL, /* out */ BOOL* havingVideo)
{
    MBLHavingVideo MBLHavingVideo; DEF_ZERO_IT(MBLHavingVideo);
	
	if (NULL == havingVideo)
        return E_POINTER;

    MBLHavingVideo.hr = E_FAIL;

    ::SendMessage(hwndMBL, MBL_HAVINGVIDEO, NULL, (LPARAM)&MBLHavingVideo);
	if(MBLHavingVideo.hr == S_OK) {
		if (MBLHavingVideo.havingVideo)
			*havingVideo = true;
		else
			*havingVideo = false;
	}

    return MBLHavingVideo.hr;
}

HRESULT WINAPI MBL_CloseVideo(/* in */ HWND hwndMBL)
{
    MBLCloseVideo MBLCloseVideo; DEF_ZERO_IT(MBLCloseVideo);

    MBLCloseVideo.hr = E_FAIL;

    ::SendMessage(hwndMBL, MBL_CLOSEVIDEO, NULL, (LPARAM)&MBLCloseVideo);

    return MBLCloseVideo.hr;
}

HRESULT WINAPI MBL_SetCallBack(/* in */ HWND hwndMBL, /* in */ CallBackProc callback_func, /* in */ LPVOID uData)
{
    MBLSetCallBack MBLSetCallBack; DEF_ZERO_IT(MBLSetCallBack);

    MBLSetCallBack.hr = E_FAIL;

	MBLSetCallBack.callbackFunc = callback_func;
	MBLSetCallBack.uData = uData;
	
    ::SendMessage(hwndMBL, MBL_SETCALLBACK, NULL, (LPARAM)&MBLSetCallBack);

    return MBLSetCallBack.hr;
}

BOOL WINAPI MBL_LoadMovie(HWND hwndMBL, LPVOID lpData)
{
	if (NULL == hwndMBL)
		return FALSE;

	MBLLoadMovie info; DEF_ZERO_IT(info);
	
	info.lpData = lpData;

	::SendMessage(hwndMBL, MBL_LOADMOVIE, 0, (LPARAM)&info);

	return TRUE;
}

BOOL WINAPI MBL_LoadWatermark(HWND hwndMBL, LPVOID lpData)
{
	if (NULL == hwndMBL)
		return FALSE;

	MBLLoadWatermark info; DEF_ZERO_IT(info);
	
	info.lpData = lpData;

	::SendMessage(hwndMBL, MBL_LOADWATERMARK, 0, (LPARAM)&info);

	return TRUE;
}

HRESULT WINAPI MBL_SetVolume(/* in */ HWND hwndMBL, /* in */ DWORD Volume)
{
    MBLSetVolume MBLSetVolume; DEF_ZERO_IT(MBLSetVolume);

    MBLSetVolume.hr = E_FAIL;

	MBLSetVolume.lVolume = Volume & 0x0000FFFF;
	MBLSetVolume.rVolume = Volume & 0xFFFF0000;
	
    ::SendMessage(hwndMBL, MBL_SETVOLUME, NULL, (LPARAM)&MBLSetVolume);

    return MBLSetVolume.hr;
}

HWND WINAPI MBL_CreateWindow(DWORD dwStyle, int x, int y, int nWidth, int nHeight, HWND hWndParent, HINSTANCE hInstance)
{
	HWND hwndMBL;

	if (MBLCreateWindow(dwStyle, x, y, nWidth, nHeight, hWndParent, hInstance, &hwndMBL)) {
		return hwndMBL;
	} else {
		return NULL;
	}
}