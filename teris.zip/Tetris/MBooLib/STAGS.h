/****************************************************************************
CONFIDENTIAL AND PROPRIETARY INFORMATION.  The entire contents of this file
is Copyright ?Macromedia, Inc. 1993-1998, All Rights Reserved.  This
document is an unpublished trade secret of Macromedia, Inc. and may not be
viewed, copied or distributed by anyone, without the specific, written
permission of Macromedia, Inc. 
****************************************************************************/

#ifndef STAGS_INCLUDED
#define STAGS_INCLUDED

// Tags - the high 10 bits is the op code, the low 6 bits is the length
// if the length == 0x5f, the length is indicated by the following U32
enum {
	stagEnd 				= 0,
	stagShowFrame 			= 1,
	stagDefineShape		 	= 2,
	stagFreeCharacter 		= 3,
	stagPlaceObject 		= 4,
	stagRemoveObject 		= 5,
	stagDefineBits 			= 6, // id,w,h,colorTab,bits - bitmap referenced by a fill(s)
	stagDefineButton 		= 7, // up obj, down obj, action (URL, Page, ???)
	stagJPEGTables 			= 8, // id,w,h,colorTab,bits - bitmap referenced by a fill(s)
	stagSetBackgroundColor	= 9,
	stagDefineFont			= 10,
	stagDefineText			= 11,
	stagDoAction			= 12,
	stagDefineFontInfo		= 13,

	stagDefineSound			= 14, // Event sound tags
	stagStartSound			= 15,
	//stagStopSound			= 16,

	stagDefineButtonSound	= 17,

	stagSoundStreamHead		= 18,
	stagSoundStreamBlock	= 19,

	stagDefineBitsLossless	= 20,	// a bitmap using lossless zlib compression
	stagDefineBitsJPEG2		= 21,	// a bitmap using custom JPEG settings

	stagDefineShape2		= 22,
	stagDefineButtonCxform	= 23,

	stagProtect				= 24,	// this file should not be importable for editing

	stagPathsArePostScript	= 25,	// assume shapes are filled as PostScript style paths

	// Flash 3 tags
	stagPlaceObject2		= 26,	// the new style place w/ alpha color transform and name
	stagRemoveObject2		= 28,	// a more compact remove object that omits the character tag (just depth)

	// This tag is used for RealMedia only
	stagSyncFrame			= 29, // Handle a synchronization of the display list

	stagFreeAll				= 31, // Free all of the characters

	// These are the new tags for Flash 3
	stagDefineShape3		= 32,	// a shape V3 includes alpha values
	stagDefineText2			= 33,	// a text V2 includes alpha values
	stagDefineButton2		= 34,	// a Flash 3 button that contains color transform and sound info
	//stagMoveObject		= 34,	// OBSOLETE
	stagDefineBitsJPEG3		= 35,	// a JPEG w/ alpha channel
	stagDefineBitsLossless2 = 36,	// a lossless bitmap w/ alpha info
	//stagDefineButtonCxform2 = 37,	// OBSOLETE...a button color transform with alpha info

	//stagDefineMouseTarget	= 38,	// define a sequence of tags that describe the behavior of a sprite
	stagDefineSprite		= 39,	// define a sequence of tags that describe the behavior of a sprite
	stagNameCharacter		= 40,	// name a character definition, character id and a string, (used for buttons, bitmaps, sprites and sounds)
	//stagNameObject		= 41,	// OBSOLETE...name an object instance layer, layer number and a string, clear the name when no longer valid
	stagSerialNumber		= 41,	// a tag command for the Flash Generator customer serial id and cpu information
	stagDefineTextFormat	= 42,	// define the contents of a text block with formating information
	stagFrameLabel			= 43,	// a string label for the current frame
	//stagDefineButton2		= 44,	// a Flash 3 button that contains color transform and sound info
	stagSoundStreamHead2	= 45,	// for lossless streaming sound, should not have needed this...
	stagDefineMorphShape	= 46,	// a morph shape definition
	stagFrameTag			= 47,	// a tag command for the Flash Generator (U16 duration, STRING label)
	stagDefineFont2			= 48,	// a tag command for the Flash Generator Font information
	stagGenCommand			= 49,	// a tag command for the Flash Generator intrinsic
	stagDefineCommandObj	= 50,	// a tag command for the Flash Generator intrinsic Command
	stagCharacterSet		= 51,	// defines the character set used to store strings
	stagFontRef				= 52,   // defines a reference to an external font source

	// Flash 4 tags
	stagDefineEditText		= 37,	// an edit text object (bounds, width, font, variable name)
	stagDefineVideo			= 38,	// a reference to an external video stream

	// NOTE: If tag values exceed 255 we need to expand SCharacter::tagCode from a U8 to a U16
	stagDefineBitsPtr		= 1023  // a special tag used only in the editor
};

// Flags for defining a shape character
enum {
	// These flag codes are used for state changes - and as return values from ShapeParser::GetEdge()
	eflagsMoveTo	   = 0x01,
	eflagsFill0	   	   = 0x02,
	eflagsFill1		   = 0x04,
	eflagsLine		   = 0x08,
	eflagsNewStyles	   = 0x10,
	eflagsEnd 	   	   = 0x80  // a state change with no change marks the end
};

// Start Sound Flags
enum {
	soundHasInPoint		= 0x01,
	soundHasOutPoint	= 0x02,
	soundHasLoops		= 0x04,
	soundHasEnvelope	= 0x08

	// the upper 4 bits are reserved for synchronization flags
};

// PlaceObject 2 flags
// format
//   depth (word)
//   character tag (word)
//   matrix
//   color transform w/alpha
//	 blend ratio (word)
//	 name (string)
enum {
	splaceMove			      = 0x01, // this place moves an exisiting object
	splaceCharacter		      = 0x02, // there is a character tag	(if no tag, must be a move)
	splaceMatrix		      = 0x04, // there is a matrix
	splaceColorTransform      = 0x08, // there is a color transform
	splaceRatio			      = 0x10, // there is a blend ratio
	splaceName			      = 0x20, // there is an object name
	splaceDefineClip	      = 0x40, // this shape should open or close a clipping bracket (character != 0 to open, character == 0 to close)
	splaceCloneExternalSprite = 0x80  // cloning a movie which was loaded externally
	// 1 bit left for expansion
};

#endif // STAGS_INCLUDED




