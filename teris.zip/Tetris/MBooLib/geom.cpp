/****************************************************************************
CONFIDENTIAL AND PROPRIETARY INFORMATION.  The entire contents of this file
is Copyright ?Macromedia, Inc. 1993-1998, All Rights Reserved.  This
document is an unpublished trade secret of Macromedia, Inc. and may not be
viewed, copied or distributed by anyone, without the specific, written
permission of Macromedia, Inc. 
****************************************************************************/
//	990325	mnk	"fixed1" -> "fixed_1"


#include "geom.h"

//
// SRECT Routines
//

void RectSet(SCOORD xmin, SCOORD ymin, SCOORD xmax, SCOORD ymax, P_SRECT dst)
{	
	if ( xmin < xmax ) {
		dst->xmin = xmin;
		dst->xmax = xmax;
	} else {
		dst->xmin = xmax;
		dst->xmax = xmin;
	}
	if ( ymin < ymax ) {
		dst->ymin = ymin;
		dst->ymax = ymax;
	} else {
		dst->ymin = ymax;
		dst->ymax = ymin;
	}
}

void RectSetPoint(P_SPOINT pt, P_SRECT dst)
{
	dst->xmin = dst->xmax = pt->x;
	dst->ymin = dst->ymax = pt->y;
}

void RectSetEmpty(P_SRECT dst)
{
	dst->xmin = dst->xmax = dst->ymin = dst->ymax = rectEmptyFlag;
}

void RectInset(SCOORD dist, P_SRECT dst)
{
	if ( !RectIsEmpty(dst) ) {
		dst->xmin += dist;
		dst->xmax -= dist;
		dst->ymin += dist;
		dst->ymax -= dist;
		RectValidate(dst);
	}
}

void RectValidate(P_SRECT r)
{
	if ( r->xmin > r->xmax || r->ymin > r->ymax )
		RectSetEmpty(r);
}

void RectGetPoint(P_SRECT r, int ref, P_SPOINT pt)
{
	switch ( ref ) {
		case rectTopLeft: 
			pt->x = r->xmin;
			pt->y = r->ymax;
			break;
		case rectTopRight:
			pt->x = r->xmax;
			pt->y = r->ymax;
			break;
		case rectBottomRight:
			pt->x = r->xmax;
			pt->y = r->ymin;
			break;
		case rectBottomLeft:
			pt->x = r->xmin;
			pt->y = r->ymin;
			break;
		case rectTopCenter:
			pt->x = (r->xmin+r->xmax)>>1;
			pt->y = r->ymax;
			break;
		case rectCenterRight: 
			pt->x = r->xmax;
			pt->y = (r->ymin+r->ymax)>>1;
			break;
		case rectBottomCenter:
			pt->x = (r->xmin+r->xmax)>>1;
			pt->y = r->ymin;
			break;
		case rectCenterLeft:
			pt->x = r->xmin;
			pt->y = (r->ymin+r->ymax)>>1;
			break;
		default:
		case rectCenter:
			pt->x = (r->xmin+r->xmax)>>1;
			pt->y = (r->ymin+r->ymax)>>1;
			break;
	}
}

void RectUnion(P_SRECT r1, P_SRECT r2, P_SRECT dst)
{
	if ( RectIsEmpty(r1) ) {
		*dst = *r2;
	} else if ( RectIsEmpty(r2) ) {
		*dst = *r1;
	} else {
		dst->xmin = Min(r1->xmin, r2->xmin);
		dst->xmax = Max(r1->xmax, r2->xmax);
		dst->ymin = Min(r1->ymin, r2->ymin);
		dst->ymax = Max(r1->ymax, r2->ymax);
	}
}

void RectUnionPoint(P_SPOINT pt, P_SRECT dst)
{
	if ( RectIsEmpty(dst) ) {
		RectSetPoint(pt, dst);
	} else {
		if ( pt->x < dst->xmin ) dst->xmin = pt->x;
		else if ( pt->x > dst->xmax ) dst->xmax = pt->x;

		if ( pt->y < dst->ymin ) dst->ymin = pt->y;
		else if ( pt->y > dst->ymax ) dst->ymax = pt->y;
	}
}

void RectIntersect(P_SRECT r1, P_SRECT r2, P_SRECT dst)
{
	if ( RectIsEmpty(r1) || RectIsEmpty(r2) ) {
		RectSetEmpty(dst);
	} else {
		dst->xmin = FixedMax(r1->xmin, r2->xmin);
		dst->xmax = FixedMin(r1->xmax, r2->xmax);
		dst->ymin = FixedMax(r1->ymin, r2->ymin);
		dst->ymax = FixedMin(r1->ymax, r2->ymax);
		
		RectValidate(dst);
	}
}

BOOL RectTestIntersect(P_SRECT r1, P_SRECT r2)
{
	return !RectIsEmpty(r1) &&	// if one or both rect is empty, they cannot intersect
		   r1->xmin <= r2->xmax && r2->xmin <= r1->xmax &&
		   r1->ymin <= r2->ymax && r2->ymin <= r1->ymax;
}

//
// MATRIX Routines
//

void MatrixTransformPoint(P_MATRIX m, P_SPOINT p, P_SPOINT dst)
// Note that we try to optomize the common case of no rotation or slant
{
	dst->x = m->tx + p->x;
	dst->y = m->ty + p->y;
}

void MatrixTransformRect(P_MATRIX m, P_SRECT r, P_SRECT dst)
{
	if ( RectIsEmpty(r) ) {
		RectSetEmpty(dst);
	} else {
	  // Make the destination SRECT the union of the transformed corners
	  //	of the source SRECT
		SPOINT pt;
		SRECT result;
		int i;
		
		RectSetEmpty(&result);
		for ( i = 0; i < 4; i++ ) {
			RectGetPoint(r, i, &pt);
			MatrixTransformPoint(m, &pt, &pt);
			RectUnionPoint(&pt, &result);
		}
		
		*dst = result;
	}
}

void MatrixConcat(P_MATRIX m1, P_MATRIX m2, P_MATRIX dst)
{
	MATRIX result;

	result.a  = m1->a;
	result.d  = m1->d;
	result.b  = result.c = 0;
	result.tx = m1->tx + m2->tx;
	result.ty = m1->ty + m2->ty;
	
	*dst = result;
}

void MatrixInvert(P_MATRIX m, P_MATRIX dst)
{
	// Invert a simple matrix
	dst->a  = m->a;
	dst->d  = m->d;
	dst->b  = dst->c = 0; 
	dst->tx = -m->tx;
	dst->ty = -m->ty;
}

void MatrixIdentity(P_MATRIX m)
{
	m->a = m->d = 1;
	m->b = m->c = 0;
	m->tx = m->ty = 0;
}