/****************************************************************************
CONFIDENTIAL AND PROPRIETARY INFORMATION.  The entire contents of this file
is Copyright ?Macromedia, Inc. 1993-1998, All Rights Reserved.  This
document is an unpublished trade secret of Macromedia, Inc. and may not be
viewed, copied or distributed by anyone, without the specific, written
permission of Macromedia, Inc. 
****************************************************************************/
//	990325	mnk	"fixed1" -> "fixed_1"

#include "splay.h"
#include "splayer.h"
#include NATIVE_SOUND

#include "bitbuf.h"
#include "stags.h"
#include "sobject.h"

//
// Display List Methods
//

DisplayList::DisplayList() :
edgeAlloc(sizeof(REdge), 600, true, 0x22222222),
colorAlloc(sizeof(RColor), 64, true, 0x44444444),
objectAlloc(sizeof(SObject), 32, true, 0x55555555)
{
	// Set up the root object
	root.display = this;
	root.parent = 0;
	root.above = 0;
	root.bottomChild = 0;
	root.character = 0;
	root.depth = 0;
	root.xform.Clear();
	RectSetEmpty(&root.devBounds);
	root.drawn = false;

	root.edges = 0;
	root.colors = 0;
	root.visible = true;

	threads = 0;

	camera.Clear();
	bits = 0;
	dirty = false;
	RectSetEmpty(&screenDirtyRgn);
	RectSetEmpty(&devDirtyRgn);
	nDirty = 0;
	UpdateDevViewRect();

	backgroundColor.all = 0;
	backgroundColorPriority = 0;
}

DisplayList::~DisplayList()
{
	root.FreeChildren();

	// Zero out the thread list
	while ( threads ) {
		threads->display = 0;
		threads = threads->next;
	}
}

void DisplayList::AddThread(ScriptThread* thread) 
{
	FLASHASSERT(!thread->next); 
	thread->next = threads; 
	threads = thread; 
}

void DisplayList::RemoveThread(ScriptThread* thread)
{

	// Remove the thread from the list
	ScriptThread** link = &threads;
	while ( *link ) {
		if ( *link == thread ) {
			*link = thread->next;
			return;
		}
		link = &(*link)->next;
	}
	FLASHASSERT(false);
}

void DisplayList::Reset()
{
	if ( backgroundColorPriority <= 1 ) {
		backgroundColor.all = 0;
		backgroundColorPriority = 0;
		Invalidate();
	}
}

S32 RectArea(SRECT* area)
{
	return (area->xmax-area->xmin) * (area->ymax-area->ymin);
}

inline S32 UnionArea(SRECT* r1, SRECT* r2)
{
	SRECT area;
	RectUnion(r1, r2, &area);
	return RectArea(&area);
}

BOOL RectTestOverlap(P_SRECT r1, P_SRECT r2)
{
	return r1->xmin < r2->xmax && r2->xmin < r1->xmax &&
		r1->ymin < r2->ymax && r2->ymin < r1->ymax;
}

BOOL DisplayList::MergeDirtyList(BOOL forceMerge)
// Merge the pair of rectangles that will cause the smallest increase in the total dirty area
{
	if ( nDirty > 1 ) {
		// Check to merge areas to reduce the number
		S32 bestDelta = forceMerge ? 0x7FFFFFFFL : 0;	// if there is no empty slot, we must merge
		int mergeA = 0;
		int mergeB = 0;
		for ( int i = 0; i < nDirty-1; i++ ) {
			for ( int j = i+1; j < nDirty; j++ ) {
				S32 delta = UnionArea(devDirtyRect+i, devDirtyRect+j) - devDirtyArea[i] - devDirtyArea[j];
				if ( bestDelta > delta ) {
					mergeA = i;
					mergeB = j;
					bestDelta = delta;
				}
			}
		}

		if ( mergeA != mergeB ) {
			RectUnion(devDirtyRect+mergeA, devDirtyRect+mergeB, devDirtyRect+mergeA);
			devDirtyArea[mergeA] = RectArea(devDirtyRect+mergeA);
			for ( int i = mergeB+1; i < nDirty; i++ ) {
				devDirtyRect[i-1] = devDirtyRect[i];
				devDirtyArea[i-1] = devDirtyArea[i];
			}
			nDirty--;
			return true;
		}
	}
	return false;
}

void DecomposeRect(SRECT* r1, SRECT* r2)
// Restructure two overlaping rectangles to eliminate the intersecting area
//	while still covering the same area and perhaps more area
{
	FLASHASSERT(RectTestOverlap(r1, r2));

	// Build the 3 rect slabs on y-axis
	SRECT r[3];
	if ( r1->ymin < r2->ymin ) {
		r[0].ymin = r1->ymin;
		r[0].ymax = r2->ymin;
		r[0].xmin = r1->xmin;
		r[0].xmax = r1->xmax;
	} else {
		r[0].ymin = r2->ymin;
		r[0].ymax = r1->ymin;
		r[0].xmin = r2->xmin;
		r[0].xmax = r2->xmax;
	}
	if ( r1->ymax < r2->ymax ) {
		r[2].ymin = r1->ymax;
		r[2].ymax = r2->ymax;
		r[2].xmin = r2->xmin;
		r[2].xmax = r2->xmax;
	} else {
		r[2].ymin = r2->ymax;
		r[2].ymax = r1->ymax;
		r[2].xmin = r1->xmin;
		r[2].xmax = r1->xmax;
	}
	r[1].ymin = r[0].ymax;
	r[1].ymax = r[2].ymin;
	r[1].xmin = Min(r1->xmin, r2->xmin);
	r[1].xmax = Max(r1->xmax, r2->xmax);

	// Combine the middle slab with the slab that will generate the smallest area
	S32 a[3];
	for ( int i = 0; i < 3; i++ )
		a[i] = RectArea(r+i);

	SRECT u1, u2;
	RectUnion(&r[0], &r[1], &u1);
	RectUnion(&r[1], &r[2], &u2);

	S32 delta0 = a[0] + a[1] - RectArea(&u1);
	S32 delta1 = a[1] + a[2] - RectArea(&u2);

	if ( delta0 > delta1 ) {
		*r1 = u1;
		*r2 = r[2];
	} else {
		*r1 = r[0];
		*r2 = u2;
	}
}

void DisplayList::DecomposeDirtyList()
// Decompose any overlapping rectangles into non-overlapping rectangles
{
	// Merge any areas that would reduce the total area
	while ( MergeDirtyList(false) ) {}

	for ( int i = 0; i < nDirty-1; i++ ) {
		for ( int j = i+1; j < nDirty; j++ ) {
			if ( RectTestOverlap(devDirtyRect+i, devDirtyRect+j) ) {
				DecomposeRect(devDirtyRect+i, devDirtyRect+j);
			}
		}
	}
}

void DisplayList::InvalidateRect(SRECT* r)
{
	SRECT rect;
	rect.xmin = r->xmin;
	rect.xmax = r->xmax;
	rect.ymin = r->ymin;
	rect.ymax = r->ymax;

	RectInset(-2, &rect);
	if ( RectTestIntersect(&devViewRect, &rect) ) {
		FLASHASSERT(nDirty < maxDirtyAreas);
		// Add to the list
		RectIntersect(&devViewRect, &rect, &devDirtyRect[nDirty]);
		RectUnion(&devDirtyRgn, &devDirtyRect[nDirty], &devDirtyRgn);	// add to the dirty region
		devDirtyArea[nDirty] = RectArea(devDirtyRect+nDirty);	// add to the list
		nDirty++;

		MergeDirtyList(nDirty == maxDirtyAreas);
	}
}

void FreeCache(SObject* parent)
{
	parent->FreeCache();
	for ( SObject* obj = parent->bottomChild; obj; obj = obj->above )
		FreeCache(obj);
}

void DisplayList::FreeCache()
// free the cached data to reduce memory load
{
	::FreeCache(&root);

	edgeAlloc.FreeEmpties();
	objectAlloc.FreeEmpties();
	colorAlloc.FreeEmpties();
	raster.FreeEmpties();
}

void DisplayList::SetBits(CBitBuffer* b)
{
	bits = b;
	UpdateDevViewRect();
	Invalidate();	
}

void DisplayList::SetCamera()
{
	MATRIX newMat;

	newMat.b = newMat.c = 0;
	newMat.a = newMat.d = 1;
	newMat.tx = newMat.ty = 0;
	camera.mat = newMat;
}

void DisplayList::UpdateDevViewRect()
// set the dirty area to the whole view
{
	devViewRect.xmin = devViewRect.ymin = 0;
	if ( bits && bits->BitsValid()) {
		devViewRect.xmax = bits->width();
		devViewRect.ymax = bits->height();

	} else {
		devViewRect.xmax = 2000;
		devViewRect.ymax = 2000;
	}
}

void DisplayList::ModifyCamera()
{
	// Free all of the transformed edges and update the object matricies
	UpdateDevViewRect();
	Invalidate();
	root.Modify();
}

void DisplayList::SetBackgroundColor(SRGB color, int priority)
{
	if ( priority > backgroundColorPriority ) {
		if ( backgroundColor.all != color.all ) {
			Invalidate();	
			backgroundColor = color;
		}
		backgroundColorPriority = priority;
	}
}

void DisplayList::CalcBitsDirty(SRECT* devDirty, SRECT* bitsDirtyRgn)
{
	*bitsDirtyRgn = *devDirty;
}

class SStroker;

void DisplayList::UpdateRect(SRECT* clip)
{
	if ( bits->LockBits() ) {
		raster.Attach(bits, clip);
		raster.BeginPaint();

		{
			// Add the object edges
			root.Draw(&raster, &camera);
		}

		raster.PaintBits();

		bits->UnlockBits();
	}
}

void DisplayList::CalcUpdate()
{
	if ( dirty ) {
		root.CalcUpdate(&camera.mat);
		dirty = false;
	}
}

void DisplayList::Update()
{
	CalcUpdate();
	// Use multiple dirty rectangles to minimize area
	if ( nDirty > 0 && bits ) {
		// Update the frame buffer
		DecomposeDirtyList();
		for ( int i = 0; i < nDirty; i++ ) {
			SRECT bitsDirtyRgn;
			CalcBitsDirty(devDirtyRect+i, &bitsDirtyRgn);
			RectUnion(&bitsDirtyRgn, &screenDirtyRgn, &screenDirtyRgn);
			UpdateRect(&bitsDirtyRgn);
		}
	}

	RectSetEmpty(&devDirtyRgn);
	nDirty = 0;
}

SObject* DisplayList::PlaceObject(SObject* parent, PlaceInfo* info)
{
	// Find the insertion point
	SObject** link = &parent->bottomChild;
	for (;;) {
		SObject* obj = *link;
		if ( !obj ) break;
		if ( obj->depth >= info->depth ) {
			FLASHASSERT(obj->depth != info->depth);
			break;
		}
		link = &obj->above;
	}

	// Create a new object
	SObject* obj = CreateObject();
	if ( !obj ) return 0;

	// Add to list
	obj->parent = parent;
	obj->above = *link;
	*link = obj;

	// Set up object
	obj->character = info->character;
	obj->xform = *info;
	obj->depth = info->depth;
	obj->drawn = false;
	obj->visible = true;
	obj->display = this;
	obj->bottomChild = 0;
	obj->edges = 0;
	obj->colors = 0;

	// Regular processing: copy name if present
	obj->Modify();

	return obj;
}

void DisplayList::DoRemove(SObject** link)
{
	SObject* obj = *link;
	FLASHASSERT(obj);

	// Remove the contents of the old object
	if ( obj->drawn )
		InvalidateRect(&obj->devBounds);

	obj->FreeChildren();
	obj->Free();


	// Remove from list
	*link = obj->above;
	FreeObject(obj);
}

void DisplayList::RemoveObject(SObject* parent, U16 depth)
{
	// See if there is already an object at this depth or find the insertion point
	SObject* obj;
	SObject** link = &parent->bottomChild;
	for (;;) {
		obj = *link;
		if ( !obj ) break;
		if ( obj->depth >= depth ) 
			break;
		link = &obj->above;
	}

	if ( obj && obj->depth == depth )
		DoRemove(link);
}