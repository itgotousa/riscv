// Sample03_StandalonePlayerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Sample03_StandalonePlayer.h"
#include "Sample03_StandalonePlayerDlg.h"
#include "../MBooLib/mboolib.h"
#include "../MBooLib/global.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSample03_StandalonePlayerDlg dialog

CSample03_StandalonePlayerDlg::CSample03_StandalonePlayerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSample03_StandalonePlayerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSample03_StandalonePlayerDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSample03_StandalonePlayerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSample03_StandalonePlayerDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSample03_StandalonePlayerDlg, CDialog)
	//{{AFX_MSG_MAP(CSample03_StandalonePlayerDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(ID_PLAY_SWF_FROM_FILE, OnPlaySwfFromFile)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, &CSample03_StandalonePlayerDlg::OnBnClickedStop)
	ON_BN_CLICKED(IDC_BUTTON4, &CSample03_StandalonePlayerDlg::OnBnClickedCurrentFrame)
	ON_BN_CLICKED(IDC_BUTTON2, &CSample03_StandalonePlayerDlg::OnBnClickedPlay)
	ON_BN_CLICKED(IDC_BUTTON3, &CSample03_StandalonePlayerDlg::OnBnClickedPause)
	ON_BN_CLICKED(IDC_BUTTON5, &CSample03_StandalonePlayerDlg::OnBnClickedTotalFrames)
	ON_BN_CLICKED(IDC_BUTTON6, &CSample03_StandalonePlayerDlg::OnBnClickedGotoFrame)
	ON_BN_CLICKED(IDC_BUTTON7, &CSample03_StandalonePlayerDlg::OnBnClickedButton7)
	ON_BN_CLICKED(IDC_BUTTON8, &CSample03_StandalonePlayerDlg::OnBnClickedButton8)
	ON_BN_CLICKED(IDC_BUTTON9, &CSample03_StandalonePlayerDlg::OnBnClickedButton9)
	ON_BN_CLICKED(IDC_BUTTON10, &CSample03_StandalonePlayerDlg::OnBnClickedButton10)
	ON_BN_CLICKED(IDC_BUTTON11, &CSample03_StandalonePlayerDlg::OnBnClickedButton11)
	ON_BN_CLICKED(IDC_BUTTON12, &CSample03_StandalonePlayerDlg::OnBnClickedButton12)
	ON_BN_CLICKED(IDC_BUTTON13, &CSample03_StandalonePlayerDlg::OnBnClickedButton13)
	ON_BN_CLICKED(IDC_BUTTON14, &CSample03_StandalonePlayerDlg::OnBnClickedButton14)
	ON_BN_CLICKED(IDC_BUTTON15, &CSample03_StandalonePlayerDlg::OnBnClickedButton15)
	ON_BN_CLICKED(IDC_BUTTON16, &CSample03_StandalonePlayerDlg::OnBnClickedButton16)
	ON_BN_CLICKED(IDC_BUTTON17, &CSample03_StandalonePlayerDlg::OnBnClickedButton17)
	ON_BN_CLICKED(IDC_BUTTON18, &CSample03_StandalonePlayerDlg::OnBnClickedButton18)
	ON_BN_CLICKED(IDC_BUTTON19, &CSample03_StandalonePlayerDlg::OnBnClickedButton19)
	ON_BN_CLICKED(IDC_BUTTON20, &CSample03_StandalonePlayerDlg::OnBnClickedButton20)
	ON_BN_CLICKED(IDC_BUTTON21, &CSample03_StandalonePlayerDlg::OnBnClickedButton21)
	ON_BN_CLICKED(IDC_BUTTON22, &CSample03_StandalonePlayerDlg::OnBnClickedButton22)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSample03_StandalonePlayerDlg message handlers

BOOL CSample03_StandalonePlayerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	RegisterMBLWindowClass(NULL);
	pData = new U8[100000000];

	// FlashPlayerControl creating
	// NOTE: CALL FPC_LoadRegisteredOCX() or FPC_LoadOCXCodeFromMemory() before creating!
	// See InitInstance() implementation
	{
		RECT rc;
		GetDlgItem(IDC_STATIC_FPC_PLACE)->GetWindowRect(&rc);
		ScreenToClient(&rc);

		m_hwndFlashPlayerControl = 
			MBL_CreateWindow(WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS, 
						 rc.left, 
						 rc.top, 
						 800, 
						 600, 
						 m_hWnd,  
						 NULL);
	}

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSample03_StandalonePlayerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSample03_StandalonePlayerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSample03_StandalonePlayerDlg::OnPlaySwfFromFile() 
{
    CFileDialog dlg(TRUE, 
                    _T("swf|bwf"), 
                    _T(""), 
                    0, 
                    _T("Flash movie files (*.swf;*.bwf)|*.swf;*.bwf|Flash Movies (*.swf)|*.swf|Flash Video Files (*.bwf)|*.bwf|All Files (*.*)|*.*||"), 
                    this);

    if (IDOK == dlg.DoModal())
    {
        //
        CString strFlashMoviePath = dlg.GetPathName();

        //
        TCHAR lpszFlashMoviePath[MAX_PATH + 1] = { 0 };
        lstrcpy(lpszFlashMoviePath, strFlashMoviePath);

    
		HANDLE hFile = CreateFile(lpszFlashMoviePath,    
							  GENERIC_READ,    
							  FILE_SHARE_READ,    
							  NULL,    
							  OPEN_EXISTING,    
							  FILE_ATTRIBUTE_NORMAL,    
							  NULL);   
	  
		DWORD dwFlashOCXCodeSize = GetFileSize(hFile, NULL);   
	  
		HANDLE hFileMapping = CreateFileMapping(hFile,    
											NULL,    
											PAGE_READONLY,    
											0,    
											dwFlashOCXCodeSize,    
											NULL);   
	  
		LPVOID lpFlashOCXCodeData = MapViewOfFile(hFileMapping, FILE_MAP_READ, 0, 0, 0);
		memcpy(pData, lpFlashOCXCodeData, 500000);
		UnmapViewOfFile(lpFlashOCXCodeData);   
		CloseHandle(hFileMapping);   
		CloseHandle(hFile);
		MBL_PutMovieFromMemory(m_hwndFlashPlayerControl, (LPVOID)pData, 500000, 1);
	}
}
void CSample03_StandalonePlayerDlg::OnBnClickedStop()
{
	MBL_Stop(m_hwndFlashPlayerControl);
}

void CSample03_StandalonePlayerDlg::OnBnClickedCurrentFrame()
{
	WORD cf;
	
	MBL_CurrentFrame(m_hwndFlashPlayerControl, &cf);
	
	CString string;
	string.Format("CurrentFrame: %d", cf);
	MessageBox(string,"MBOOLIB TEST", NULL);
}

void CSample03_StandalonePlayerDlg::OnBnClickedPlay()
{
	MBL_Play(m_hwndFlashPlayerControl);
}

void CSample03_StandalonePlayerDlg::OnBnClickedPause()
{
	MBL_Pause(m_hwndFlashPlayerControl);
}

void CSample03_StandalonePlayerDlg::OnBnClickedTotalFrames()
{
	WORD tf;

	MBL_TotalFrames(m_hwndFlashPlayerControl, &tf);

	CString string;
	string.Format("TotalFrames: %d", tf);
	MessageBox(string,"MBOOLIB TEST", NULL);
}

void CSample03_StandalonePlayerDlg::OnBnClickedGotoFrame()
{
	MBL_GotoFrame(m_hwndFlashPlayerControl, 400);
}

void CSample03_StandalonePlayerDlg::OnBnClickedButton7()
{
	MBL_GotoFrame(m_hwndFlashPlayerControl, 9000);
}

void CSample03_StandalonePlayerDlg::OnBnClickedButton8()
{
    CFileDialog dlg(TRUE, 
                    _T("swf|bwf"), 
                    _T(""), 
                    0, 
                    _T("Flash movie files (*.swf;*.bwf)|*.swf;*.bwf|Flash Movies (*.swf)|*.swf|Flash Video Files (*.bwf)|*.bwf|All Files (*.*)|*.*||"), 
                    this);

    if (IDOK == dlg.DoModal())
    {
        //
        CString strFlashMoviePath = dlg.GetPathName();

        //
        TCHAR lpszFlashMoviePath[MAX_PATH + 1] = { 0 };
        lstrcpy(lpszFlashMoviePath, strFlashMoviePath);

		MBL_LoadMovie(m_hwndFlashPlayerControl, lpszFlashMoviePath);
	}
}

void CSample03_StandalonePlayerDlg::OnBnClickedButton9()
{
	CFileDialog dlg(TRUE, 
                    _T("swf|bwf"), 
                    _T(""), 
                    0, 
                    _T("Flash movie files (*.swf;*.bwf)|*.swf;*.bwf|Flash Movies (*.swf)|*.swf|Flash Video Files (*.bwf)|*.bwf|All Files (*.*)|*.*||"), 
                    this);

    if (IDOK == dlg.DoModal())
    {
        //
        CString strFlashMoviePath = dlg.GetPathName();

        //
        TCHAR lpszFlashMoviePath[MAX_PATH + 1] = { 0 };
        lstrcpy(lpszFlashMoviePath, strFlashMoviePath);

    
		HANDLE hFile = CreateFile(lpszFlashMoviePath,    
							  GENERIC_READ,    
							  FILE_SHARE_READ,    
							  NULL,    
							  OPEN_EXISTING,    
							  FILE_ATTRIBUTE_NORMAL,    
							  NULL);   
	  
		DWORD dwFlashOCXCodeSize = GetFileSize(hFile, NULL);   
	  
		HANDLE hFileMapping = CreateFileMapping(hFile,    
											NULL,    
											PAGE_READONLY,    
											0,    
											dwFlashOCXCodeSize,    
											NULL);   
	  
		LPVOID lpFlashOCXCodeData = MapViewOfFile(hFileMapping, FILE_MAP_READ, 0, 0, 0);

		memcpy(pData, lpFlashOCXCodeData, dwFlashOCXCodeSize);
		UnmapViewOfFile(lpFlashOCXCodeData);   
		CloseHandle(hFileMapping);   
		CloseHandle(hFile); 

		MBL_PutMovieFromMemory(m_hwndFlashPlayerControl, pData, dwFlashOCXCodeSize, 0);
	}
}

void CSample03_StandalonePlayerDlg::OnBnClickedButton10()
{
	MBL_EnableSound(m_hwndFlashPlayerControl, false);
}

void CSample03_StandalonePlayerDlg::OnBnClickedButton11()
{
	MBL_EnableSound(m_hwndFlashPlayerControl, true);
}

LRESULT callback_func(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam, LPVOID udata)
{

	switch (msg) 
	{
		case WM_KEYDOWN:
		case WM_CHAR:
		case WM_LBUTTONDOWN:
		case WM_LBUTTONUP:
		case WM_RBUTTONDOWN:
		case WM_RBUTTONUP:
		case WM_LBUTTONDBLCLK:
		case WM_RBUTTONDBLCLK:
			{
				CString string;
				string.Format("MSG: %d", msg);
				MessageBox(NULL,string,"MBOOLIB TEST", NULL);
			}
			break;
		case WM_MOUSEMOVE:
			break;
		case MBL_END:
			{
				MBL_Stop(hWnd);
				MBL_Play(hWnd);
			}
			break;
	}
	return 0;
}

void CSample03_StandalonePlayerDlg::OnBnClickedButton12()
{
	MBL_SetCallBack(m_hwndFlashPlayerControl, callback_func, NULL);
}

void CSample03_StandalonePlayerDlg::OnBnClickedButton13()
{
	UINT tf;

	MBL_GetVideoSize(m_hwndFlashPlayerControl, &tf);

	CString string;
	string.Format("VideoSize: %dx%d", tf >> 16, tf&0x0000ffff);
	MessageBox(string,"MBOOLIB TEST", NULL);
}

void CSample03_StandalonePlayerDlg::OnBnClickedButton14()
{
	WORD tf;

	MBL_GetFrameRate(m_hwndFlashPlayerControl, &tf);

	CString string;
	string.Format("FrameRate: %d", tf);
	MessageBox(string,"MBOOLIB TEST", NULL);
}

void CSample03_StandalonePlayerDlg::OnBnClickedButton15()
{
	BOOL tf;

	MBL_IsMute(m_hwndFlashPlayerControl, &tf);

	CString string;
	if (tf) {
		string.Format("isMute: true");
	} else {
		string.Format("IsMute: false");
	}
	MessageBox(string,"MBOOLIB TEST", NULL);
}

void CSample03_StandalonePlayerDlg::OnBnClickedButton16()
{
	BOOL tf;

	MBL_IsPlaying(m_hwndFlashPlayerControl, &tf);

	CString string;
	if (tf) {
		string.Format("isPlaying: true");
	} else {
		string.Format("IsPlaying: false");
	}
	MessageBox(string,"MBOOLIB TEST", NULL);
}
void CSample03_StandalonePlayerDlg::OnBnClickedButton17()
{
	BOOL tf;

	MBL_HavingVideo(m_hwndFlashPlayerControl, &tf);

	CString string;
	if (tf) {
		string.Format("HavingVideo: true");
	} else {
		string.Format("HavingVideo: false");
	}
	MessageBox(string,"MBOOLIB TEST", NULL);
}

void CSample03_StandalonePlayerDlg::OnBnClickedButton18()
{
	MBL_CloseVideo(m_hwndFlashPlayerControl);
}

void CSample03_StandalonePlayerDlg::OnBnClickedButton19()
{
	MBL_SetVolume(m_hwndFlashPlayerControl, 0x00FF00FF);
}

void CSample03_StandalonePlayerDlg::OnBnClickedButton20()
{
	MBL_SetVolume(m_hwndFlashPlayerControl, 0xFF00FF00);
}


void CSample03_StandalonePlayerDlg::OnBnClickedButton21()
{
	// TODO: Add your control notification handler code here
	MBL_LoadWatermark(m_hwndFlashPlayerControl, "abcd1234");
}


void CSample03_StandalonePlayerDlg::OnBnClickedButton22()
{
	// TODO: Add your control notification handler code here
	MBL_LoadWatermark(m_hwndFlashPlayerControl, "");
}
