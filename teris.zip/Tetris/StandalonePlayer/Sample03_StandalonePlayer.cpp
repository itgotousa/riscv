// Sample03_StandalonePlayer.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Sample03_StandalonePlayer.h"
#include "Sample03_StandalonePlayerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSample03_StandalonePlayerApp

BEGIN_MESSAGE_MAP(CSample03_StandalonePlayerApp, CWinApp)
	//{{AFX_MSG_MAP(CSample03_StandalonePlayerApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSample03_StandalonePlayerApp construction

CSample03_StandalonePlayerApp::CSample03_StandalonePlayerApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CSample03_StandalonePlayerApp object

CSample03_StandalonePlayerApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CSample03_StandalonePlayerApp initialization

UINT PlayThread(LPVOID lParam){

	CSample03_StandalonePlayerDlg dlg1;
	int nResponse = dlg1.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return 0;
}

BOOL CSample03_StandalonePlayerApp::InitInstance()
{
	AfxBeginThread(PlayThread,0,0,0,0,0);

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

	CSample03_StandalonePlayerDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

int CSample03_StandalonePlayerApp::ExitInstance() 
{
	return CWinApp::ExitInstance();
}
