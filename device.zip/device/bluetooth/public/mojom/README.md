# Bluetooth

Interfaces providing cross platform abstraction of [Bluetooth](../..).

## Note

These interfaces are NOT yet ready for production use by
other components. They are a start at a large task of producing
a service for device/bluetooth. Work was scoped to the miniumum
required to enable
[chrome://bluetooth-internals page][InternalsDesignDoc], and
long term design and testing were minimized to accomplish that.

[InternalsDesignDoc]: https://docs.google.com/document/d/1wa96bCrB2Iw7tTI-fWsKmhLB7_ffF12frGIjRvhaj9E/edit#heading=h.2j0b11w2a292

