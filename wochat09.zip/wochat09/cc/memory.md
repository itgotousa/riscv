This document has moved to [//docs/memory-infra/probe-cc.md](/docs/memory-infra/probe-cc.md).
