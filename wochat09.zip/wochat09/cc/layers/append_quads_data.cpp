#if 0


// Copyright 2017 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "cc/layers/append_quads_data.h"

namespace cc {

AppendQuadsData::AppendQuadsData() = default;

AppendQuadsData::~AppendQuadsData() = default;

}  // namespace cc



#endif
