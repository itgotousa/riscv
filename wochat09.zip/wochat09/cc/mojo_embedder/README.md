# cc/mojo_embedder/

This directory contains mojo bindings for connecting cc to viz via mojo.

